# Changelog

## [Unreleased]

### Fixed
- 現在値を表示しているときに「表示切替」を Undo / Redo すると、履歴に残っていた候補の値が
  現在値として入ってしまうことがあった。直前の現在値へ書き戻すようにした

### Added
- VCC / ALCOM 用のパッケージ（VPM 版）を配布物に同梱した。User Packages にフォルダを追加して入れる。
  ツール本体は `Packages/jp.yukke.shapepick/` に入り、候補の保存先は `Assets/ShapePick/Snapshots/` のまま
- 紐づけが切れた候補を、今のアバターへ引き継げるようにした。別の名前で置き直した・複製して元を消した・
  別のシーンへ移した、などで前の候補が画面に出なくなったとき、対象を選ぶと
  「前の候補が n 件残っています［引き継ぐ…］」と出る。一覧から選んだ候補を今のアバターへコピーする
  （元の候補は残る。上書きはしない。Ctrl+Z で戻せる）。
  元のアバターがシーンに残っている場合は案内しない（2 体置いても候補は混ざらない）
- 候補を Scene に表示したままシーンを保存したとき、保存の直前に現在値へ戻すようにした。
  これまでは候補の値がそのまま保存されていた（Prefab モードでの保存は対象外）
- VRChat SDK が入っているプロジェクトでは、ビルド（Build & Test / Build & Publish）の開始前にも
  現在値へ戻す。戻せなかったときはビルドを中止して理由を出す。
  SDK を参照するコードは別アセンブリ（`ShapePick.Editor.VRChat`）に分けてあり、
  SDK が無いプロジェクトではコンパイルされない（本体は引き続き SDK に依存しない）

## [1.0.0] - 2026-09-05

初回リリース（BOOTH「やよの作業場」）。

### Changed
- スロットの既定名を自動採番に変更（`候補1`・`候補2` …）。設定パネルの「スロット名」で
  接頭辞を変えると全 UI が追従する。個別に名前変更したスロットは影響を受けない
- UI 言語が English のとき、スロットの既定名を `Option 1`・`Option 2` … にした。
  接頭辞を自分で設定している場合はそちらが優先される

### Removed
- 登録のショートカット（`Ctrl+Shift+A` / `Ctrl+Shift+B`）を廃止した。Unity 標準の
  Add Component / Build Settings と同じキーだったため。Shortcut Manager にキーの割り当ては出ない
- 候補の表示中に Esc で現在値に戻す操作を廃止した。帯の［現在値に戻す］か
  「Sceneビューに表示」の［現在値］で戻す
- 0.1.0 までの既定名（`A案`・`B案`）は既定名のまま扱われ、設定の接頭辞に追従する

### Fixed
- 既に開いているウィンドウを Tools メニューから開き直したとき、Hierarchy の選択が
  すでに対象メッシュだと対象が空のままになる不具合
- 差分表の「この値にする」ボタンが 3 文字以上のスロット名を切っていた


## [0.1.0] - 2026-09-02

### Added
- P1 基盤: データモデル、RendererResolver、BlendShapeNameCache、SnapshotService（登録・適用・切替・liveBackup・Undo）、DiffCalculator、SnapshotSetRepository
- P2 最小 UI: 2 ペイン（TwoPaneSplitView）、スロットカード（ホバー操作）、表示切替 / 押している間 A案、差分表（MultiColumnListView）、ヒント行、トースト、初回チュートリアル、Ctrl+Shift+A / B、日本語・英語文言表
- P3 プレビュー: PreviewRenderer（PreviewRenderUtility、一時適用→描画→finally で復元）、Scene ビュー互換のカメラ操作と引き継ぎ、［顔に合わせる］、PNG サムネイルキャッシュ、dirty 駆動、ドラッグ中 256²
- P4 仕上げ: シェイプキータブ（使用中 / 全一覧、検索、カテゴリ折りたたみ、Inspector 同期、まばたき・リップシンク警告）、名前変更・メモ、設定パネル、保存失敗の赤帯と再試行、3.7 エラー処理テスト
- NUnit Edit Mode テスト（機能・エラー処理・性能 PF-01 / 03 / 05 / 07）
