using System;

namespace ShapePick.Data
{
    /// <summary>プレビューに描くオブジェクトのプリセット（FR-23）。</summary>
    public enum PreviewObjectPreset
    {
        /// <summary>アバターの全レンダラー（既定）。</summary>
        All = 0,

        /// <summary>対象メッシュ + Head（設定により Neck）配下のオブジェクト。</summary>
        HeadOnly = 1,

        /// <summary>対象メッシュだけ。</summary>
        TargetOnly = 2,

        /// <summary>一覧で個別に変更した状態。</summary>
        Custom = 3,
    }

    /// <summary>
    /// プレビュー表示オブジェクトの、既定（シーンでの表示状態）と異なる設定だけを保存する（FR-23）。
    /// 照合キーはアバター root からの Hierarchy 相対パス。
    /// </summary>
    [Serializable]
    public sealed class PreviewObjectState
    {
        public string path;
        public bool visible;

        public PreviewObjectState()
        {
        }

        public PreviewObjectState(string path, bool visible)
        {
            this.path = path;
            this.visible = visible;
        }
    }
}
