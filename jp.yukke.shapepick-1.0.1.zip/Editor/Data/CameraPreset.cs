using System;
using UnityEngine;

namespace ShapePick.Data
{
    /// <summary>
    /// 「既定の構図」をアバターに依存しない形で持つ（FR-07）。
    /// 注視点は基準点（Humanoid の Head ボーン、無ければレンダラー境界の上部）からのオフセットを
    /// アバターの向き・大きさで正規化して保存し、別のアバターにも同じ構図を適用できるようにする。
    /// </summary>
    [Serializable]
    public struct CameraPreset
    {
        /// <summary>アバター正面から見る向きを 0 とした水平回転（度）。</summary>
        public float yawFromFront;
        public float pitch;

        /// <summary>距離 ÷ アバターのスケール。</summary>
        public float distanceScaled;

        /// <summary>基準点から注視点へのオフセット（アバターのローカル軸、スケールで正規化）。</summary>
        public Vector3 pivotOffsetScaled;

        public float fov;
        public bool orthographic;

        /// <summary>組み込みの既定: 正面・透視・頭の上から胸元までが収まるバストアップ。</summary>
        public static CameraPreset BuiltIn => new CameraPreset
        {
            yawFromFront = 0f,
            pitch = 0f,
            distanceScaled = 0.60f,
            pivotOffsetScaled = new Vector3(0f, 0.068f, 0f),
            fov = 30f,
            orthographic = false,
        };

        /// <summary>今のカメラ状態を、基準点・向き・スケールに対する相対値として記録する。</summary>
        public static CameraPreset Capture(PreviewCameraState state, Vector3 anchor, Quaternion rootRotation, float scale)
        {
            scale = Mathf.Max(0.01f, scale);
            float frontYaw = rootRotation.eulerAngles.y + 180f;
            var localOffset = Quaternion.Inverse(rootRotation) * (state.pivot - anchor);
            return new CameraPreset
            {
                yawFromFront = Mathf.DeltaAngle(frontYaw, state.yaw),
                pitch = state.pitch,
                distanceScaled = state.distance / scale,
                pivotOffsetScaled = localOffset / scale,
                fov = state.fov,
                orthographic = state.orthographic,
            };
        }

        /// <summary>基準点・向き・スケールに当てはめてカメラ状態を作る。</summary>
        public PreviewCameraState Apply(Vector3 anchor, Quaternion rootRotation, float scale)
        {
            scale = Mathf.Max(0.01f, scale);
            float frontYaw = rootRotation.eulerAngles.y + 180f;
            return new PreviewCameraState
            {
                yaw = Mathf.Repeat(frontYaw + yawFromFront, 360f),
                pitch = Mathf.Clamp(pitch, -89f, 89f),
                distance = Mathf.Clamp(distanceScaled * scale, PreviewCameraState.MinDistance, PreviewCameraState.MaxDistance),
                pivot = anchor + rootRotation * (pivotOffsetScaled * scale),
                fov = Mathf.Clamp(fov <= 0f ? 30f : fov, 5f, 120f),
                orthographic = orthographic,
                initialized = true,
            };
        }

        public string ToJson() => JsonUtility.ToJson(this);

        public static bool TryParse(string json, out CameraPreset preset)
        {
            preset = default;
            if (string.IsNullOrWhiteSpace(json)) return false;
            try
            {
                preset = JsonUtility.FromJson<CameraPreset>(json);
                return preset.distanceScaled > 0f;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}
