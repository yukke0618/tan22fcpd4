using System;
using System.Collections.Generic;
using UnityEngine;

namespace ShapePick.Data
{
    /// <summary>ブレンドシェイプ 1 件の値。照合キーは name。</summary>
    [Serializable]
    public sealed class BlendShapeEntry
    {
        /// <summary>照合キー。メッシュ内で重複する名前は "名前#出現順" に正規化される（BlendShapeNameCache 参照）。</summary>
        public string name;

        /// <summary>ウェイト。通常 0..100 だが上限は持たない。</summary>
        public float weight;

        public BlendShapeEntry()
        {
        }

        public BlendShapeEntry(string name, float weight)
        {
            this.name = name;
            this.weight = weight;
        }
    }

    /// <summary>1 スロット分のスナップショット。対象メッシュが持つ全ブレンドシェイプを保存する。</summary>
    [Serializable]
    public sealed class BlendShapeSnapshot
    {
        /// <summary>GUID 文字列。登録（上書き）ごとに新しく振り直す。プレビューキャッシュのキーにも使う。</summary>
        public string id;

        /// <summary>表示名。既定は設定の接頭辞 + 番号（"候補1" / "候補2" …）。</summary>
        public string label;

        /// <summary>自由記述メモ。</summary>
        public string memo;

        /// <summary>登録日時 (DateTime.UtcNow.Ticks)。0 は未登録。</summary>
        public long createdAtUtc;

        /// <summary>整合性チェック用のメッシュ名。</summary>
        public string meshName;

        /// <summary>補助キー。メッシュがアセット由来ならそのアセット GUID、そうでなければ空。</summary>
        public string meshGuid;

        /// <summary>参考情報。登録時のレンダラーの Hierarchy パス。</summary>
        public string rendererPath;

        public List<BlendShapeEntry> entries = new List<BlendShapeEntry>();

        /// <summary>プレビュー画像。null 可。値から再生成できるキャッシュ扱い。</summary>
        public Texture2D previewCache;

        public bool IsRegistered => createdAtUtc != 0 && entries != null && entries.Count > 0;

        public DateTime CreatedAtLocal => createdAtUtc == 0
            ? default
            : new DateTime(createdAtUtc, DateTimeKind.Utc).ToLocalTime();

        /// <summary>値と登録情報を消して未登録状態に戻す。label と memo は残す。</summary>
        public void ClearValues()
        {
            id = null;
            createdAtUtc = 0;
            meshName = null;
            meshGuid = null;
            rendererPath = null;
            entries?.Clear();
            previewCache = null;
        }

        /// <summary>name → weight の辞書を作る。UI や検索用。ホットパスでは使わない。</summary>
        public Dictionary<string, float> ToDictionary()
        {
            var dict = new Dictionary<string, float>(entries?.Count ?? 0);
            if (entries == null) return dict;
            foreach (var e in entries)
            {
                if (e?.name != null && !dict.ContainsKey(e.name)) dict.Add(e.name, e.weight);
            }
            return dict;
        }
    }

    /// <summary>
    /// 並列プレビューのカメラ状態。左右で同一の値を使う（FR-06 / FR-07）。
    /// Scene ビューと同じ「注視点（pivot）を中心に回転・距離で拡縮・平行移動で pivot を動かす」モデル。
    /// 仕様 3.3 の offsetY は pivot（ワールド座標）に置き換えた。平行移動と Scene ビューからの引き継ぎに必要なため。
    /// </summary>
    [Serializable]
    public struct PreviewCameraState
    {
        public const float MinDistance = 0.02f;
        public const float MaxDistance = 50f;

        /// <summary>水平回転（度）。180 で +Z を向いたアバターの正面から見る。</summary>
        public float yaw;

        /// <summary>垂直回転（度）。正で上から見下ろす。</summary>
        public float pitch;

        /// <summary>注視点からカメラまでの距離（m）。</summary>
        public float distance;

        /// <summary>注視点（ワールド座標）。</summary>
        public Vector3 pivot;

        /// <summary>垂直画角（度）。Scene ビューから引き継ぐ。</summary>
        public float fov;

        /// <summary>一度でも「顔に合わせる」等で初期化されたか。false なら対象に合わせて初期化する。</summary>
        public bool initialized;

        /// <summary>平行投影（Scene ビューの Iso）。false なら透視投影（Persp）。</summary>
        public bool orthographic;

        public static PreviewCameraState Default => new PreviewCameraState
        {
            yaw = 180f,
            pitch = 0f,
            distance = 0.6f,
            pivot = Vector3.zero,
            fov = 30f,
            initialized = false,
            orthographic = false,
        };

        public Quaternion Rotation => Quaternion.Euler(pitch, yaw, 0f);
        public Vector3 Forward => Rotation * Vector3.forward;
        public Vector3 Position => pivot - Forward * distance;

        /// <summary>平行投影の半高さ。透視投影と同じ距離で同じ範囲が映るように画角から決める（Scene ビューと同じ換算）。</summary>
        public float OrthographicSize => distance * Mathf.Tan(Mathf.Clamp(fov, 5f, 120f) * 0.5f * Mathf.Deg2Rad);

        /// <summary>注視点を中心に回転する（右ドラッグ / Alt + 左ドラッグ）。</summary>
        public void Orbit(float deltaYaw, float deltaPitch)
        {
            yaw = Mathf.Repeat(yaw + deltaYaw, 360f);
            pitch = Mathf.Clamp(pitch + deltaPitch, -89f, 89f);
        }

        /// <summary>距離を倍率で変える（ホイール）。</summary>
        public void Zoom(float factor)
        {
            distance = Mathf.Clamp(distance * factor, MinDistance, MaxDistance);
        }

        /// <summary>画面上のピクセル移動量ぶん注視点を平行移動する（中ドラッグ）。viewportHeight はプレビューの高さ（px）。</summary>
        public void Pan(Vector2 deltaPixels, float viewportHeight)
        {
            if (viewportHeight <= 0f) return;
            float worldPerPixel = 2f * distance * Mathf.Tan(fov * 0.5f * Mathf.Deg2Rad) / viewportHeight;
            var r = Rotation;
            pivot += (r * Vector3.right) * (-deltaPixels.x * worldPerPixel) + (r * Vector3.up) * (deltaPixels.y * worldPerPixel);
        }

        /// <summary>カメラの位置・回転・距離から状態を作る（Scene ビューの引き継ぎ用）。</summary>
        public static PreviewCameraState FromLookAt(Vector3 pivot, Quaternion rotation, float distance, float fov, bool orthographic = false)
        {
            var e = rotation.eulerAngles;
            float p = e.x > 180f ? e.x - 360f : e.x;
            return new PreviewCameraState
            {
                yaw = e.y,
                pitch = Mathf.Clamp(p, -89f, 89f),
                distance = Mathf.Clamp(distance, MinDistance, MaxDistance),
                pivot = pivot,
                fov = Mathf.Clamp(fov, 5f, 120f),
                initialized = true,
                orthographic = orthographic,
            };
        }

        public override string ToString()
        {
            return $"yaw={yaw:0.#} pitch={pitch:0.#} distance={distance:0.###} pivot=({pivot.x:0.###}, {pivot.y:0.###}, {pivot.z:0.###}) fov={fov:0.#} {(orthographic ? "Iso" : "Persp")}";
        }
    }
}
