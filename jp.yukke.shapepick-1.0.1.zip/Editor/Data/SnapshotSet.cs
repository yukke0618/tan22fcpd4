using System.Collections.Generic;
using UnityEngine;

namespace ShapePick.Data
{
    /// <summary>
    /// シーン上の 1 個体（対象 SkinnedMeshRenderer の GameObject）1 つ分のスナップショット集合。
    /// 保存先: Assets/ShapePick/Snapshots/(アバター名)_(対象名).asset（SnapshotSetRepository が管理）。
    ///
    /// 紐付けはメッシュアセットではなく個体で行う。同じアバターを 2 体置いたとき
    /// （Shinano と Shinano (1)）に候補・カメラ・プレビュー表示状態を分けるため。
    /// meshName / meshGuid は「別メッシュに適用しようとしている」警告の材料としてだけ持ち、
    /// セットの選択には使わない。
    /// </summary>
    public sealed class SnapshotSet : ScriptableObject
    {
        public const int MaxSlots = 8;
        public const int SlotA = 0;
        public const int SlotB = 1;

        /// <summary>UI に出すスロット枠の上限（yayo 依頼 5: 候補5 まで）。データ上は MaxSlots まで持てる。</summary>
        public const int VisibleSlotLimit = 5;

        /// <summary>プレビュー・差分の「現在値」を表すソース番号（スロット番号は 0 以上）。</summary>
        public const int LiveSource = -1;

        /// <summary>UI に出す枠の数。最低 1（yayo: 1 枚は確定で表示）、既に確保したスロット数まで（上限 VisibleSlotLimit）。</summary>
        public int VisibleSlotCount => Mathf.Clamp(slots != null ? slots.Count : 0, 1, VisibleSlotLimit);

        /// <summary>枠を 1 つ減らせるか（最低 1 枠は残す）。</summary>
        public bool CanRemoveSlot(int slotIndex) => slots != null && slots.Count > 1 && slotIndex >= 0 && slotIndex < slots.Count;

        /// <summary>
        /// 枠を取り除く。後ろの枠は前に詰まり、既定名のままだった枠は新しい番号の既定名に付け直す
        /// （「候補5」が 2 枚目に来たら「候補2」に。ユーザーが付けた名前はそのまま）。
        /// </summary>
        public bool RemoveSlot(int slotIndex)
        {
            if (!CanRemoveSlot(slotIndex)) return false;
            slots.RemoveAt(slotIndex);
            for (int i = slotIndex; i < slots.Count; i++)
            {
                var s = slots[i];
                if (s != null && IsBuiltInDefaultLabel(s.label, i + 1)) s.label = DefaultLabel(i);
            }
            return true;
        }

        /// <summary>登録済みスロットの番号を昇順で返す。</summary>
        public void GetRegisteredSlots(List<int> result)
        {
            result.Clear();
            if (slots == null) return;
            for (int i = 0; i < slots.Count; i++)
            {
                if (slots[i] != null && slots[i].IsRegistered) result.Add(i);
            }
        }

        public string meshName;
        public string meshGuid;

        /// <summary>
        /// 紐付け先（対象 SkinnedMeshRenderer の GameObject）の GlobalObjectId 文字列。本命の識別子。
        /// 未保存シーンでは文字列から復元できないので空になり、そのときは targetPath が受け持つ。
        /// </summary>
        public string targetGlobalId;

        /// <summary>保険。紐付け先のシーン内フルパス（"Wrapper/Shinano (1)/Body"）。</summary>
        public string targetPath;

        /// <summary>紐付け先が属するシーンのアセットパス。別シーンの同名パスを拾わないための絞り込みに使う。</summary>
        public string targetScene;

        /// <summary>表示用のアバター名（「適用先」の表示と引き継ぎ提示に使う）。</summary>
        public string avatarName;

        /// <summary>
        /// このセットへ引き継いだ、元の候補の id（BlendShapeSnapshot.id）。
        /// 引き継ぎはコピーで、元のセットは残る。引き継ぎ済みの候補を何度も提示しないために覚えておく。
        /// 候補ごとに覚えるので、一部だけ引き継いだときは残りを後から引き継げる。
        /// </summary>
        public List<string> adoptedFrom = new List<string>();

        /// <summary>index 0 = A, 1 = B, …。要素は常に非 null（未登録は IsRegistered == false で表す）。</summary>
        public List<BlendShapeSnapshot> slots = new List<BlendShapeSnapshot>();

        public PreviewCameraState camera = PreviewCameraState.Default;

        /// <summary>FR-23: 既定と異なる表示状態だけを持つ（path → visible）。</summary>
        public List<PreviewObjectState> previewObjects = new List<PreviewObjectState>();

        public PreviewObjectPreset previewPreset = PreviewObjectPreset.All;

        /// <summary>「頭まわり」プリセットに Neck 配下を含めるか。</summary>
        public bool previewIncludeNeck = true;

        /// <summary>path に対する上書きを返す。無ければ null。</summary>
        public bool? GetPreviewOverride(string path)
        {
            if (previewObjects == null || string.IsNullOrEmpty(path)) return null;
            for (int i = 0; i < previewObjects.Count; i++)
            {
                var s = previewObjects[i];
                if (s != null && s.path == path) return s.visible;
            }
            return null;
        }

        /// <summary>path の上書きを設定する。visible が null なら上書きを消す。</summary>
        public void SetPreviewOverride(string path, bool? visible)
        {
            if (string.IsNullOrEmpty(path)) return;
            previewObjects ??= new List<PreviewObjectState>();
            for (int i = 0; i < previewObjects.Count; i++)
            {
                var s = previewObjects[i];
                if (s == null || s.path != path) continue;
                if (visible.HasValue) s.visible = visible.Value;
                else previewObjects.RemoveAt(i);
                return;
            }
            if (visible.HasValue) previewObjects.Add(new PreviewObjectState(path, visible.Value));
        }

        public void ClearPreviewOverrides()
        {
            previewObjects?.Clear();
        }

        /// <summary>組み込みで既定として扱う接頭辞。接頭辞を切り替えても、以前の既定名をユーザーが付けた名前と誤認しないため。</summary>
        private static readonly string[] BuiltInLabelPrefixes = { "候補", "案", "スロット", "Option", "Slot", "Draft" };

        /// <summary>既定の名前。設定の接頭辞に 1 から始まる番号を付ける（候補1・候補2 … / Option 1・Option 2 …）。</summary>
        public static string DefaultLabel(int slotIndex)
        {
            var prefix = ShapePickSettings.SlotLabelPrefix;
            return prefix + LabelSeparator(prefix) + ((slotIndex < 0 ? 0 : slotIndex) + 1);
        }

        /// <summary>
        /// 接頭辞と番号のあいだの区切り。半角英数字で終わる接頭辞は数字と直結すると読みにくい（Option1）ので空白を入れる。
        /// 日本語の接頭辞は詰める（候補1）。
        /// </summary>
        private static string LabelSeparator(string prefix)
        {
            if (string.IsNullOrEmpty(prefix)) return string.Empty;
            char last = prefix[prefix.Length - 1];
            return last < 128 && char.IsLetterOrDigit(last) ? " " : string.Empty;
        }

        /// <summary>既定名のままか（過去の既定名 "A案" や、別の接頭辞の既定名も含む）。ユーザーが付けた名前と区別するために使う。</summary>
        public static bool IsBuiltInDefaultLabel(string label, int slotIndex)
        {
            if (string.IsNullOrEmpty(label)) return true;
            if (label == DefaultLabel(slotIndex)) return true;
            if (slotIndex < 0 || slotIndex >= MaxSlots) return false;
            // 0.1.0 までの既定名
            if (label == (char)('A' + slotIndex) + "案") return true;
            var number = (slotIndex + 1).ToString();
            foreach (var prefix in BuiltInLabelPrefixes)
            {
                // 空白の有無は問わない（"Option 1" も "Option1" も既定名として扱う）
                if (label == prefix + number || label == prefix + " " + number) return true;
            }
            return false;
        }

        /// <summary>
        /// UI に出す名前。ユーザーが名前変更していればそれ、既定名のままなら設定の既定名（設定を変えると全 UI が追従する）。
        /// </summary>
        public string DisplayLabel(int slotIndex)
        {
            var slot = GetSlot(slotIndex);
            var label = slot != null ? slot.label : null;
            return IsBuiltInDefaultLabel(label, slotIndex) ? DefaultLabel(slotIndex) : label;
        }

        public static bool IsValidSlotIndex(int slotIndex) => slotIndex >= 0 && slotIndex < MaxSlots;

        /// <summary>存在するスロットを返す。無ければ null。</summary>
        public BlendShapeSnapshot GetSlot(int slotIndex)
        {
            if (slots == null || slotIndex < 0 || slotIndex >= slots.Count) return null;
            return slots[slotIndex];
        }

        /// <summary>指定インデックスまでスロットを確保して返す。</summary>
        public BlendShapeSnapshot EnsureSlot(int slotIndex)
        {
            if (!IsValidSlotIndex(slotIndex))
            {
                throw new System.ArgumentOutOfRangeException(
                    nameof(slotIndex), slotIndex, "スロット番号は 0.." + (MaxSlots - 1) + " の範囲");
            }

            slots ??= new List<BlendShapeSnapshot>();
            while (slots.Count <= slotIndex)
            {
                slots.Add(new BlendShapeSnapshot { label = DefaultLabel(slots.Count) });
            }

            var slot = slots[slotIndex];
            if (slot == null)
            {
                slot = new BlendShapeSnapshot { label = DefaultLabel(slotIndex) };
                slots[slotIndex] = slot;
            }
            if (string.IsNullOrEmpty(slot.label)) slot.label = DefaultLabel(slotIndex);
            return slot;
        }

        public bool IsSlotRegistered(int slotIndex)
        {
            var slot = GetSlot(slotIndex);
            return slot != null && slot.IsRegistered;
        }

        public int RegisteredSlotCount
        {
            get
            {
                if (slots == null) return 0;
                int n = 0;
                foreach (var s in slots)
                {
                    if (s != null && s.IsRegistered) n++;
                }
                return n;
            }
        }

        /// <summary>
        /// このセットが指定メッシュのものかを判定する。
        /// GUID が双方にあれば GUID + 名前で厳密比較、どちらかが無ければ名前のみで比較する。
        /// セットの選択には使わない（個体で紐付ける）。引き継ぎ候補の提示など、目安として使う。
        /// </summary>
        public bool MatchesMesh(string guid, string name)
        {
            if (meshName != name) return false;
            if (string.IsNullOrEmpty(guid) || string.IsNullOrEmpty(meshGuid)) return true;
            return meshGuid == guid;
        }

        /// <summary>紐付け先の識別子が一致するか。識別子を持たないセットは決して一致しない。</summary>
        public bool MatchesGlobalId(string globalId)
        {
            return !string.IsNullOrEmpty(globalId) && targetGlobalId == globalId;
        }

        /// <summary>
        /// 保険のパスが一致するか。別シーンにある同名パスを拾わないよう、シーンの一致も求める。
        /// 未保存シーン同士（どちらも空）は同じシーンとみなす。
        /// </summary>
        public bool MatchesPath(string path, string scene)
        {
            if (string.IsNullOrEmpty(path) || targetPath != path) return false;
            return (targetScene ?? string.Empty) == (scene ?? string.Empty);
        }

        /// <summary>紐付け情報を今の個体に貼り直す。何か変わったときだけ true を返す。</summary>
        /// <remarks>
        /// globalId は空のときに上書きしない。未保存シーンで一時的に取れなくなっても、
        /// 既に持っている識別子を捨てないため。
        /// </remarks>
        public bool UpdateBinding(string globalId, string path, string scene, string avatar)
        {
            bool changed = false;
            if (!string.IsNullOrEmpty(globalId) && targetGlobalId != globalId)
            {
                targetGlobalId = globalId;
                changed = true;
            }
            if (targetPath != path)
            {
                targetPath = path;
                changed = true;
            }
            if ((targetScene ?? string.Empty) != (scene ?? string.Empty))
            {
                targetScene = scene;
                changed = true;
            }
            if ((avatarName ?? string.Empty) != (avatar ?? string.Empty))
            {
                avatarName = avatar;
                changed = true;
            }
            return changed;
        }
    }
}
