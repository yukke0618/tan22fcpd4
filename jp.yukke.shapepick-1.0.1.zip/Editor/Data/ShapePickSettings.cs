using UnityEditor;

namespace ShapePick.Data
{
    /// <summary>マシン固有の設定。EditorPrefs に保存する（スナップショット本体はアセット側）。</summary>
    public static class ShapePickSettings
    {
        private const string Prefix = "ShapePick.";

        public const float DefaultDiffThreshold = 0.01f;
        public const int DefaultPreviewResolution = 512;
        public const string DefaultLanguage = "ja";

        /// <summary>差分表に表示する最小の |差|。既定 0.01。</summary>
        public static float DiffThreshold
        {
            get => EditorPrefs.GetFloat(Prefix + "DiffThreshold", DefaultDiffThreshold);
            set => EditorPrefs.SetFloat(Prefix + "DiffThreshold", value < 0f ? 0f : value);
        }

        /// <summary>プレビュー解像度（256 / 512 / 1024）。</summary>
        public static int PreviewResolution
        {
            get => EditorPrefs.GetInt(Prefix + "PreviewResolution", DefaultPreviewResolution);
            set => EditorPrefs.SetInt(Prefix + "PreviewResolution", value);
        }

        /// <summary>UI 言語コード。"ja" / "en"。</summary>
        public static string Language
        {
            get => EditorPrefs.GetString(Prefix + "Language", DefaultLanguage);
            set => EditorPrefs.SetString(Prefix + "Language", string.IsNullOrEmpty(value) ? DefaultLanguage : value);
        }

        /// <summary>ウィンドウを閉じるときに「現在値」へ自動復帰する。既定 ON。</summary>
        public static bool AutoRestoreOnClose
        {
            get => EditorPrefs.GetBool(Prefix + "AutoRestoreOnClose", true);
            set => EditorPrefs.SetBool(Prefix + "AutoRestoreOnClose", value);
        }

        public const string DefaultSlotLabelPrefixJa = "候補";
        public const string DefaultSlotLabelPrefixEn = "Option";

        /// <summary>
        /// 言語ごとの既定の接頭辞。日本語は「候補」（候補1・候補2 …）、英語は "Option"（Option 1・Option 2 …）。
        /// ユーザーが設定パネルで接頭辞を変えていないあいだは、言語の切り替えにこちらが追従する。
        /// </summary>
        public static string DefaultSlotLabelPrefix => Language == "en" ? DefaultSlotLabelPrefixEn : DefaultSlotLabelPrefixJa;

        private const string SlotLabelPrefixKey = Prefix + "SlotLabelPrefix";

        /// <summary>
        /// スロット名の接頭辞。実際の名前は末尾に 1 から始まる番号が付く（候補1・候補2 … / Option 1・Option 2 …）。
        /// ボタン・帯・ヒント・差分表の見出しなど UI 全体に使う。個別に名前変更したスロットには影響しない。
        /// 既定と同じ値は保存しない。保存してしまうと言語を切り替えても既定が追従しなくなるため。
        /// </summary>
        public static string SlotLabelPrefix
        {
            get
            {
                var v = EditorPrefs.GetString(SlotLabelPrefixKey, string.Empty);
                return string.IsNullOrWhiteSpace(v) ? DefaultSlotLabelPrefix : v.Trim();
            }
            set
            {
                var v = (value ?? string.Empty).Trim();
                if (v.Length == 0 || v == DefaultSlotLabelPrefixJa || v == DefaultSlotLabelPrefixEn)
                {
                    EditorPrefs.DeleteKey(SlotLabelPrefixKey);
                }
                else
                {
                    EditorPrefs.SetString(SlotLabelPrefixKey, v);
                }
            }
        }

        /// <summary>
        /// ［顔に合わせる］と初期表示に使う既定の構図（CameraPreset の JSON）。空なら組み込み（正面・透視・バストアップ）。
        /// ［この構図を既定に］で Scene ビュー等から取り込んだ構図を保存する。
        /// </summary>
        public static string DefaultCameraPresetJson
        {
            get => EditorPrefs.GetString(Prefix + "DefaultCameraPreset", string.Empty);
            set => EditorPrefs.SetString(Prefix + "DefaultCameraPreset", value ?? string.Empty);
        }

        public static CameraPreset DefaultCameraPreset =>
            CameraPreset.TryParse(DefaultCameraPresetJson, out var p) ? p : CameraPreset.BuiltIn;

        public const string DefaultCategorySeparator = "_";

        /// <summary>シェイプキー一覧をカテゴリに折りたたむ区切り文字（FR-20）。空なら折りたたまない。</summary>
        public static string CategorySeparator
        {
            get => EditorPrefs.GetString(Prefix + "CategorySeparator", DefaultCategorySeparator);
            set => EditorPrefs.SetString(Prefix + "CategorySeparator", value ?? string.Empty);
        }

        public const string DefaultBlinkPattern = @"^vrc\.(blink|lowerlid)";
        public const string DefaultLipSyncPattern = @"^vrc\.v_";

        /// <summary>まばたきに使われるシェイプキー名の正規表現（FR-22）。</summary>
        public static string BlinkPattern
        {
            get => EditorPrefs.GetString(Prefix + "BlinkPattern", DefaultBlinkPattern);
            set => EditorPrefs.SetString(Prefix + "BlinkPattern", value ?? string.Empty);
        }

        /// <summary>リップシンクに使われるシェイプキー名の正規表現（FR-22）。</summary>
        public static string LipSyncPattern
        {
            get => EditorPrefs.GetString(Prefix + "LipSyncPattern", DefaultLipSyncPattern);
            set => EditorPrefs.SetString(Prefix + "LipSyncPattern", value ?? string.Empty);
        }
    }
}
