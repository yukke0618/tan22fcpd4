using System;
using System.Collections.Generic;
using ShapePick.Data;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>表示オブジェクト一覧の 1 行分（FR-23）。UI 表示用の読み取り専用データ。</summary>
    public sealed class PreviewObjectRow
    {
        public string Path;
        public string DisplayName;
        public bool Visible;
        public bool IsTarget;
        public bool HeadAttached;
        public bool NeckAttached;
        public bool SceneHidden;
        /// <summary>まとまり（衣装など）。本体は空文字。</summary>
        public string GroupPath = string.Empty;
        public string GroupName = string.Empty;
    }

    /// <summary>
    /// 左ペイン: A 案と比較対象のプレビューを上下（幅が広いときは左右）に並べる（FR-06）。
    /// カメラ操作は Scene ビューと同じ（右ドラッグ / Alt+左ドラッグで回転、中ドラッグで平行移動、ホイールで拡縮）で、
    /// どちらの画像を操作しても同じカメラに反映される（FR-07）。描画そのものは PreviewCoordinator が行う。
    /// </summary>
    public sealed class PreviewPane : VisualElement
    {
        private const float SideBySideMinWidth = 640f;
        private const float OrbitDegreesPerPixel = 0.35f;
        private const float ZoomStep = 1.12f;

        private readonly VisualElement _images;
        private readonly Image _leftImage;
        private readonly Image _rightImage;
        private readonly DropdownField _leftCaption;
        private readonly DropdownField _rightCaption;
        private readonly List<int> _sourceIds = new List<int>();
        private bool _suppressSourceEvents;

        /// <summary>プレビューに出すものが変わった（0 = 上/左, 1 = 下/右, ソース番号: スロット番号または SnapshotSet.LiveSource）。</summary>
        public event Action<int, int> SourceChanged;
        private readonly Label _placeholder;
        private readonly Button _fitFace;
        private readonly Button _fromSceneView;
        private readonly Button _recapture;
        private readonly Button _projection;
        private readonly Button _setDefault;
        private bool _orthographic;

        public event Action ProjectionToggleRequested;
        public event Action SetDefaultFramingRequested;

        private int _dragButton = -1;
        private bool _dragging;

        // 表示オブジェクト（FR-23）
        private const string PrefCameraHintSeen = "ShapePick.CameraHintSeen";
        private readonly VisualElement _objectsSection;
        private readonly Label _objectsTitle;
        private readonly Label _cameraHint;
        private readonly Foldout _objectsFoldout;
        private readonly Button _presetAll;
        private readonly Button _presetHead;
        private readonly Button _presetTarget;
        private readonly ScrollView _objectList;
        private bool _suppressObjectEvents;
        /// <summary>開いているまとまり。一覧を作り直しても開閉を保つ。本体（空文字）は最初から開いておく。</summary>
        private readonly HashSet<string> _expandedGroups = new HashSet<string> { string.Empty };

        public event Action FitFaceRequested;
        public event Action FromSceneViewRequested;
        public event Action RecaptureRequested;

        /// <summary>プリセットが選ばれた（FR-23）。</summary>
        public event Action<PreviewObjectPreset> PresetRequested;

        /// <summary>「Neck を含める」が変わった。</summary>
        /// <summary>個別のオブジェクトのチェックが変わった（path, visible）。</summary>
        public event Action<string, bool> ObjectVisibilityChanged;

        /// <summary>まとまり（衣装）の見出しのチェックが変わった（中身の path, visible）。</summary>
        public event Action<IReadOnlyList<string>, bool> ObjectGroupVisibilityChanged;

        /// <summary>回転要求（ヨー差分, ピッチ差分）度。</summary>
        public event Action<float, float> OrbitRequested;

        /// <summary>平行移動要求（画面ピクセル差分, ビューポート高さ px）。</summary>
        public event Action<Vector2, float> PanRequested;

        /// <summary>拡縮要求（距離の倍率）。</summary>
        public event Action<float> ZoomRequested;

        /// <summary>ドラッグ開始 / 終了。ドラッグ中は低解像度で描く（PF-10）。</summary>
        public event Action<bool> DragStateChanged;

        public bool IsDragging => _dragging;

        /// <summary>画像 1 枚の表示サイズ（px、pixelsPerPoint 込み）。解像度の選択に使う。</summary>
        public float SurfacePixelWidth => _leftImage.resolvedStyle.width * (float)UnityEditor.EditorGUIUtility.pixelsPerPoint;
        public float SurfacePointHeight => _leftImage.resolvedStyle.height;

        public PreviewPane()
        {
            AddToClassList("shapepick-preview");

            _images = new VisualElement();
            _images.AddToClassList("shapepick-preview__images");
            Add(_images);

            (_leftImage, _leftCaption) = MakeBox("A");
            (_rightImage, _rightCaption) = MakeBox(L.T(L.Key.PreviewLive));
            AttachCameraHandlers(_leftImage);
            AttachCameraHandlers(_rightImage);

            _placeholder = new Label(L.T(L.Key.PreviewNotReady));
            _placeholder.AddToClassList("shapepick-preview__placeholder");
            Add(_placeholder);

            var toolbar = new VisualElement();
            toolbar.AddToClassList("shapepick-preview__toolbar");
            _fitFace = new Button(() => FitFaceRequested?.Invoke());
            _fromSceneView = new Button(() => FromSceneViewRequested?.Invoke());
            _projection = new Button(() => ProjectionToggleRequested?.Invoke());
            _projection.AddToClassList("shapepick-preview__projection");
            _setDefault = new Button(() => SetDefaultFramingRequested?.Invoke());
            _recapture = new Button(() => RecaptureRequested?.Invoke());
            toolbar.Add(_fitFace);
            toolbar.Add(_fromSceneView);
            toolbar.Add(_projection);
            toolbar.Add(_setDefault);
            toolbar.Add(_recapture);
            Add(toolbar);

            // 表示オブジェクト（FR-23）: 見出しとプリセットは常時見せ、個別チェックの一覧だけ折りたたむ（プレビューの面積を守る）
            _objectsSection = new VisualElement();
            _objectsSection.AddToClassList("shapepick-objects");
            var header = new VisualElement();
            header.AddToClassList("shapepick-objects__header");
            _objectsTitle = new Label();
            _objectsTitle.AddToClassList("shapepick-objects__title");
            header.Add(_objectsTitle);
            _objectsSection.Add(header);
            var presets = new VisualElement();
            presets.AddToClassList("shapepick-objects__presets");
            _presetAll = new Button(() => PresetRequested?.Invoke(PreviewObjectPreset.All));
            _presetHead = new Button(() => PresetRequested?.Invoke(PreviewObjectPreset.HeadOnly));
            _presetTarget = new Button(() => PresetRequested?.Invoke(PreviewObjectPreset.TargetOnly));
            foreach (var b in new[] { _presetAll, _presetHead, _presetTarget }) b.AddToClassList("shapepick-objects__preset");
            presets.Add(_presetAll);
            presets.Add(_presetHead);
            presets.Add(_presetTarget);
            _objectsSection.Add(presets);
            _objectsFoldout = new Foldout { value = false };
            _objectsFoldout.AddToClassList("shapepick-objects__list-foldout");
            _objectList = new ScrollView(ScrollViewMode.Vertical) { horizontalScrollerVisibility = ScrollerVisibility.Hidden };
            _objectList.AddToClassList("shapepick-objects__list");
            _objectsFoldout.Add(_objectList);
            _objectsSection.Add(_objectsFoldout);
            Add(_objectsSection);

            // カメラ操作の案内: 初めて操作するまで左のプレビューに薄く重ねる
            _cameraHint = new Label();
            _cameraHint.AddToClassList("shapepick-camera-hint");
            _cameraHint.pickingMode = PickingMode.Ignore;
            _leftImage.parent.Add(_cameraHint);
            _cameraHint.style.display = UnityEditor.EditorPrefs.GetBool(PrefCameraHintSeen, false) ? DisplayStyle.None : DisplayStyle.Flex;

            RegisterCallback<GeometryChangedEvent>(_ => UpdateLayout());
            SetRenderingAvailable(false);
            RefreshTexts();
        }

        /// <summary>表示オブジェクト一覧を作り直す。rows は対象 → 頭 → 首 → その他の順で渡す。</summary>
        public void SetObjects(IReadOnlyList<PreviewObjectRow> rows, PreviewObjectPreset preset, bool includeNeck)
        {
            _suppressObjectEvents = true;
            try
            {
                _objectList.Clear();
                int shown = 0, total = 0, sceneHidden = 0;
                if (rows != null)
                {
                    foreach (var r in rows)
                    {
                        total++;
                        if (r.Visible) shown++;
                        if (r.SceneHidden && !r.Visible) sceneHidden++;
                    }
                    BuildGroupedRows(rows);
                }
                // 「すべて」なのに 19 / 20 と出ると足りないように見えるので、シーンで非表示の数を添える
                string count = sceneHidden > 0
                    ? L.F(L.Key.PreviewObjectsCountHidden, shown, total, sceneHidden)
                    : L.F(L.Key.PreviewObjectsCount, shown, total);
                _objectsTitle.text = L.T(L.Key.PreviewObjectsSection) + "  " + count;
                _objectsFoldout.text = L.T(L.Key.PreviewObjectsList);
                _presetAll.EnableInClassList("shapepick-toggle--on", preset == PreviewObjectPreset.All);
                _presetHead.EnableInClassList("shapepick-toggle--on", preset == PreviewObjectPreset.HeadOnly);
                _presetTarget.EnableInClassList("shapepick-toggle--on", preset == PreviewObjectPreset.TargetOnly);
                _objectsSection.style.display = total > 0 ? DisplayStyle.Flex : DisplayStyle.None;
            }
            finally
            {
                _suppressObjectEvents = false;
            }
        }

        /// <summary>
        /// 行をまとまりごとに並べる（yayo 依頼 9/16: 衣装ごとにオンオフしやすく）。
        /// 2 つ以上の中身があるまとまりは見出し（開閉・まとめてチェック・件数）を付ける。1 つだけなら行をそのまま出す。
        /// </summary>
        private void BuildGroupedRows(IReadOnlyList<PreviewObjectRow> rows)
        {
            var order = new List<string>();
            var members = new Dictionary<string, List<PreviewObjectRow>>();
            foreach (var r in rows)
            {
                string key = r.GroupPath ?? string.Empty;
                if (!members.TryGetValue(key, out var list))
                {
                    list = new List<PreviewObjectRow>();
                    members.Add(key, list);
                    order.Add(key);
                }
                list.Add(r);
            }

            foreach (var key in order)
            {
                var list = members[key];
                if (list.Count < 2)
                {
                    foreach (var r in list) _objectList.Add(MakeObjectRow(r, false));
                    continue;
                }

                var paths = new List<string>();
                int visible = 0;
                foreach (var r in list)
                {
                    if (r.IsTarget) continue;
                    paths.Add(r.Path);
                    if (r.Visible) visible++;
                }

                bool expanded = _expandedGroups.Contains(key);
                var body = new VisualElement();
                body.AddToClassList("shapepick-object-group__body");
                body.style.display = expanded ? DisplayStyle.Flex : DisplayStyle.None;
                foreach (var r in list) body.Add(MakeObjectRow(r, true));

                var header = new VisualElement();
                header.AddToClassList("shapepick-object-group");

                var arrow = new Label(expanded ? "▼" : "▶");
                arrow.AddToClassList("shapepick-object-group__arrow");
                header.Add(arrow);

                var toggle = new Toggle { value = paths.Count > 0 && visible == paths.Count, tooltip = L.T(L.Key.TipObjectGroup) };
                toggle.showMixedValue = visible > 0 && visible < paths.Count;
                toggle.AddToClassList("shapepick-object-row__toggle");
                toggle.SetEnabled(paths.Count > 0);
                toggle.RegisterValueChangedCallback(evt =>
                {
                    if (_suppressObjectEvents) return;
                    // 一部だけ表示のときに押したら、まず全部表示にする
                    bool on = toggle.showMixedValue || evt.newValue;
                    ObjectGroupVisibilityChanged?.Invoke(paths, on);
                });
                header.Add(toggle);

                string title = string.IsNullOrEmpty(key) ? L.T(L.Key.PreviewObjectsGroupBase) : list[0].GroupName;
                var name = new Label(title) { tooltip = string.IsNullOrEmpty(key) ? null : key };
                name.AddToClassList("shapepick-object-group__name");
                header.Add(name);

                var count = new Label(visible + " / " + paths.Count);
                count.AddToClassList("shapepick-object-group__count");
                header.Add(count);

                // 見出しの名前か矢印を押すと開閉（チェックボックスは切替だけ）
                void ToggleExpand()
                {
                    bool open = body.style.display == DisplayStyle.None;
                    body.style.display = open ? DisplayStyle.Flex : DisplayStyle.None;
                    arrow.text = open ? "▼" : "▶";
                    if (open) _expandedGroups.Add(key); else _expandedGroups.Remove(key);
                }
                arrow.RegisterCallback<ClickEvent>(_ => ToggleExpand());
                name.RegisterCallback<ClickEvent>(_ => ToggleExpand());

                _objectList.Add(header);
                _objectList.Add(body);
            }
        }

        private VisualElement MakeObjectRow(PreviewObjectRow r, bool indented)
        {
            var row = new VisualElement();
            row.AddToClassList("shapepick-object-row");
            row.EnableInClassList("shapepick-object-row--indented", indented);

            var toggle = new Toggle { value = r.Visible };
            toggle.AddToClassList("shapepick-object-row__toggle");
            toggle.SetEnabled(!r.IsTarget);
            string path = r.Path;
            toggle.RegisterValueChangedCallback(evt =>
            {
                if (!_suppressObjectEvents) ObjectVisibilityChanged?.Invoke(path, evt.newValue);
            });
            row.Add(toggle);

            var name = new Label(r.DisplayName) { tooltip = r.Path };
            name.AddToClassList("shapepick-object-row__name");
            name.EnableInClassList("shapepick-object-row__name--hidden", r.SceneHidden && !r.Visible);
            row.Add(name);

            if (r.IsTarget) row.Add(MakeTag(L.T(L.Key.TagTarget), "shapepick-tag--target"));
            else if (r.HeadAttached) row.Add(MakeTag(L.T(L.Key.TagHead), "shapepick-tag--head"));
            else if (r.NeckAttached) row.Add(MakeTag(L.T(L.Key.TagNeck), "shapepick-tag--neck"));
            if (r.SceneHidden) row.Add(MakeTag(L.T(L.Key.TagSceneHidden), "shapepick-tag--muted"));
            return row;
        }

        private static Label MakeTag(string text, string cls)
        {
            var l = new Label(text);
            l.AddToClassList("shapepick-tag");
            l.AddToClassList(cls);
            return l;
        }

        private (Image, DropdownField) MakeBox(string caption)
        {
            var box = new VisualElement();
            box.AddToClassList("shapepick-preview__box");
            var img = new Image { scaleMode = ScaleMode.ScaleToFit };
            img.AddToClassList("shapepick-preview__image");
            img.tooltip = L.T(L.Key.TipPreviewCamera);
            // 名前はドロップダウン: 押すと候補 / 現在値を選べる（yayo 依頼 2）
            var cap = new DropdownField(new List<string> { caption }, 0);
            cap.AddToClassList("shapepick-preview__caption");
            int pane = _images.childCount;
            cap.RegisterValueChangedCallback(_ =>
            {
                if (_suppressSourceEvents) return;
                int i = cap.index;
                if (i >= 0 && i < _sourceIds.Count) SourceChanged?.Invoke(pane, _sourceIds[i]);
            });
            box.Add(img);
            box.Add(cap);
            _images.Add(box);
            return (img, cap);
        }

        /// <summary>上下のプレビューに出せる選択肢と現在の選択を設定する。ids は choices と同じ並び。</summary>
        public void SetSources(IReadOnlyList<string> choices, IReadOnlyList<int> ids, int top, int bottom)
        {
            _suppressSourceEvents = true;
            try
            {
                _sourceIds.Clear();
                _sourceIds.AddRange(ids);
                var list = new List<string>(choices);
                foreach (var cap in new[] { _leftCaption, _rightCaption })
                {
                    cap.choices = list;
                    cap.tooltip = L.T(L.Key.TipPreviewSource);
                }
                _leftCaption.index = Mathf.Max(0, _sourceIds.IndexOf(top));
                _rightCaption.index = Mathf.Max(0, _sourceIds.IndexOf(bottom));
            }
            finally
            {
                _suppressSourceEvents = false;
            }
        }

        /// <summary>パネル座標がどちらのプレビューの上か（0 = 上/左, 1 = 下/右, それ以外 -1）。カードのドロップ先判定に使う。</summary>
        public int HitPane(Vector2 panelPosition)
        {
            if (float.IsNaN(panelPosition.x)) return -1;
            if (_leftImage.parent.worldBound.Contains(panelPosition)) return 0;
            if (_rightImage.parent.worldBound.Contains(panelPosition)) return 1;
            return -1;
        }

        /// <summary>ドラッグ中のドロップ先を強調する（-1 で解除）。</summary>
        public void SetDropHighlight(int pane)
        {
            _leftImage.parent.EnableInClassList("shapepick-preview__box--drop", pane == 0);
            _rightImage.parent.EnableInClassList("shapepick-preview__box--drop", pane == 1);
        }

        private void AttachCameraHandlers(VisualElement surface)
        {
            surface.RegisterCallback<PointerDownEvent>(evt =>
            {
                bool orbit = evt.button == 1 || (evt.button == 0 && evt.altKey);
                bool pan = evt.button == 2;
                if (!orbit && !pan) return;
                MarkCameraHintSeen();
                _dragButton = evt.button;
                surface.CapturePointer(evt.pointerId);
                SetDragging(true);
                evt.StopPropagation();
            });
            surface.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (!_dragging || !surface.HasPointerCapture(evt.pointerId)) return;
                var d = evt.deltaPosition;
                if (_dragButton == 2)
                {
                    PanRequested?.Invoke(d, Mathf.Max(1f, surface.resolvedStyle.height));
                }
                else
                {
                    OrbitRequested?.Invoke(d.x * OrbitDegreesPerPixel, d.y * OrbitDegreesPerPixel);
                }
                evt.StopPropagation();
            });
            surface.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (surface.HasPointerCapture(evt.pointerId)) surface.ReleasePointer(evt.pointerId);
                EndDrag();
                evt.StopPropagation();
            });
            surface.RegisterCallback<PointerCaptureOutEvent>(_ => EndDrag());
            surface.RegisterCallback<WheelEvent>(evt =>
            {
                MarkCameraHintSeen();
                float factor = evt.delta.y > 0f ? ZoomStep : 1f / ZoomStep;
                ZoomRequested?.Invoke(factor);
                evt.StopPropagation();
            });
            // 右ドラッグで Unity のコンテキストメニューが出ないようにする
            surface.RegisterCallback<ContextualMenuPopulateEvent>(evt => evt.StopPropagation());
        }

        private void MarkCameraHintSeen()
        {
            if (_cameraHint.style.display == DisplayStyle.None) return;
            _cameraHint.style.display = DisplayStyle.None;
            UnityEditor.EditorPrefs.SetBool(PrefCameraHintSeen, true);
        }

        /// <summary>登録済みスロットが無いときは［再撮影］を出さない（撮り直す対象が無い）。</summary>
        public void SetRecaptureEnabled(bool enabled)
        {
            _recapture.style.display = enabled ? DisplayStyle.Flex : DisplayStyle.None;
        }

        private void SetDragging(bool on)
        {
            if (_dragging == on) return;
            _dragging = on;
            DragStateChanged?.Invoke(on);
        }

        private void EndDrag()
        {
            _dragButton = -1;
            SetDragging(false);
        }

        private void UpdateLayout()
        {
            bool sideBySide = resolvedStyle.width >= SideBySideMinWidth;
            _images.EnableInClassList("shapepick-preview__images--row", sideBySide);
            _images.EnableInClassList("shapepick-preview__images--column", !sideBySide);
        }

        /// <summary>対象があり描画できるなら true。false の間は案内文だけを見せる。</summary>
        public void SetRenderingAvailable(bool available)
        {
            _images.style.display = available ? DisplayStyle.Flex : DisplayStyle.None;
            _placeholder.style.display = available ? DisplayStyle.None : DisplayStyle.Flex;
            _fitFace.SetEnabled(available);
            _fromSceneView.SetEnabled(available);
            _projection.SetEnabled(available);
            _setDefault.SetEnabled(available);
            _recapture.SetEnabled(available);
            if (!available) _objectsSection.style.display = DisplayStyle.None;
        }

        /// <summary>Persp / Iso ボタンの表示を今の投影方式に合わせる（Scene ビューと同じく、押すと切り替わる）。</summary>
        public void SetProjection(bool orthographic)
        {
            _orthographic = orthographic;
            _projection.text = L.T(orthographic ? L.Key.BtnIso : L.Key.BtnPersp);
            _projection.EnableInClassList("shapepick-toggle--on", orthographic);
        }

        public void SetPlaceholderText(string text) => _placeholder.text = text;

        public void SetTextures(Texture left, Texture right)
        {
            _leftImage.image = left;
            _rightImage.image = right;
            RepaintImages();
        }

        /// <summary>RenderTexture の内容が変わっても Image は気づかないので、描画後に呼ぶ。</summary>
        public void RepaintImages()
        {
            _leftImage.MarkDirtyRepaint();
            _rightImage.MarkDirtyRepaint();
        }

        public void RefreshTexts()
        {
            _fitFace.text = L.T(L.Key.BtnFitFace);
            _fitFace.tooltip = L.T(L.Key.TipFitFace);
            _fromSceneView.text = L.T(L.Key.BtnFromSceneView);
            _fromSceneView.tooltip = L.T(L.Key.TipFromSceneView);
            _recapture.text = L.T(L.Key.BtnRecapture);
            _recapture.tooltip = L.T(L.Key.TipRecapture);
            _projection.tooltip = L.T(L.Key.TipProjection);
            SetProjection(_orthographic);
            _setDefault.text = L.T(L.Key.BtnSetDefaultFraming);
            _setDefault.tooltip = L.T(L.Key.TipSetDefaultFraming);
            _placeholder.text = L.T(L.Key.PreviewNotReady);
            _leftImage.tooltip = L.T(L.Key.TipPreviewCamera);
            _rightImage.tooltip = L.T(L.Key.TipPreviewCamera);

            _objectsSection.tooltip = L.T(L.Key.TipPreviewObjects);
            _objectsFoldout.text = L.T(L.Key.PreviewObjectsList);
            _cameraHint.text = L.T(L.Key.CameraHint);
            _presetAll.text = L.T(L.Key.PresetAll);
            _presetAll.tooltip = L.T(L.Key.TipPresetAll);
            _presetHead.text = L.T(L.Key.PresetHead);
            _presetHead.tooltip = L.T(L.Key.TipPresetHead);
            _presetTarget.text = L.T(L.Key.PresetTargetOnly);
            _presetTarget.tooltip = L.T(L.Key.TipPresetTargetOnly);
        }
    }
}
