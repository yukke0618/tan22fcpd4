using System;
using System.Collections.Generic;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor;
using UnityEngine;

namespace ShapePick.UI
{
    /// <summary>
    /// 並列プレビューの描画をまとめる（3.5 並列プレビュー、4.4 描画は dirty 駆動）。
    /// 左 = A 案、右 = 現在値（または B 案）。カメラは 1 つを左右で共有し、SnapshotSet.camera に保存する。
    /// 描画は dirty のときだけ Tick で行い、ドラッグ中は 512² に落とす（PF-10。9/15 に yayo 依頼で 256² から変更）。アイドル時は何もしない（PF-12）。
    /// </summary>
    public sealed class PreviewCoordinator : IDisposable
    {
        private const int DragResolution = 512;
        private const int ThumbnailResolution = 512;

        private readonly ShapePickController _controller;
        private readonly PreviewPane _pane;
        private readonly PreviewRenderer _renderer = new PreviewRenderer();
        private readonly HashSet<string> _thumbnailAttempted = new HashSet<string>();

        // PreviewPane のイベントから確実に外せるよう、デリゲートを保持する
        private readonly Action<float, float> _onOrbit;
        private readonly Action<Vector2, float> _onPan;
        private readonly Action<float> _onZoom;
        private readonly Action<bool> _onDragState;
        private readonly Action<PreviewObjectPreset> _onPreset;
        private readonly Action<string, bool> _onObjectVisibility;
        private readonly Action<IReadOnlyList<string>, bool> _onGroupVisibility;

        // 表示オブジェクト（FR-23）
        private readonly List<PreviewObjectInfo> _objects = new List<PreviewObjectInfo>();
        private readonly List<Renderer> _extras = new List<Renderer>();
        private readonly List<PreviewObjectRow> _rows = new List<PreviewObjectRow>();
        private SnapshotSet _scratchSet; // Set 未生成のあいだの設定置き場
        private bool _objectsDirty;

        private RenderTexture _left;
        private RenderTexture _right;
        private int _resolution;
        private PreviewCameraState _camera = PreviewCameraState.Default;
        private bool _cameraBoundToSet;
        private bool _dirtyLeft;
        private bool _dirtyRight;
        private bool _pendingFullRes;
        private bool _cameraDirty;
        private int _topSource = SnapshotSet.SlotA;          // スロット番号または SnapshotSet.LiveSource
        private int _bottomSource = SnapshotSet.LiveSource;
        private bool _orphanSweepScheduled;
        private SkinnedMeshRenderer _lastTarget;
        private bool _disposed;
        private bool _renderFailedLogged;

        public PreviewCameraState Camera => _camera;

        public PreviewCoordinator(ShapePickController controller, PreviewPane pane)
        {
            _controller = controller;
            _pane = pane;

            _controller.StateChanged += OnStateChanged;
            _controller.LiveChanged += OnLiveChanged;
            _controller.SlotRegistered += OnSlotRegistered;
            _controller.SlotCleared += OnSlotCleared;
            _controller.SlotRemoved += OnSlotRemoved;
            Undo.undoRedoPerformed += OnUndoRedo;

            _onOrbit = (dy, dp) => { _camera.Orbit(dy, dp); MarkCameraChanged(); };
            _onPan = (d, h) => { _camera.Pan(d, h); MarkCameraChanged(); };
            _onZoom = f => { _camera.Zoom(f); MarkCameraChanged(); SaveCamera(); };
            _onDragState = dragging =>
            {
                if (!dragging) { _pendingFullRes = true; MarkAllDirty(); SaveCamera(); }
            };
            _pane.OrbitRequested += _onOrbit;
            _pane.PanRequested += _onPan;
            _pane.ZoomRequested += _onZoom;
            _pane.DragStateChanged += _onDragState;
            _pane.FitFaceRequested += FitToFace;
            _pane.FromSceneViewRequested += FromSceneView;
            _pane.RecaptureRequested += RecaptureThumbnails;
            _pane.ProjectionToggleRequested += ToggleProjection;
            _pane.SetDefaultFramingRequested += SetDefaultFraming;

            _onPreset = ApplyPreset;
            _onObjectVisibility = SetObjectVisible;
            _onGroupVisibility = SetObjectsVisible;
            _pane.PresetRequested += _onPreset;
            _pane.ObjectVisibilityChanged += _onObjectVisibility;
            _pane.ObjectGroupVisibilityChanged += _onGroupVisibility;
        }

        // ------------------------------------------------------------------ 表示オブジェクト（FR-23）

        /// <summary>設定の置き場。SnapshotSet があればそれ、無ければメモリ上の仮の Set。</summary>
        private SnapshotSet SettingsSet
        {
            get
            {
                var set = _controller.Set;
                if (set != null)
                {
                    if (_scratchSet != null)
                    {
                        // 登録で Set が生まれたら、それまでの設定を引き継ぐ
                        set.previewPreset = _scratchSet.previewPreset;
                        set.previewIncludeNeck = _scratchSet.previewIncludeNeck;
                        set.previewObjects = new List<PreviewObjectState>(_scratchSet.previewObjects);
                        UnityEngine.Object.DestroyImmediate(_scratchSet);
                        _scratchSet = null;
                        SnapshotSetRepository.ScheduleSave(set);
                    }
                    return set;
                }
                if (_scratchSet == null)
                {
                    _scratchSet = ScriptableObject.CreateInstance<SnapshotSet>();
                    _scratchSet.hideFlags = HideFlags.HideAndDontSave;
                }
                return _scratchSet;
            }
        }

        /// <summary>Hierarchy が変わった・対象が変わったときに呼ぶ。次の Tick で一覧を作り直す。</summary>
        public void MarkObjectsDirty()
        {
            _objectsDirty = true;
        }

        private void RefreshObjects()
        {
            _objectsDirty = false;
            _objects.Clear();
            if (_controller.HasTarget)
            {
                _objects.AddRange(PreviewObjectResolver.Collect(_controller.Target));
            }
            _renderer.ReleaseExtraBakes();
            ApplyObjectVisibility();
        }

        private void ApplyObjectVisibility()
        {
            var set = SettingsSet;
            PreviewObjectResolver.CollectVisibleExtras(_objects, set, _extras);
            _renderer.ExtraRenderers = _extras;

            _rows.Clear();
            foreach (var o in _objects)
            {
                _rows.Add(new PreviewObjectRow
                {
                    Path = o.Path,
                    DisplayName = o.DisplayName,
                    Visible = PreviewObjectResolver.IsVisible(o, set),
                    IsTarget = o.IsTarget,
                    HeadAttached = o.HeadAttached,
                    NeckAttached = o.NeckAttached,
                    SceneHidden = !o.DefaultVisible && !o.IsTarget,
                    GroupPath = o.GroupPath,
                    GroupName = o.GroupName,
                });
            }
            _pane.SetObjects(_rows, EffectivePreset(set), set.previewIncludeNeck);
            RefreshRecaptureButton();
            MarkAllDirty();
        }

        /// <summary>
        /// 個別チェックを触ると preset は Custom になるが、結果が「すべて」などと同じなら
        /// そのボタンを点灯させる（検証 V6-1: 全部チェックなのに「すべて」が青くない）。
        /// </summary>
        private PreviewObjectPreset EffectivePreset(SnapshotSet set)
        {
            if (set.previewPreset != PreviewObjectPreset.Custom) return set.previewPreset;
            foreach (var candidate in new[] { PreviewObjectPreset.All, PreviewObjectPreset.HeadOnly, PreviewObjectPreset.TargetOnly })
            {
                bool same = true;
                foreach (var o in _objects)
                {
                    if (PreviewObjectResolver.IsVisible(o, set) != PreviewObjectResolver.PresetVisible(o, candidate, set.previewIncludeNeck))
                    {
                        same = false;
                        break;
                    }
                }
                if (same) return candidate;
            }
            return PreviewObjectPreset.Custom;
        }

        private void RefreshRecaptureButton()
        {
            var set = _controller.Set;
            _pane.SetRecaptureEnabled(set != null && set.RegisteredSlotCount > 0);
        }

        public void ApplyPreset(PreviewObjectPreset preset)
        {
            var set = SettingsSet;
            set.previewPreset = preset;
            set.ClearPreviewOverrides();
            SaveSettings(set);
            ApplyObjectVisibility();
        }

        public void SetObjectVisible(string path, bool visible)
        {
            SetObjectsVisible(new[] { path }, visible);
        }

        /// <summary>衣装ごとのチェック（まとめて切替）と個別チェックの共通処理。</summary>
        public void SetObjectsVisible(IReadOnlyList<string> paths, bool visible)
        {
            var set = SettingsSet;
            PreviewObjectResolver.SetVisible(_objects, set, new HashSet<string>(paths), visible);
            SaveSettings(set);
            ApplyObjectVisibility();
        }

        private static void SaveSettings(SnapshotSet set)
        {
            if (set != null && AssetDatabase.Contains(set)) SnapshotSetRepository.ScheduleSave(set);
        }

        // ------------------------------------------------------------------ 公開操作

        /// <summary>上下のプレビューに出すもの（スロット番号または SnapshotSet.LiveSource）。</summary>
        public void SetSources(int top, int bottom)
        {
            if (_topSource != top) { _topSource = top; _dirtyLeft = true; }
            if (_bottomSource != bottom) { _bottomSource = bottom; _dirtyRight = true; }
        }

        private void MarkSourceDirty(int source)
        {
            if (_topSource == source) _dirtyLeft = true;
            if (_bottomSource == source) _dirtyRight = true;
        }

        /// <summary>そのソースを描くための値。null は「シーンの今の値のまま描く」。</summary>
        private IReadOnlyList<BlendShapeEntry> ValuesFor(int source, SnapshotSet set)
        {
            if (source != SnapshotSet.LiveSource)
            {
                var snap = set != null ? set.GetSlot(source) : null;
                return snap != null && snap.IsRegistered ? snap.entries : null;
            }
            // スロット表示中: シーン上はスロットの値なので、退避した現在値を一時適用して描く
            return _controller.Mode != ViewMode.Live ? _controller.RefreshLiveSnapshot().entries : null;
        }

        private bool IsSourceReady(int source, SnapshotSet set)
        {
            if (source == SnapshotSet.LiveSource) return true;
            var snap = set != null ? set.GetSlot(source) : null;
            return snap != null && snap.IsRegistered;
        }

        /// <summary>参照されなくなったプレビュー PNG を次のエディタ更新で消す（yayo 依頼 7）。連続呼び出しは 1 回にまとめる。</summary>
        private void ScheduleOrphanSweep()
        {
            if (_orphanSweepScheduled) return;
            _orphanSweepScheduled = true;
            EditorApplication.delayCall += () =>
            {
                _orphanSweepScheduled = false;
                if (_disposed) return;
                var set = _controller.Set;
                if (set != null && AssetDatabase.Contains(set)) PreviewCache.DeleteOrphans(set);
            };
        }

        public void MarkAllDirty()
        {
            _dirtyLeft = true;
            _dirtyRight = true;
        }

        public void FitToFace()
        {
            if (_disposed || !_controller.HasTarget) return;
            // 既定の構図に戻す（画角・投影も既定のもの）
            _camera = PreviewRenderer.FitToFace(_controller.Target);
            MarkCameraChanged();
            SaveCamera();
        }

        public void FromSceneView()
        {
            if (_disposed) return;
            if (PreviewRenderer.TryFromSceneView(out var state))
            {
                _camera = state;
                MarkCameraChanged();
                SaveCamera();
            }
        }

        /// <summary>Scene ビューの Persp / Iso と同じ切替。距離はそのままで映る範囲を揃える。</summary>
        public void ToggleProjection()
        {
            if (_disposed) return;
            _camera.orthographic = !_camera.orthographic;
            MarkCameraChanged();
            SaveCamera();
        }

        /// <summary>今の構図を既定として保存する（アバター非依存の相対値。［顔に合わせる］と初回表示に使う）。</summary>
        public void SetDefaultFraming()
        {
            if (_disposed || !_controller.HasTarget) return;
            var preset = PreviewRenderer.CapturePreset(_controller.Target, _camera);
            ShapePickSettings.DefaultCameraPresetJson = preset.ToJson();
            _controller.Notify(L.T(L.Key.ToastDefaultFramingSaved));
        }

        /// <summary>登録済みスロットすべてのサムネイルを今のカメラで撮り直す（FR-16）。</summary>
        public void RecaptureThumbnails()
        {
            if (_disposed) return;
            var set = _controller.Set;
            if (set == null || !_controller.HasTarget) return;
            for (int i = 0; i < set.slots.Count; i++)
            {
                if (set.IsSlotRegistered(i)) CaptureThumbnail(i);
            }
        }

        /// <summary>1 スロットのサムネイルを撮って PNG キャッシュに保存し、スロットへ紐づける。</summary>
        public void CaptureThumbnail(int slot)
        {
            if (_disposed || _renderer.IsDisposed) return;
            var set = _controller.Set;
            var snap = set != null ? set.GetSlot(slot) : null;
            if (snap == null || !snap.IsRegistered || !_controller.HasTarget) return;

            EnsureCameraInitialized();
            _thumbnailAttempted.Add(snap.id);
            var rt = PreviewRenderer.CreateTarget(ThumbnailResolution);
            _controller.Detector.Suppress(true);
            try
            {
                if (!_renderer.Render(_controller.Target, snap.entries, _camera, rt)) return;
                var tex = PreviewCache.Save(set, snap.id, rt);
                if (tex != null)
                {
                    snap.previewCache = tex;
                    SnapshotSetRepository.ScheduleSave(set);
                    _controller.NotifyStateChanged();
                }
            }
            finally
            {
                _controller.Detector.Suppress(false);
                UnityEngine.Object.DestroyImmediate(rt);
            }
        }

        // ------------------------------------------------------------------ 更新

        /// <summary>毎エディタ更新で呼ぶ。dirty のときだけ描く。</summary>
        public void Tick()
        {
            if (_disposed) return;

            if (!_controller.HasTarget)
            {
                if (_lastTarget != null)
                {
                    _lastTarget = null;
                    _pane.SetRenderingAvailable(false);
                }
                return;
            }

            if (_lastTarget != _controller.Target)
            {
                _lastTarget = _controller.Target;
                _cameraBoundToSet = false;
                _pane.SetRenderingAvailable(true);
                if (_scratchSet != null) { UnityEngine.Object.DestroyImmediate(_scratchSet); _scratchSet = null; }
                _objectsDirty = true;
                MarkAllDirty();
            }

            if (_objectsDirty) RefreshObjects();
            EnsureCameraInitialized();
            RestoreMissingThumbnails();
            if (!_dirtyLeft && !_dirtyRight && !_cameraDirty) return;

            // ドラッグ中も、設定や枠の幅で決まる解像度より上げない（設定が 256 ならドラッグ中も 256）
            int res = _pane.IsDragging ? Mathf.Min(DragResolution, ChooseResolution()) : ChooseResolution();
            EnsureTargets(res);

            var set = _controller.Set;
            bool renderLeft = _dirtyLeft || _cameraDirty || _pendingFullRes;
            bool renderRight = _dirtyRight || _cameraDirty || _pendingFullRes;

            _controller.Detector.Suppress(true);
            try
            {
                if (renderLeft)
                {
                    if (IsSourceReady(_topSource, set)) _renderer.Render(_controller.Target, ValuesFor(_topSource, set), _camera, _left);
                    else PreviewRenderer.Clear(_left, _renderer.BackgroundColor);
                }
                if (renderRight)
                {
                    if (IsSourceReady(_bottomSource, set)) _renderer.Render(_controller.Target, ValuesFor(_bottomSource, set), _camera, _right);
                    else PreviewRenderer.Clear(_right, _renderer.BackgroundColor);
                }
                _renderFailedLogged = false;
            }
            catch (Exception ex)
            {
                // 描画に失敗しても次の dirty まで再試行しない（毎フレーム例外を繰り返さない）。1 回だけ記録する
                if (!_renderFailedLogged)
                {
                    Debug.LogException(ex);
                    _renderFailedLogged = true;
                }
            }
            finally
            {
                _controller.Detector.Suppress(false);
                _dirtyLeft = false;
                _dirtyRight = false;
                _cameraDirty = false;
                _pendingFullRes = false;
            }

            _pane.SetTextures(_left, _right);
        }

        /// <summary>
        /// カメラの初期化。SnapshotSet に保存済みならそれを使う。無ければ Head ボーン基準の初期フレーミング（FR-07）に、
        /// Scene ビューの画角だけを引き継ぐ。Scene ビューの位置そのままだと顔が小さすぎることが多いため、位置は顔に合わせる。
        /// </summary>
        private void EnsureCameraInitialized()
        {
            if (_cameraBoundToSet) return;
            var set = _controller.Set;
            if (set != null && set.camera.initialized)
            {
                _camera = set.camera;
            }
            else
            {
                // 既定の構図（設定に保存した構図、無ければ正面・Persp・バストアップ）。画角だけ Scene ビューから引き継ぐ
                float fov = 0f;
                if (PreviewRenderer.TryFromSceneView(out var sv)) fov = sv.fov;
                _camera = PreviewRenderer.FitToFace(_controller.Target, fov);
            }
            _cameraBoundToSet = true;
            _cameraDirty = true;
            _pane.SetProjection(_camera.orthographic);
        }

        /// <summary>Undo で上書き登録が戻った等で PNG が欠けたスロットのサムネイルを撮り直す（FR-16: 値から再生成できる）。</summary>
        private void RestoreMissingThumbnails()
        {
            var set = _controller.Set;
            if (set == null) return;
            for (int i = 0; i < set.slots.Count; i++)
            {
                var s = set.slots[i];
                if (s == null || !s.IsRegistered || s.previewCache != null) continue;
                if (string.IsNullOrEmpty(s.id) || _thumbnailAttempted.Contains(s.id)) continue;
                CaptureThumbnail(i);
                return; // 1 フレームに 1 枚まで
            }
        }

        private void MarkCameraChanged()
        {
            _cameraDirty = true;
            _pane.SetProjection(_camera.orthographic);
        }

        private void SaveCamera()
        {
            var set = _controller.Set;
            if (set == null) return;
            set.camera = _camera;
            SnapshotSetRepository.ScheduleSave(set);
        }

        private int ChooseResolution()
        {
            float px = _pane.SurfacePixelWidth;
            int wanted = ShapePickSettings.PreviewResolution;
            if (px <= 0f) return wanted;
            if (px <= 300f) return Mathf.Min(wanted, 256);
            if (px <= 640f) return Mathf.Min(wanted, 512);
            return Mathf.Min(wanted, 1024);
        }

        private void EnsureTargets(int resolution)
        {
            if (_left != null && _resolution == resolution) return;
            ReleaseTargets();
            _resolution = resolution;
            _left = PreviewRenderer.CreateTarget(resolution);
            _right = PreviewRenderer.CreateTarget(resolution);
            _dirtyLeft = true;
            _dirtyRight = true;
        }

        private void ReleaseTargets()
        {
            if (_left != null) UnityEngine.Object.DestroyImmediate(_left);
            if (_right != null) UnityEngine.Object.DestroyImmediate(_right);
            _left = null;
            _right = null;
        }

        // ------------------------------------------------------------------ イベント

        private void OnStateChanged()
        {
            RefreshRecaptureButton();
            MarkAllDirty();
        }

        /// <summary>
        /// Undo で上書き前のスロットに戻ると、その id の PNG は上書き時に消えている。
        /// 「一度撮った id」の記録を消して RestoreMissingThumbnails で撮り直せるようにする（検証 V3-1 / V3-2）。
        /// </summary>
        private void OnUndoRedo()
        {
            if (_disposed) return;
            _thumbnailAttempted.Clear();
            MarkAllDirty();
            ScheduleOrphanSweep();
        }

        private void OnLiveChanged()
        {
            MarkSourceDirty(SnapshotSet.LiveSource);
        }

        private void OnSlotCleared(int slot, string previousId)
        {
            MarkSourceDirty(slot);
            ScheduleOrphanSweep();
        }

        private void OnSlotRemoved(int slot)
        {
            // 番号が詰まるので両方描き直す。消えた id の PNG は掃除、戻ってきた id は撮り直せるようにする
            _thumbnailAttempted.Clear();
            MarkAllDirty();
            ScheduleOrphanSweep();
        }

        private void OnSlotRegistered(int slot, string previousId)
        {
            var set = _controller.Set;
            if (set != null && !string.IsNullOrEmpty(previousId)) PreviewCache.Delete(set, previousId);
            // Set がこの登録で生成された場合、ここまでのカメラ操作と表示オブジェクト設定を保存しておく
            SaveCamera();
            var _ = SettingsSet;
            // 登録直後のフレームでは UI を止めない。次のエディタ更新でサムネイルを撮る（3.5 登録フロー）
            EditorApplication.delayCall += () =>
            {
                if (!_disposed) CaptureThumbnail(slot);
            };
            MarkSourceDirty(slot);
            ScheduleOrphanSweep();
        }

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _controller.StateChanged -= OnStateChanged;
            _controller.LiveChanged -= OnLiveChanged;
            _controller.SlotRegistered -= OnSlotRegistered;
            _controller.SlotCleared -= OnSlotCleared;
            _controller.SlotRemoved -= OnSlotRemoved;
            Undo.undoRedoPerformed -= OnUndoRedo;
            _pane.OrbitRequested -= _onOrbit;
            _pane.PanRequested -= _onPan;
            _pane.ZoomRequested -= _onZoom;
            _pane.DragStateChanged -= _onDragState;
            _pane.FitFaceRequested -= FitToFace;
            _pane.FromSceneViewRequested -= FromSceneView;
            _pane.RecaptureRequested -= RecaptureThumbnails;
            _pane.ProjectionToggleRequested -= ToggleProjection;
            _pane.SetDefaultFramingRequested -= SetDefaultFraming;
            _pane.PresetRequested -= _onPreset;
            _pane.ObjectVisibilityChanged -= _onObjectVisibility;
            _pane.ObjectGroupVisibilityChanged -= _onGroupVisibility;
            if (_scratchSet != null) { UnityEngine.Object.DestroyImmediate(_scratchSet); _scratchSet = null; }
            ReleaseTargets();
            _renderer.Dispose();
        }
    }
}
