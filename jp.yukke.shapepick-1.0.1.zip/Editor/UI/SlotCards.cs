using System;
using System.Collections.Generic;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>
    /// スロット 1 つ分のサムネイルカード（FR-19 (2)）。
    /// 9/5 検証後の整理（yayo 依頼 3・4）: 操作はホバー無しで常時見せる。
    /// 登録済み: サムネイル・名前・時刻・［シーンに表示］［アバターに適用］・メモ。名前変更・上書き・空にするは「…」メニュー。
    /// 未登録: サムネイル枠と［登録］。
    /// サムネイルはクリックで上のプレビューに出し、ドラッグで上下どちらかのプレビューに置ける（依頼 2）。
    /// </summary>
    public sealed class SlotCard : VisualElement
    {
        private const float DragThreshold = 6f;

        public int Slot { get; }

        private readonly Image _thumb;
        private readonly Label _title;
        private readonly Label _sub;
        private readonly Image _warnIcon;
        private readonly VisualElement _actions;
        private readonly Button _show;
        private readonly Button _apply;
        private readonly TextField _renameField;
        private readonly TextField _memo;
        private readonly Button _registerBig;
        private readonly Button _more;

        private bool _registered;
        private bool _canRegister;
        private bool _canRemove;
        private Vector2 _pressPos;
        private int _pressPointer = -1;
        private bool _dragging;

        public event Action<int> RegisterRequested;
        public event Action<int> ShowRequested;
        public event Action<int> ApplyRequested;
        public event Action<int> ClearRequested;
        public event Action<int> RemoveRequested;
        public event Action<int> PreviewRequested;
        public event Action<int, string> RenameRequested;
        public event Action<int, string> MemoChanged;
        /// <summary>サムネイルのドラッグ開始（スロット番号, パネル座標）。</summary>
        public event Action<int, Vector2> DragStarted;
        public event Action<int, Vector2> DragMoved;
        public event Action<int, Vector2> DragEnded;

        public SlotCard(int slot)
        {
            Slot = slot;
            AddToClassList("shapepick-slot-card");
            AddToClassList(slot == SnapshotSet.SlotA ? "shapepick-slot-card--a" : slot == SnapshotSet.SlotB ? "shapepick-slot-card--b" : "shapepick-slot-card--other");

            _thumb = new Image { scaleMode = ScaleMode.ScaleAndCrop };
            _thumb.AddToClassList("shapepick-slot-card__thumb");
            AttachThumbHandlers();
            Add(_thumb);

            // 未登録のカードには常時見える［登録］を置く
            _registerBig = new Button(() => RegisterRequested?.Invoke(Slot));
            _registerBig.AddToClassList("shapepick-slot-card__register-big");
            Add(_registerBig);

            var header = new VisualElement();
            header.AddToClassList("shapepick-slot-card__header");
            _title = new Label();
            _title.AddToClassList("shapepick-slot-card__title");
            _warnIcon = new Image();
            _warnIcon.AddToClassList("shapepick-slot-card__warn");
            _more = new Button(ShowMoreMenu) { text = L.T(L.Key.SlotMore) };
            _more.AddToClassList("shapepick-slot-card__more");
            header.Add(_title);
            header.Add(_warnIcon);
            header.Add(_more);
            Add(header);

            _renameField = new TextField { isDelayed = true };
            _renameField.AddToClassList("shapepick-slot-card__rename");
            _renameField.style.display = DisplayStyle.None;
            _renameField.RegisterValueChangedCallback(evt =>
            {
                HideRename();
                if (!string.IsNullOrWhiteSpace(evt.newValue)) RenameRequested?.Invoke(Slot, evt.newValue);
            });
            _renameField.RegisterCallback<FocusOutEvent>(_ => HideRename());
            _renameField.RegisterCallback<KeyDownEvent>(evt =>
            {
                if (evt.keyCode == KeyCode.Escape) HideRename();
            });
            Add(_renameField);

            _sub = new Label();
            _sub.AddToClassList("shapepick-slot-card__sub");
            Add(_sub);

            _actions = new VisualElement();
            _actions.AddToClassList("shapepick-slot-card__actions");
            _show = MakeAction(L.Key.BtnShow, () => ShowRequested?.Invoke(Slot));
            _apply = MakeAction(L.Key.BtnApply, () => ApplyRequested?.Invoke(Slot));
            _actions.Add(_show);
            _actions.Add(_apply);
            Add(_actions);

            _memo = new TextField { isDelayed = true, multiline = false };
            _memo.AddToClassList("shapepick-slot-card__memo");
            _memo.RegisterValueChangedCallback(evt => MemoChanged?.Invoke(Slot, evt.newValue));
            Add(_memo);
        }

        // ------------------------------------------------------------ サムネイル: クリックとドラッグ

        private void AttachThumbHandlers()
        {
            _thumb.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || !_registered) return;
                _pressPos = evt.position;
                _pressPointer = evt.pointerId;
                _dragging = false;
                _thumb.CapturePointer(evt.pointerId);
                evt.StopPropagation();
            });
            _thumb.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (_pressPointer != evt.pointerId || !_thumb.HasPointerCapture(evt.pointerId)) return;
                Vector2 pos = evt.position;
                if (!_dragging)
                {
                    if ((pos - _pressPos).sqrMagnitude < DragThreshold * DragThreshold) return;
                    _dragging = true;
                    AddToClassList("shapepick-slot-card--dragging");
                    DragStarted?.Invoke(Slot, pos);
                }
                DragMoved?.Invoke(Slot, pos);
            });
            _thumb.RegisterCallback<PointerUpEvent>(evt =>
            {
                if (_pressPointer != evt.pointerId) return;
                bool wasDragging = _dragging;
                Vector2 pos = evt.position;
                ReleaseThumb(evt.pointerId);
                if (wasDragging) DragEnded?.Invoke(Slot, pos);
                else PreviewRequested?.Invoke(Slot);
            });
            _thumb.RegisterCallback<PointerCaptureOutEvent>(evt =>
            {
                if (_pressPointer != evt.pointerId) return;
                bool wasDragging = _dragging;
                ReleaseThumb(evt.pointerId);
                // 捕捉を失ったらドロップ無しで終える（位置は無効）
                if (wasDragging) DragEnded?.Invoke(Slot, new Vector2(float.NaN, float.NaN));
            });
        }

        private void ReleaseThumb(int pointerId)
        {
            _pressPointer = -1;
            _dragging = false;
            RemoveFromClassList("shapepick-slot-card--dragging");
            if (_thumb.HasPointerCapture(pointerId)) _thumb.ReleasePointer(pointerId);
        }

        // ------------------------------------------------------------ 「…」メニュー

        private void ShowMoreMenu()
        {
            var menu = new GenericMenu();
            menu.AddItem(new GUIContent(L.T(L.Key.BtnRename)), false, ShowRename);
            if (_canRegister) menu.AddItem(new GUIContent(L.T(L.Key.MenuOverwrite)), false, () => RegisterRequested?.Invoke(Slot));
            else menu.AddDisabledItem(new GUIContent(L.T(L.Key.MenuOverwrite)));
            menu.AddSeparator(string.Empty);
            if (_registered) menu.AddItem(new GUIContent(L.T(L.Key.BtnClearSlot)), false, () => ClearRequested?.Invoke(Slot));
            else menu.AddDisabledItem(new GUIContent(L.T(L.Key.BtnClearSlot)));
            // 枠ごと削除（最低 2 枠は残す）
            if (_canRemove) menu.AddItem(new GUIContent(L.T(L.Key.MenuRemoveSlot)), false, () => RemoveRequested?.Invoke(Slot));
            else menu.AddDisabledItem(new GUIContent(L.T(L.Key.MenuRemoveSlot)));
            menu.DropDown(_more.worldBound);
        }

        /// <summary>当日は時刻だけ、それ以外は日付付き（後日開いたときに新旧が分かるように）。</summary>
        private static string FormatTime(DateTime local)
        {
            return local.Date == DateTime.Now.Date ? local.ToString("HH:mm") : local.ToString("M/d HH:mm");
        }

        private static Button MakeAction(L.Key text, Action onClick)
        {
            var b = new Button(onClick) { text = L.T(text) };
            b.AddToClassList("shapepick-slot-card__btn");
            return b;
        }

        private void ShowRename()
        {
            _renameField.SetValueWithoutNotify(_title.text);
            _title.style.display = DisplayStyle.None;
            _renameField.style.display = DisplayStyle.Flex;
            _renameField.Focus();
            _renameField.SelectAll();
        }

        private void HideRename()
        {
            _renameField.style.display = DisplayStyle.None;
            _title.style.display = DisplayStyle.Flex;
        }

        public void SetThumbnail(Texture texture)
        {
            _thumb.image = texture;
            _thumb.EnableInClassList("shapepick-slot-card__thumb--empty", texture == null);
        }

        /// <summary>上下のプレビューに出ているスロットに印を付ける。</summary>
        public void SetPreviewMarks(bool top, bool bottom)
        {
            EnableInClassList("shapepick-slot-card--top", top);
            EnableInClassList("shapepick-slot-card--bottom", bottom);
        }

        public void Refresh(ShapePickController controller)
        {
            var snap = controller.GetSlot(Slot);
            _registered = snap != null && snap.IsRegistered;
            string label = controller.Set != null ? controller.Set.DisplayLabel(Slot) : SnapshotSet.DefaultLabel(Slot);

            _title.text = label;
            _show.text = L.T(L.Key.BtnShow);
            _apply.text = L.T(L.Key.BtnApply);
            _more.text = L.T(L.Key.SlotMore);
            _more.tooltip = L.T(L.Key.TipSlotMore);

            bool otherMesh = _registered && controller.HasTarget && snap.meshName != controller.Target.sharedMesh.name;
            _warnIcon.style.display = otherMesh ? DisplayStyle.Flex : DisplayStyle.None;
            _warnIcon.tooltip = L.T(L.Key.SlotOtherMesh);
            if (otherMesh && _warnIcon.image == null)
            {
                _warnIcon.image = EditorGUIUtility.IconContent("console.warnicon.sml").image;
            }

            _sub.text = _registered
                ? L.F(L.Key.SlotRegisteredAt, FormatTime(snap.CreatedAtLocal))
                : Slot == SnapshotSet.SlotB ? L.T(L.Key.SlotBOptional) : L.T(L.Key.SlotUnregistered);
            _sub.EnableInClassList("shapepick-slot-card__sub--wrap", !_registered && Slot == SnapshotSet.SlotB);

            _registerBig.style.display = _registered ? DisplayStyle.None : DisplayStyle.Flex;
            _registerBig.text = L.T(L.Key.BtnRegister);
            _actions.style.display = _registered ? DisplayStyle.Flex : DisplayStyle.None;
            _memo.style.display = _registered ? DisplayStyle.Flex : DisplayStyle.None;
            _memo.SetValueWithoutNotify(snap != null ? snap.memo ?? string.Empty : string.Empty);
            _memo.tooltip = L.T(L.Key.SlotMemo);
            _thumb.tooltip = _registered ? L.T(L.Key.TipThumbnail) : string.Empty;
            EnableInClassList("shapepick-slot-card--empty", !_registered);
            EnableInClassList("shapepick-slot-card--shown", controller.Mode != ViewMode.Live && controller.ShownSlot == Slot);

            _canRegister = controller.CanRegister(Slot);
            string registerTip = _canRegister
                ? L.T(L.Key.TipRegister)
                : !controller.HasTarget ? L.T(L.Key.TipRegisterDisabledNoTarget)
                : controller.Mode != ViewMode.Live ? L.T(L.Key.TipRegisterDisabledShowing)
                : L.F(L.Key.TipRegisterDisabledNeedA, controller.Set != null ? controller.Set.DisplayLabel(SnapshotSet.SlotA) : L.LabelA);
            _registerBig.SetEnabled(_canRegister);
            _registerBig.tooltip = registerTip;
            _more.SetEnabled(controller.Set != null);
            _canRemove = controller.CanRemoveSlot(Slot);

            _show.SetEnabled(controller.CanShow(Slot));
            _show.tooltip = L.T(L.Key.TipShow);
            _apply.SetEnabled(controller.CanApply(Slot));
            _apply.tooltip = L.T(L.Key.TipApply);

            SetThumbnail(_registered ? snap.previewCache : null);
        }
    }

    /// <summary>スロットのカードと［＋ 追加］を横並びにする。枠数は SnapshotSet に合わせて増減する（最低 1、最大 5）。</summary>
    public sealed class SlotCardsView : VisualElement
    {
        private readonly List<SlotCard> _cards = new List<SlotCard>();
        private readonly Button _addButton;

        public event Action<int> RegisterRequested;
        public event Action<int> ShowRequested;
        public event Action<int> ApplyRequested;
        public event Action<int> ClearRequested;
        public event Action<int> RemoveRequested;
        public event Action<int> PreviewRequested;
        public event Action<int, string> RenameRequested;
        public event Action<int, string> MemoChanged;
        public event Action<int, Vector2> DragStarted;
        public event Action<int, Vector2> DragMoved;
        public event Action<int, Vector2> DragEnded;
        public event Action AddRequested;

        public SlotCardsView()
        {
            AddToClassList("shapepick-slot-cards");
            _addButton = new Button(() => AddRequested?.Invoke()) { text = L.T(L.Key.BtnAddSlot), tooltip = L.T(L.Key.TipAddSlot) };
            _addButton.AddToClassList("shapepick-slot-cards__add");
            Add(_addButton);
            EnsureCards(1);
        }

        public SlotCard GetCard(int slot) => slot >= 0 && slot < _cards.Count ? _cards[slot] : null;

        private void EnsureCards(int count)
        {
            while (_cards.Count < count)
            {
                var card = new SlotCard(_cards.Count);
                card.RegisterRequested += s => RegisterRequested?.Invoke(s);
                card.ShowRequested += s => ShowRequested?.Invoke(s);
                card.ApplyRequested += s => ApplyRequested?.Invoke(s);
                card.ClearRequested += s => ClearRequested?.Invoke(s);
                card.RemoveRequested += s => RemoveRequested?.Invoke(s);
                card.PreviewRequested += s => PreviewRequested?.Invoke(s);
                card.RenameRequested += (s, n) => RenameRequested?.Invoke(s, n);
                card.MemoChanged += (s, m) => MemoChanged?.Invoke(s, m);
                card.DragStarted += (s, p) => DragStarted?.Invoke(s, p);
                card.DragMoved += (s, p) => DragMoved?.Invoke(s, p);
                card.DragEnded += (s, p) => DragEnded?.Invoke(s, p);
                _cards.Add(card);
                Insert(_cards.Count - 1, card);
            }
            while (_cards.Count > count)
            {
                var last = _cards[_cards.Count - 1];
                last.RemoveFromHierarchy();
                _cards.RemoveAt(_cards.Count - 1);
            }
        }

        public void Refresh(ShapePickController controller, int topSource, int bottomSource)
        {
            int count = controller.Set != null ? controller.Set.VisibleSlotCount : 1;
            EnsureCards(count);
            foreach (var c in _cards)
            {
                c.Refresh(controller);
                c.SetPreviewMarks(c.Slot == topSource, c.Slot == bottomSource);
            }
            _addButton.text = L.T(L.Key.BtnAddSlot);
            bool full = count >= SnapshotSet.VisibleSlotLimit;
            _addButton.style.display = full ? DisplayStyle.None : DisplayStyle.Flex;
            _addButton.SetEnabled(controller.CanAddSlot);
            _addButton.tooltip = controller.CanAddSlot ? L.T(L.Key.TipAddSlot) : L.T(L.Key.TipAddSlotDisabled);
        }
    }
}
