using System.Collections.Generic;
using System.IO;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>
    /// 紐づけが切れた候補を、今の対象へ引き継ぐ（コピーする）ための一覧（2026-11-13）。
    /// 1 セット 1 行で、アバター名・シーン名・候補の数・最後に登録した日時・サムネイルを出す。
    /// 行の中で候補を選べるので、空きが足りないときはどれを入れるかを決められる。上書きはしない。
    /// 表示と入力だけを担当し、処理は ShapePickController.Adopt に委ねる。
    /// </summary>
    public sealed class AdoptWindow : EditorWindow
    {
        private ShapePickController _controller;
        private ScrollView _list;
        private Label _header;

        public static AdoptWindow Open(ShapePickController controller)
        {
            var window = GetWindow<AdoptWindow>(true, L.T(L.Key.AdoptWindowTitle), true);
            window.minSize = new Vector2(460f, 320f);
            window.Bind(controller);
            return window;
        }

        /// <summary>開いている一覧を閉じる。メインウィンドウを閉じるとき（コントローラが破棄される前）に呼ぶ。</summary>
        public static void CloseAll()
        {
            foreach (var window in Resources.FindObjectsOfTypeAll<AdoptWindow>())
            {
                if (window != null) window.Close();
            }
        }

        private void Bind(ShapePickController controller)
        {
            Unbind();
            _controller = controller;
            if (_controller != null) _controller.StateChanged += Rebuild;
            Rebuild();
        }

        private void Unbind()
        {
            if (_controller != null) _controller.StateChanged -= Rebuild;
            _controller = null;
        }

        private void OnEnable()
        {
            // コントローラはドメインリロードを越えられない。押せない一覧を残さず、リロードの前に閉じる
            AssemblyReloadEvents.beforeAssemblyReload += Close;
        }

        private void OnDisable()
        {
            AssemblyReloadEvents.beforeAssemblyReload -= Close;
            Unbind();
        }

        private void CreateGUI()
        {
            var root = rootVisualElement;
            root.style.paddingLeft = root.style.paddingRight = 8;
            root.style.paddingTop = root.style.paddingBottom = 8;

            _header = new Label();
            _header.style.unityFontStyleAndWeight = FontStyle.Bold;
            _header.style.whiteSpace = WhiteSpace.Normal;
            root.Add(_header);

            var explain = new Label(L.T(L.Key.AdoptExplain));
            explain.style.whiteSpace = WhiteSpace.Normal;
            explain.style.opacity = 0.75f;
            explain.style.marginTop = 2;
            explain.style.marginBottom = 6;
            root.Add(explain);

            _list = new ScrollView(ScrollViewMode.Vertical);
            _list.style.flexGrow = 1;
            root.Add(_list);

            Rebuild();
        }

        private void Rebuild()
        {
            if (_list == null) return;
            _list.Clear();

            var c = _controller;
            // ドメインリロードや対象の切替で引き継ぎ先が無くなったら、押せない一覧を残さない
            if (c == null || !c.HasTarget)
            {
                _header.text = L.T(L.Key.AdoptEmpty);
                return;
            }

            var avatar = PreviewObjectResolver.FindAvatarRoot(c.Target);
            string targetName = (avatar != null ? avatar.name : c.Target.name) + " / " + c.Target.name;
            int free = c.FreeSlotCount;
            _header.text = L.F(L.Key.AdoptHeader, targetName, free);

            if (c.Adoptable.Count == 0)
            {
                _list.Add(new Label(L.T(L.Key.AdoptEmpty)));
                return;
            }

            // Rebuild の途中で一覧が変わっても困らないよう写しを回す
            foreach (var set in new List<SnapshotSet>(c.Adoptable))
            {
                if (set != null) _list.Add(BuildRow(c, set, free));
            }
        }

        private VisualElement BuildRow(ShapePickController c, SnapshotSet source, int free)
        {
            var row = new VisualElement();
            row.style.marginBottom = 8;
            row.style.paddingLeft = row.style.paddingRight = 6;
            row.style.paddingTop = row.style.paddingBottom = 6;
            row.style.borderTopWidth = row.style.borderBottomWidth = row.style.borderLeftWidth = row.style.borderRightWidth = 1;
            var border = new Color(0.5f, 0.5f, 0.5f, 0.4f);
            row.style.borderTopColor = row.style.borderBottomColor = row.style.borderLeftColor = row.style.borderRightColor = border;
            row.style.borderTopLeftRadius = row.style.borderTopRightRadius = row.style.borderBottomLeftRadius = row.style.borderBottomRightRadius = 4;

            // まだ引き継いでいない候補だけを出す（一部だけ引き継いだあとは、残りが出る）
            var registered = new List<int>();
            for (int i = 0; i < source.slots.Count; i++)
            {
                if (SnapshotSetRepository.IsUnadopted(source, i, c.Set)) registered.Add(i);
            }

            long latest = 0;
            foreach (int s in registered) latest = System.Math.Max(latest, source.GetSlot(s).createdAtUtc);
            string latestText = latest == 0 ? "-" : new System.DateTime(latest, System.DateTimeKind.Utc).ToLocalTime().ToString("yyyy/MM/dd HH:mm");

            string avatarName = string.IsNullOrEmpty(source.avatarName) ? source.name : source.avatarName;
            string leaf = source.targetPath ?? string.Empty;
            int slash = leaf.LastIndexOf('/');
            if (slash >= 0) leaf = leaf.Substring(slash + 1);
            if (string.IsNullOrEmpty(leaf)) leaf = source.meshName;

            var title = new Label(L.F(L.Key.AdoptRowTitle, avatarName, leaf));
            title.style.unityFontStyleAndWeight = FontStyle.Bold;
            row.Add(title);

            var detail = new Label(L.F(L.Key.AdoptRowDetail, DescribeScene(source.targetScene), registered.Count, latestText))
            {
                tooltip = AssetDatabase.GetAssetPath(source),
            };
            detail.style.opacity = 0.75f;
            detail.style.whiteSpace = WhiteSpace.Normal;
            row.Add(detail);

            // 候補ごとのサムネイルとチェック。入りきるなら全部、入りきらないなら前から空きの数だけ選んでおく
            var picks = new VisualElement();
            picks.style.flexDirection = FlexDirection.Row;
            picks.style.flexWrap = Wrap.Wrap;
            picks.style.marginTop = 4;
            row.Add(picks);

            var toggles = new List<(int slot, Toggle toggle)>();
            var footer = new VisualElement();
            footer.style.flexDirection = FlexDirection.Row;
            footer.style.alignItems = Align.Center;
            footer.style.marginTop = 4;
            var warn = new Label();
            warn.style.flexGrow = 1;
            warn.style.flexShrink = 1;
            warn.style.whiteSpace = WhiteSpace.Normal;
            warn.style.color = new Color(0.95f, 0.6f, 0.2f);
            var go = new Button();

            void UpdateFooter()
            {
                int n = 0;
                foreach (var t in toggles) if (t.toggle.value) n++;
                go.text = L.F(L.Key.AdoptDo, n);
                bool tooMany = n > free;
                go.SetEnabled(n > 0 && !tooMany && c.CanAdopt);
                warn.text = free == 0 ? L.T(L.Key.AdoptNoRoom) : tooMany ? L.F(L.Key.AdoptTooMany, free) : string.Empty;
            }

            for (int i = 0; i < registered.Count; i++)
            {
                int slot = registered[i];
                var snap = source.GetSlot(slot);

                var cell = new VisualElement();
                cell.style.width = 84;
                cell.style.marginRight = 6;
                cell.style.marginBottom = 4;

                var thumb = new Image { scaleMode = ScaleMode.ScaleToFit, image = PreviewCache.Load(source, snap.id) };
                thumb.style.width = 84;
                thumb.style.height = 84;
                thumb.style.backgroundColor = new Color(0f, 0f, 0f, 0.25f);
                cell.Add(thumb);

                var toggle = new Toggle(source.DisplayLabel(slot)) { value = i < free, tooltip = snap.memo };
                toggle.labelElement.style.minWidth = 0;
                toggle.RegisterValueChangedCallback(_ => UpdateFooter());
                // サムネイルを押してもチェックが切り替わるように
                thumb.RegisterCallback<ClickEvent>(_ => toggle.value = !toggle.value);
                cell.Add(toggle);

                toggles.Add((slot, toggle));
                picks.Add(cell);
            }

            go.clicked += () =>
            {
                var chosen = new List<int>();
                foreach (var t in toggles) if (t.toggle.value) chosen.Add(t.slot);
                // 成功すると StateChanged で一覧ごと作り直される
                c.Adopt(source, chosen);
            };

            footer.Add(warn);
            footer.Add(go);
            row.Add(footer);
            UpdateFooter();
            return row;
        }

        /// <summary>紐づけ先のシーンを、開いているか・ファイルが残っているかと合わせて説明する。</summary>
        private static string DescribeScene(string scenePath)
        {
            if (string.IsNullOrEmpty(scenePath)) return L.T(L.Key.AdoptSceneUnsaved);

            string name = Path.GetFileNameWithoutExtension(scenePath);
            if (!File.Exists(scenePath)) return L.F(L.Key.AdoptSceneMissing, name);

            for (int i = 0; i < UnityEngine.SceneManagement.SceneManager.sceneCount; i++)
            {
                var scene = UnityEngine.SceneManagement.SceneManager.GetSceneAt(i);
                if (scene.isLoaded && scene.path == scenePath) return L.F(L.Key.AdoptSceneOpen, name);
            }
            // Prefab モードで登録した候補は、キーがプレハブのパスになっている
            return scenePath.EndsWith(".unity", System.StringComparison.OrdinalIgnoreCase)
                ? L.F(L.Key.AdoptSceneClosed, name)
                : L.F(L.Key.AdoptSceneOpen, name);
        }
    }
}
