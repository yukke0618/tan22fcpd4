using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>
    /// 「シェイプキー」タブ（FR-20）。FaceEmo の表情エディタと同じく、上に「使用中（値 ≠ 0）」、下に「すべて」を置く。
    /// 一覧はクリックで使用中に追加（値 100）、スライダーと数値入力で値を変更、名前の部分一致検索、
    /// 区切り文字によるカテゴリ折りたたみに対応する。値の変更は Inspector と同じく即時反映して Undo に記録する。
    /// 1,000 件でも固定行高の ListView で可視行だけ描く。
    /// </summary>
    public sealed class ShapeKeyListView : VisualElement
    {
        private const float RowHeight = 22f;
        private const float MinListHeight = RowHeight * 2f;
        private const float MaxListHeight = 1200f;
        private const string PrefInUseHeight = "ShapePick.Keys.InUseHeight";
        private const string PrefAllHeight = "ShapePick.Keys.AllHeight";
        private const float DefaultInUseHeight = 200f;
        private const float DefaultAllHeight = 360f;

        private sealed class Item
        {
            public bool IsHeader;
            public string Category;
            public string Name;
            public int Index;
            public int Count;
            public bool Collapsed;
            public bool Blink;
            public bool LipSync;
        }

        private readonly ShapePickController _controller;
        private readonly ToolbarSearchField _search;
        private readonly TextField _separator;
        private readonly Label _inUseTitle;
        private readonly Label _allTitle;
        private readonly Label _inUseEmpty;
        private readonly HelpBox _disabledBox;
        private readonly ListView _inUse;
        private readonly ListView _all;
        private readonly List<Item> _inUseItems = new List<Item>(64);
        private readonly List<Item> _allItems = new List<Item>(1024);
        private readonly List<Item> _rows = new List<Item>(1024);
        private readonly HashSet<string> _collapsed = new HashSet<string>();
        private Regex _blink;
        private Regex _lipSync;
        private Mesh _builtFor;
        private bool _suppress;
        private bool _sliderDragging;
        private bool _pendingRefresh;

        /// <summary>見出し用に置かれたシェイプキー（"--------Eye" や "=======EYE=======" など）をまとめるカテゴリ名。</summary>
        private const string SeparatorCategory = "――――";

        public ShapeKeyListView(ShapePickController controller)
        {
            _controller = controller;
            AddToClassList("shapepick-keys");

            var toolbar = new VisualElement();
            toolbar.AddToClassList("shapepick-row");
            _search = new ToolbarSearchField();
            _search.AddToClassList("shapepick-keys__search");
            _search.tooltip = L.T(L.Key.TipFilter);
            _search.RegisterValueChangedCallback(_ => Rebuild());
            toolbar.Add(_search);

            _separator = new TextField(L.T(L.Key.ShapeKeysSeparator)) { value = ShapePickSettings.CategorySeparator, isDelayed = true };
            _separator.AddToClassList("shapepick-keys__separator");
            _separator.RegisterValueChangedCallback(evt =>
            {
                ShapePickSettings.CategorySeparator = evt.newValue;
                _collapsed.Clear();
                Rebuild();
            });
            toolbar.Add(_separator);
            Add(toolbar);

            _disabledBox = new HelpBox(L.T(L.Key.ShapeKeysDisabledWhileShowing), HelpBoxMessageType.Info);
            _disabledBox.style.display = DisplayStyle.None;
            Add(_disabledBox);

            // 「使用中」と「すべて」を枠で分け、それぞれ下端のつまみで表示する高さを変えられるようにする（yayo 依頼 9/17）
            var inUseBox = MakeBox();
            _inUseTitle = new Label(L.T(L.Key.ShapeKeysInUse));
            _inUseTitle.AddToClassList("shapepick-section__title");
            inUseBox.Add(_inUseTitle);
            _inUseEmpty = new Label(L.T(L.Key.ShapeKeysNoneInUse));
            _inUseEmpty.AddToClassList("shapepick-muted");
            _inUseEmpty.AddToClassList("shapepick-keys__empty");
            inUseBox.Add(_inUseEmpty);
            _inUse = MakeList(_rows);
            _inUse.AddToClassList("shapepick-keys__inuse");
            inUseBox.Add(_inUse);
            inUseBox.Add(MakeResizeHandle(_inUse, PrefInUseHeight, DefaultInUseHeight));
            Add(inUseBox);

            var allBox = MakeBox();
            _allTitle = new Label(L.T(L.Key.ShapeKeysAll));
            _allTitle.AddToClassList("shapepick-section__title");
            allBox.Add(_allTitle);
            _all = MakeList(_allItems);
            _all.AddToClassList("shapepick-keys__all");
            allBox.Add(_all);
            allBox.Add(MakeResizeHandle(_all, PrefAllHeight, DefaultAllHeight));
            Add(allBox);

            CompilePatterns();
            RefreshTexts();
        }

        private static VisualElement MakeBox()
        {
            var box = new VisualElement();
            box.AddToClassList("shapepick-keys__box");
            return box;
        }

        /// <summary>
        /// 一覧の下端に置くつまみ。上下にドラッグすると一覧の高さが変わり、EditorPrefs に覚える。ダブルクリックで既定に戻す。
        /// タブの中身はスクロールするので、分割ビューではなく一覧ごとに高さを持たせる。
        /// </summary>
        private VisualElement MakeResizeHandle(VisualElement list, string prefKey, float defaultHeight)
        {
            float Clamp(float h) => Mathf.Clamp(h, MinListHeight, MaxListHeight);
            list.style.height = Clamp(EditorPrefs.GetFloat(prefKey, defaultHeight));

            var handle = new VisualElement { tooltip = L.T(L.Key.TipKeysResize) };
            handle.AddToClassList("shapepick-keys__resize");
            var grip = new VisualElement();
            grip.AddToClassList("shapepick-keys__resize-grip");
            handle.Add(grip);

            bool dragging = false;
            float startY = 0f, startHeight = 0f;
            handle.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0) return;
                if (evt.clickCount == 2)
                {
                    list.style.height = defaultHeight;
                    EditorPrefs.DeleteKey(prefKey);
                    evt.StopPropagation();
                    return;
                }
                dragging = true;
                startY = evt.position.y;
                startHeight = list.resolvedStyle.height;
                handle.CapturePointer(evt.pointerId);
                handle.AddToClassList("shapepick-keys__resize--active");
                evt.StopPropagation();
            });
            handle.RegisterCallback<PointerMoveEvent>(evt =>
            {
                if (!dragging) return;
                list.style.height = Clamp(startHeight + (evt.position.y - startY));
            });
            void End(int pointerId)
            {
                if (!dragging) return;
                dragging = false;
                if (handle.HasPointerCapture(pointerId)) handle.ReleasePointer(pointerId);
                handle.RemoveFromClassList("shapepick-keys__resize--active");
                EditorPrefs.SetFloat(prefKey, Clamp(list.resolvedStyle.height));
            }
            handle.RegisterCallback<PointerUpEvent>(evt => End(evt.pointerId));
            handle.RegisterCallback<PointerCaptureOutEvent>(evt => End(evt.pointerId));
            return handle;
        }

        private ListView MakeList(List<Item> source)
        {
            var list = new ListView
            {
                fixedItemHeight = RowHeight,
                virtualizationMethod = CollectionVirtualizationMethod.FixedHeight,
                selectionType = SelectionType.None,
                showAlternatingRowBackgrounds = AlternatingRowBackground.None,
                itemsSource = source,
                makeItem = MakeRow,
                bindItem = (e, i) => BindRow(e, source[i]),
            };
            return list;
        }

        private VisualElement MakeRow()
        {
            var row = new VisualElement();
            row.AddToClassList("shapepick-key-row");

            var header = new Label { name = "header" };
            header.AddToClassList("shapepick-key-row__header");
            header.RegisterCallback<ClickEvent>(_ =>
            {
                if (row.userData is Item item && item.IsHeader) ToggleCategory(item.Category);
            });
            row.Add(header);

            var body = new VisualElement { name = "body" };
            body.AddToClassList("shapepick-key-row__body");

            var warn = new Image { name = "warn" };
            warn.AddToClassList("shapepick-key-row__warn");
            body.Add(warn);

            var nameLabel = new Label { name = "name" };
            nameLabel.AddToClassList("shapepick-key-row__name");
            nameLabel.RegisterCallback<ClickEvent>(_ =>
            {
                if (!(row.userData is Item item) || item.IsHeader) return;
                if (!_controller.HasTarget || _controller.Mode != ViewMode.Live) return;
                // クリックで使用中に追加（FaceEmo と同じ）。既に使用中なら何もしない
                float current = _controller.Target.GetBlendShapeWeight(item.Index);
                if (current == 0f) _controller.SetLiveWeight(item.Name, 100f);
            });
            body.Add(nameLabel);

            var slider = new Slider(0f, 100f) { name = "slider" };
            slider.AddToClassList("shapepick-key-row__slider");
            slider.RegisterValueChangedCallback(evt =>
            {
                if (_suppress || !(row.userData is Item item) || item.IsHeader) return;
                _controller.SetLiveWeight(item.Name, evt.newValue);
            });
            // ドラッグ中に ListView を作り直すとドラッグ中の要素が差し替わり、離しても掴んだままになる
            // （検証 V7: カーソルを合わせるだけで値が動く）。ドラッグが終わるまで一覧の再構築を保留する
            slider.RegisterCallback<PointerDownEvent>(_ => _sliderDragging = true, TrickleDown.TrickleDown);
            slider.RegisterCallback<PointerUpEvent>(_ => EndSliderDrag(), TrickleDown.TrickleDown);
            slider.RegisterCallback<PointerCaptureOutEvent>(_ => EndSliderDrag(), TrickleDown.TrickleDown);
            body.Add(slider);

            var field = new FloatField { name = "field", isDelayed = true };
            field.AddToClassList("shapepick-key-row__field");
            field.RegisterValueChangedCallback(evt =>
            {
                if (_suppress || !(row.userData is Item item) || item.IsHeader) return;
                _controller.SetLiveWeight(item.Name, evt.newValue);
            });
            body.Add(field);

            // ワンクリックで 0 に戻す（名前のクリックで 100 にするのと対。yayo 依頼 9/17）。0 になると使用中から外れる
            var clear = new Button { name = "clear", text = "×" };
            clear.AddToClassList("shapepick-key-row__clear");
            clear.clicked += () =>
            {
                if (!(row.userData is Item item) || item.IsHeader) return;
                if (!_controller.HasTarget || _controller.Mode != ViewMode.Live) return;
                if (_controller.Target.GetBlendShapeWeight(item.Index) != 0f) _controller.SetLiveWeight(item.Name, 0f);
            };
            body.Add(clear);

            row.Add(body);
            return row;
        }

        private void BindRow(VisualElement row, Item item)
        {
            row.userData = item;
            var header = row.Q<Label>("header");
            var body = row.Q("body");

            if (item.IsHeader)
            {
                header.style.display = DisplayStyle.Flex;
                body.style.display = DisplayStyle.None;
                header.text = (item.Collapsed ? "▸ " : "▾ ") + item.Category + "  (" + item.Count + ")";
                return;
            }

            header.style.display = DisplayStyle.None;
            body.style.display = DisplayStyle.Flex;

            float w = _controller.HasTarget ? _controller.Target.GetBlendShapeWeight(item.Index) : 0f;
            _suppress = true;
            try
            {
                var nameLabel = row.Q<Label>("name");
                nameLabel.text = item.Name;
                nameLabel.tooltip = L.T(L.Key.TipShapeKeyRow);
                nameLabel.EnableInClassList("shapepick-key-row__name--active", w != 0f);
                row.Q<Slider>("slider").SetValueWithoutNotify(Mathf.Clamp(w, 0f, 100f));
                row.Q<FloatField>("field").SetValueWithoutNotify(w);

                var warn = row.Q<Image>("warn");
                bool show = item.Blink || item.LipSync;
                warn.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
                if (show)
                {
                    if (warn.image == null) warn.image = WarningIcon;
                    warn.tooltip = L.T(item.Blink ? L.Key.TipBlinkWarning : L.Key.TipLipSyncWarning);
                }
                bool editable = _controller.Mode == ViewMode.Live;
                row.Q<Slider>("slider").SetEnabled(editable);
                row.Q<FloatField>("field").SetEnabled(editable);
                var clear = row.Q<Button>("clear");
                clear.tooltip = L.T(L.Key.TipKeyClear);
                clear.SetEnabled(editable && w != 0f);
            }
            finally
            {
                _suppress = false;
            }
        }

        private static Texture s_warningIcon;

        /// <summary>エディタ標準の警告アイコン。スキンやバージョンで名前が違うため候補を順に試す。</summary>
        private static Texture WarningIcon
        {
            get
            {
                if (s_warningIcon != null) return s_warningIcon;
                foreach (var name in new[] { "console.warnicon.sml", "d_console.warnicon.sml", "console.warnicon", "Warning" })
                {
                    var content = EditorGUIUtility.IconContent(name);
                    if (content != null && content.image != null)
                    {
                        s_warningIcon = content.image;
                        break;
                    }
                }
                return s_warningIcon;
            }
        }

        private void EndSliderDrag()
        {
            if (!_sliderDragging) return;
            _sliderDragging = false;
            if (_pendingRefresh)
            {
                _pendingRefresh = false;
                RefreshValues();
            }
        }

        /// <summary>ドラッグ中は見えている行の値だけを更新し、一覧の作り直しは離すまで待つ。</summary>
        private bool DeferWhileDragging()
        {
            if (!_sliderDragging) return false;
            _pendingRefresh = true;
            UpdateVisibleRowValues(_inUse);
            UpdateVisibleRowValues(_all);
            return true;
        }

        private void UpdateVisibleRowValues(ListView list)
        {
            if (!_controller.HasTarget) return;
            var target = _controller.Target;
            _suppress = true;
            try
            {
                foreach (var row in list.Query(className: "shapepick-key-row").ToList())
                {
                    if (!(row.userData is Item item) || item.IsHeader) continue;
                    float w = target.GetBlendShapeWeight(item.Index);
                    row.Q<Slider>("slider").SetValueWithoutNotify(Mathf.Clamp(w, 0f, 100f));
                    row.Q<FloatField>("field").SetValueWithoutNotify(w);
                    row.Q<Button>("clear").SetEnabled(_controller.Mode == ViewMode.Live && w != 0f);
                }
            }
            finally
            {
                _suppress = false;
            }
        }

        private void ToggleCategory(string category)
        {
            if (!_collapsed.Add(category)) _collapsed.Remove(category);
            RebuildAllRows();
        }

        private void CompilePatterns()
        {
            _blink = TryRegex(ShapePickSettings.BlinkPattern);
            _lipSync = TryRegex(ShapePickSettings.LipSyncPattern);
        }

        /// <summary>設定パネルで警告パターンが変わったときに呼ぶ。正規表現を作り直して一覧を再構築する。</summary>
        public void ReloadPatterns()
        {
            CompilePatterns();
            Rebuild();
        }

        private static Regex TryRegex(string pattern)
        {
            if (string.IsNullOrWhiteSpace(pattern)) return null;
            try { return new Regex(pattern, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant); }
            catch (ArgumentException) { return null; }
        }

        /// <summary>対象や検索条件が変わったときに一覧の構造を作り直す。</summary>
        public void Rebuild()
        {
            _allItems.Clear();
            _rows.Clear();
            _builtFor = _controller.HasTarget ? _controller.Target.sharedMesh : null;

            bool live = _controller.Mode == ViewMode.Live;
            _disabledBox.style.display = _controller.HasTarget && !live ? DisplayStyle.Flex : DisplayStyle.None;

            if (_builtFor == null)
            {
                _inUse.RefreshItems();
                _all.RefreshItems();
                _inUseEmpty.style.display = DisplayStyle.None;
                return;
            }

            RebuildAllRows();
            RefreshValues();
        }

        private void RebuildAllRows()
        {
            _allItems.Clear();
            if (_builtFor == null) { _all.RefreshItems(); return; }

            var cache = BlendShapeNameCache.Get(_builtFor);
            string filter = _search.value;
            string sep = ShapePickSettings.CategorySeparator;
            bool useCategories = !string.IsNullOrEmpty(sep) && string.IsNullOrEmpty(filter);

            // カテゴリ順は出現順を保つ
            var order = new List<string>();
            var groups = new Dictionary<string, List<Item>>();
            var uncategorized = new List<Item>();

            for (int i = 0; i < cache.Count; i++)
            {
                string key = cache.GetKey(i);
                if (!string.IsNullOrEmpty(filter) && key.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) continue;

                var item = new Item
                {
                    Name = key,
                    Index = i,
                    Blink = _blink != null && _blink.IsMatch(key),
                    LipSync = _lipSync != null && _lipSync.IsMatch(key),
                };

                string category = null;
                if (useCategories)
                {
                    if (BlendShapeNameCache.IsSeparatorName(key))
                    {
                        // "----------Eye----------" や "=======EYE=======" のような見出し用のキーは
                        // 記号の種類によらず 1 つにまとめる（9/6 は "--" だけ、9/13 に一般化）
                        category = SeparatorCategory;
                    }
                    else
                    {
                        int p = key.IndexOf(sep, StringComparison.Ordinal);
                        if (p > 0) category = key.Substring(0, p);
                    }
                }

                if (category == null)
                {
                    uncategorized.Add(item);
                }
                else
                {
                    item.Category = category;
                    if (!groups.TryGetValue(category, out var list))
                    {
                        list = new List<Item>();
                        groups.Add(category, list);
                        order.Add(category);
                    }
                    list.Add(item);
                }
            }

            _allItems.AddRange(uncategorized);
            foreach (var cat in order)
            {
                var list = groups[cat];
                bool collapsed = _collapsed.Contains(cat);
                _allItems.Add(new Item { IsHeader = true, Category = cat, Count = list.Count, Collapsed = collapsed });
                if (!collapsed) _allItems.AddRange(list);
            }
            _all.RefreshItems();
        }

        /// <summary>値だけが変わったとき（Inspector 編集・Undo・適用）。使用中の並びを作り直し、全一覧は再バインドする。</summary>
        public void RefreshValues()
        {
            if (DeferWhileDragging()) return;
            _rows.Clear();
            if (_builtFor != null && _controller.HasTarget && _controller.Target.sharedMesh == _builtFor)
            {
                var cache = BlendShapeNameCache.Get(_builtFor);
                var target = _controller.Target;
                for (int i = 0; i < cache.Count; i++)
                {
                    if (target.GetBlendShapeWeight(i) == 0f) continue;
                    string key = cache.GetKey(i);
                    _rows.Add(new Item
                    {
                        Name = key,
                        Index = i,
                        Blink = _blink != null && _blink.IsMatch(key),
                        LipSync = _lipSync != null && _lipSync.IsMatch(key),
                    });
                }
            }
            else if (_builtFor != null)
            {
                Rebuild();
                return;
            }

            _inUseEmpty.style.display = _rows.Count == 0 && _builtFor != null ? DisplayStyle.Flex : DisplayStyle.None;
            _inUse.style.display = _rows.Count == 0 ? DisplayStyle.None : DisplayStyle.Flex;
            _inUse.RefreshItems();
            _all.RefreshItems();
        }

        public void RefreshTexts()
        {
            _search.tooltip = L.T(L.Key.TipFilter);
            _separator.label = L.T(L.Key.ShapeKeysSeparator);
            _inUseTitle.text = L.T(L.Key.ShapeKeysInUse);
            _allTitle.text = L.T(L.Key.ShapeKeysAll);
            _inUseEmpty.text = L.T(L.Key.ShapeKeysNoneInUse);
            _disabledBox.text = L.T(L.Key.ShapeKeysDisabledWhileShowing);
        }
    }
}
