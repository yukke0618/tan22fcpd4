using System.Collections.Generic;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>
    /// メインウィンドウ（Tools/ShapePick）。FaceEmo の表情エディタに倣った「左プレビュー・右操作」の 2 ペイン（FR-19）。
    /// 表示と入力だけを担当し、処理は ShapePickController に委ねる。
    /// </summary>
    public sealed class ShapePickWindow : EditorWindow
    {
        private const string UssFileName = "ShapePickWindow.uss";
        private static string s_ussPath;
        private const string PrefSplit = "ShapePick.SplitWidth";
        private const string PrefTab = "ShapePick.Tab";
        private const string PrefTutorialDone = "ShapePick.TutorialDone";
        private const float DefaultSplitWidth = 320f;
        private const int ToastMilliseconds = 2500;

        private ShapePickController _controller;
        private PreviewCoordinator _previewCoordinator;
        private readonly List<SkinnedMeshRenderer> _candidates = new List<SkinnedMeshRenderer>();
        private bool _built;
        private bool _suppressUiEvents;
        private int _tab;

        private VisualElement _banner;
        private Label _bannerLabel;
        private Button _bannerBack;
        private Label _toast;
        private IVisualElementScheduledItem _toastHide;
        private TwoPaneSplitView _split;
        private VisualElement _leftPane;
        private ScrollView _rightPane;
        private PreviewPane _preview;
        private ObjectField _targetField;
        private DropdownField _targetDropdown;
        private Label _countLabel;
        private Label _applyTarget;
        private Label _applyTargetDetail;
        private VisualElement _adoptBanner;
        private Label _adoptLabel;
        private bool _adoptableDirty;
        private Button _registerPrimary;
        private SlotCardsView _slots;
        private VisualElement _viewRow;
        private readonly List<Button> _viewSlotButtons = new List<Button>();
        private Button _viewLive;
        // 上下のプレビュー（= 差分表の左右）に出すもの。スロット番号または SnapshotSet.LiveSource
        private int _topSource = SnapshotSet.SlotA;
        private int _bottomSource = SnapshotSet.LiveSource;
        private readonly List<int> _registeredSlots = new List<int>();
        /// <summary>この対象でプレビューの出しものを自分で選んだか。選んでいないあいだだけ既定の組み合わせに寄せる。</summary>
        private bool _sourcesChosen;
        /// <summary>上に出していた候補のカードが削除された。次の ValidateSources で残っている候補を上に出す。</summary>
        private bool _topRemoved;
        private readonly List<string> _sourceNames = new List<string>();
        private readonly List<int> _sourceIds = new List<int>();
        private Button _peekA;
        private Button _tabDiff;
        private Button _tabKeys;
        private VisualElement _diffContent;
        private VisualElement _keysContent;
        private DiffListView _diff;
        private ShapeKeyListView _shapeKeys;
        private HintBar _hint;
        private VisualElement _tutorial;
        private VisualElement _settingsPanel;
        private VisualElement _saveBanner;
        private Label _saveBannerLabel;

        [MenuItem("Tools/ShapePick")]
        public static ShapePickWindow Open()
        {
            var window = GetWindow<ShapePickWindow>();
            window.titleContent = new GUIContent(L.T(L.Key.WindowTitle));
            window.minSize = new Vector2(720f, 560f);
            // 既に開いていたウィンドウが返る場合は CreateGUI が走らない。選択が既に対象メッシュだと
            // selectionChanged も飛ばないため、ここで拾い直さないと対象が空のままになる（FR-01）
            window.AdoptCurrentSelectionIfNoTarget();
            return window;
        }

        public ShapePickController Controller => _controller;

        // ------------------------------------------------------------------ ライフサイクル

        private void OnEnable()
        {
            titleContent = new GUIContent(L.T(L.Key.WindowTitle));
            _controller = new ShapePickController();
            _controller.StateChanged += RefreshAll;
            _controller.LiveChanged += RequestDiffRefresh;
            _controller.Notified += ShowToast;
            _controller.SlotRemoved += OnSlotRemoved;

            Selection.selectionChanged += OnSelectionChanged;
            Undo.undoRedoEvent += OnUndoRedo;
            EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
            AssemblyReloadEvents.beforeAssemblyReload += OnBeforeAssemblyReload;
            EditorApplication.update += OnEditorUpdate;
            EditorApplication.hierarchyChanged += OnHierarchyChanged;
            L.LanguageChanged += OnLanguageChanged;
            SnapshotSetRepository.SaveFailed += OnSaveFailed;
        }

        private void OnHierarchyChanged()
        {
            // 髪や衣装の追加・削除・表示切替をプレビューの表示オブジェクト一覧に反映する（FR-23）
            _previewCoordinator?.MarkObjectsDirty();
            // アバターや対象がリネーム・移動されたら、保険のパスと「適用先」の表示を追従させる
            _controller?.RebindCurrent();
            // アバターが消えた・置かれたで、引き継げる候補も変わる。Hierarchy の変化は続けて何度も来るので、
            // 調べ直しは次のエディタ更新で 1 回にまとめる（OnEditorUpdate）
            _adoptableDirty = true;
            RefreshAll();
        }

        private void OnDisable()
        {
            EditorApplication.hierarchyChanged -= OnHierarchyChanged;
            SnapshotSetRepository.SaveFailed -= OnSaveFailed;
            Selection.selectionChanged -= OnSelectionChanged;
            Undo.undoRedoEvent -= OnUndoRedo;
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
            AssemblyReloadEvents.beforeAssemblyReload -= OnBeforeAssemblyReload;
            EditorApplication.update -= OnEditorUpdate;
            L.LanguageChanged -= OnLanguageChanged;

            SaveSplit();
            // 引き継ぎの一覧はこのウィンドウのコントローラを使う。残しておくと、閉じたあとも押せてしまう
            AdoptWindow.CloseAll();
            _previewCoordinator?.Dispose();
            _previewCoordinator = null;
            if (_controller != null)
            {
                if (ShapePickSettings.AutoRestoreOnClose) _controller.RestoreForExit();
                _controller.Dispose();
                _controller = null;
            }
            SnapshotSetRepository.FlushPendingSaves();
            _built = false;
        }

        private void CreateGUI()
        {
            BuildUI();
            ApplySelection(Selection.activeGameObject);
            RefreshAll();
        }

        private void OnFocus()
        {
            // 対象を失ったままフォーカスが戻ったら Hierarchy の選択から拾い直す
            AdoptCurrentSelectionIfNoTarget();
        }

        /// <summary>対象が無いときだけ、Hierarchy の現在の選択から対象を決める。</summary>
        internal void AdoptCurrentSelectionIfNoTarget()
        {
            if (!_built || _controller == null || _controller.HasTarget) return;
            ApplySelection(Selection.activeGameObject);
        }

        private void OnLostFocus()
        {
            // 押している間だけ表示の途中でフォーカスを失ったら、必ず戻す
            _controller?.EndPeek();
        }

        // ------------------------------------------------------------------ UI 構築

        /// <summary>
        /// スタイルシートを読む。UPM パッケージ（Packages/…）と .unitypackage 展開後（Assets/…）の
        /// どちらでも動くよう、パスを固定せず自身のスクリプトの隣を見る。移動されていたら GUID 検索で拾う。
        /// </summary>
        private StyleSheet LoadStyleSheet()
        {
            if (!string.IsNullOrEmpty(s_ussPath))
            {
                var cached = AssetDatabase.LoadAssetAtPath<StyleSheet>(s_ussPath);
                if (cached != null) return cached;
                s_ussPath = null;
            }

            // 1) このスクリプト（ShapePickWindow.cs）と同じフォルダ
            var script = MonoScript.FromScriptableObject(this);
            var scriptPath = script != null ? AssetDatabase.GetAssetPath(script) : null;
            if (!string.IsNullOrEmpty(scriptPath))
            {
                // AssetDatabase のパスは常に "/" 区切り
                var slash = scriptPath.LastIndexOf('/');
                var candidate = slash >= 0 ? scriptPath.Substring(0, slash + 1) + UssFileName : null;
                var sheet = string.IsNullOrEmpty(candidate) ? null : AssetDatabase.LoadAssetAtPath<StyleSheet>(candidate);
                if (sheet != null)
                {
                    s_ussPath = candidate;
                    return sheet;
                }
            }

            // 2) プロジェクト内を名前で検索（フォルダ構成を変えられた場合の保険）
            foreach (var guid in AssetDatabase.FindAssets("ShapePickWindow t:StyleSheet"))
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (!path.EndsWith("/" + UssFileName, System.StringComparison.Ordinal)) continue;
                var sheet = AssetDatabase.LoadAssetAtPath<StyleSheet>(path);
                if (sheet == null) continue;
                s_ussPath = path;
                return sheet;
            }

            Debug.LogWarning("[ShapePick] " + UssFileName + " が見つかりませんでした。既定のスタイルで表示します。");
            return null;
        }

        private void BuildUI()
        {
            var root = rootVisualElement;
            root.Clear();
            root.AddToClassList("shapepick-root");
            var uss = LoadStyleSheet();
            if (uss != null) root.styleSheets.Add(uss);
            _banner = new VisualElement();
            _banner.AddToClassList("shapepick-banner");
            _bannerLabel = new Label();
            _banner.Add(_bannerLabel);
            _bannerBack = new Button(() => _controller?.ShowLive()) { text = L.T(L.Key.BannerBackToLive) };
            _bannerBack.AddToClassList("shapepick-banner__btn");
            _banner.Add(_bannerBack);
            _banner.style.display = DisplayStyle.None;
            root.Add(_banner);

            _saveBanner = new VisualElement();
            _saveBanner.AddToClassList("shapepick-savebanner");
            _saveBannerLabel = new Label();
            _saveBanner.Add(_saveBannerLabel);
            var retry = new Button(() =>
            {
                SnapshotSetRepository.RetryPendingSaves();
                if (!SnapshotSetRepository.HasPendingSaves) _saveBanner.style.display = DisplayStyle.None;
            }) { text = L.T(L.Key.BtnRetrySave) };
            _saveBanner.Add(retry);
            _saveBanner.style.display = DisplayStyle.None;
            root.Add(_saveBanner);

            float splitWidth = EditorPrefs.GetFloat(PrefSplit, DefaultSplitWidth);
            _split = new TwoPaneSplitView(0, splitWidth, TwoPaneSplitViewOrientation.Horizontal);
            _split.AddToClassList("shapepick-split");
            root.Add(_split);

            _leftPane = new VisualElement();
            _leftPane.AddToClassList("shapepick-left");
            _preview = new PreviewPane();
            _preview.SourceChanged += SetPreviewSource;
            _leftPane.Add(_preview);
            _split.Add(_leftPane);

            _previewCoordinator?.Dispose();
            _previewCoordinator = new PreviewCoordinator(_controller, _preview);

            _rightPane = new ScrollView(ScrollViewMode.Vertical)
            {
                horizontalScrollerVisibility = ScrollerVisibility.Hidden,
                verticalScrollerVisibility = ScrollerVisibility.Auto,
            };
            _rightPane.AddToClassList("shapepick-right");
            _split.Add(_rightPane);

            BuildTutorial();
            BuildSettingsPanel();
            BuildTargetSection();
            BuildSlotSection();
            BuildViewSection();
            BuildTabs();

            _hint = new HintBar();
            root.Add(_hint);

            _toast = new Label();
            _toast.AddToClassList("shapepick-toast");
            _toast.style.display = DisplayStyle.None;
            _toast.pickingMode = PickingMode.Ignore;
            root.Add(_toast);

            _built = true;
        }

        private void BuildTutorial()
        {
            if (EditorPrefs.GetBool(PrefTutorialDone, false)) return;

            _tutorial = new VisualElement();
            _tutorial.AddToClassList("shapepick-tutorial");
            var title = new Label(L.T(L.Key.TutorialTitle));
            title.AddToClassList("shapepick-tutorial__title");
            _tutorial.Add(title);
            foreach (var k in new[] { L.Key.TutorialStep1, L.Key.TutorialStep2, L.Key.TutorialStep3 })
            {
                var step = new Label(L.F(k, L.LabelA));
                step.AddToClassList("shapepick-tutorial__step");
                _tutorial.Add(step);
            }
            var footer = new VisualElement();
            footer.AddToClassList("shapepick-tutorial__footer");
            var dontShow = new Toggle(L.T(L.Key.TutorialDontShowAgain));
            var close = new Button(() =>
            {
                if (dontShow.value) EditorPrefs.SetBool(PrefTutorialDone, true);
                _tutorial.RemoveFromHierarchy();
                _tutorial = null;
            }) { text = L.T(L.Key.TutorialClose) };
            footer.Add(dontShow);
            footer.Add(close);
            _tutorial.Add(footer);
            _rightPane.Add(_tutorial);
        }

        private void BuildSettingsPanel()
        {
            _settingsPanel = new VisualElement();
            _settingsPanel.AddToClassList("shapepick-settings");
            _settingsPanel.style.display = DisplayStyle.None;

            var title = new Label(L.T(L.Key.SettingsSection));
            title.AddToClassList("shapepick-section__title");
            _settingsPanel.Add(title);

            var lang = new DropdownField(L.T(L.Key.SettingsLanguage), new List<string> { "日本語", "English" }, L.IsEnglish ? 1 : 0);
            lang.RegisterValueChangedCallback(_ => L.Language = lang.index == 1 ? "en" : "ja");
            _settingsPanel.Add(lang);

            // スロットの既定名の接頭辞（既定「候補」→ 候補1・候補2 …）。変えるとボタン・帯・ヒント・差分表の見出しが追従する
            var slotPrefix = new TextField(L.T(L.Key.SettingsSlotPrefix)) { value = ShapePickSettings.SlotLabelPrefix, isDelayed = true, tooltip = L.T(L.Key.TipSettingsSlotLabel) };
            var slotPrefixHint = new Label();
            slotPrefixHint.AddToClassList("bs-settings-hint");
            slotPrefixHint.style.opacity = 0.7f;
            slotPrefixHint.style.marginLeft = 4;
            slotPrefixHint.style.marginBottom = 4;
            void UpdateSlotPrefixHint() =>
                slotPrefixHint.text = SnapshotSet.DefaultLabel(SnapshotSet.SlotA) + " / " + SnapshotSet.DefaultLabel(SnapshotSet.SlotB) + " …";
            UpdateSlotPrefixHint();
            slotPrefix.RegisterValueChangedCallback(evt =>
            {
                ShapePickSettings.SlotLabelPrefix = evt.newValue;
                slotPrefix.SetValueWithoutNotify(ShapePickSettings.SlotLabelPrefix);
                UpdateSlotPrefixHint();
                L.RaiseTextsChanged();
            });
            _settingsPanel.Add(slotPrefix);
            _settingsPanel.Add(slotPrefixHint);

            var autoRestore = new Toggle(L.T(L.Key.SettingsAutoRestore)) { value = ShapePickSettings.AutoRestoreOnClose };
            autoRestore.RegisterValueChangedCallback(evt => ShapePickSettings.AutoRestoreOnClose = evt.newValue);
            _settingsPanel.Add(autoRestore);

            var resolutions = new List<string> { "256", "512", "1024" };
            int resIndex = Mathf.Max(0, resolutions.IndexOf(ShapePickSettings.PreviewResolution.ToString()));
            var resolution = new DropdownField(L.T(L.Key.SettingsResolution), resolutions, resIndex);
            resolution.RegisterValueChangedCallback(evt =>
            {
                if (int.TryParse(evt.newValue, out int r)) ShapePickSettings.PreviewResolution = r;
                _previewCoordinator?.MarkAllDirty();
            });
            _settingsPanel.Add(resolution);

            var resetFraming = new Button(() =>
            {
                ShapePickSettings.DefaultCameraPresetJson = string.Empty;
                _previewCoordinator?.FitToFace();
                ShowToast(L.T(L.Key.ToastFramingReset));
            }) { text = L.T(L.Key.SettingsResetFraming) };
            _settingsPanel.Add(resetFraming);

            var blink = new TextField(L.T(L.Key.SettingsBlinkPattern)) { value = ShapePickSettings.BlinkPattern, isDelayed = true };
            blink.RegisterValueChangedCallback(evt => { ShapePickSettings.BlinkPattern = evt.newValue; _shapeKeys?.ReloadPatterns(); });
            _settingsPanel.Add(blink);
            var lip = new TextField(L.T(L.Key.SettingsLipSyncPattern)) { value = ShapePickSettings.LipSyncPattern, isDelayed = true };
            lip.RegisterValueChangedCallback(evt => { ShapePickSettings.LipSyncPattern = evt.newValue; _shapeKeys?.ReloadPatterns(); });
            _settingsPanel.Add(lip);

            _rightPane.Add(_settingsPanel);
        }

        private VisualElement AddSection(L.Key titleKey)
        {
            var section = new VisualElement();
            section.AddToClassList("shapepick-section");
            var title = new Label(L.T(titleKey));
            title.AddToClassList("shapepick-section__title");
            section.Add(title);
            _rightPane.Add(section);
            return section;
        }

        private void BuildTargetSection()
        {
            var section = AddSection(L.Key.TargetSection);

            _targetField = new ObjectField(L.T(L.Key.TargetField))
            {
                objectType = typeof(SkinnedMeshRenderer),
                allowSceneObjects = true,
            };
            _targetField.RegisterValueChangedCallback(evt =>
            {
                if (_suppressUiEvents) return;
                var r = evt.newValue as SkinnedMeshRenderer;
                if (r == null) SetTarget(null);
                else if (RendererResolver.IsEligible(r)) SetTarget(r);
                else
                {
                    // シェイプキー 0 件のレンダラー: 対象にはせず案内だけ出す
                    SetTarget(null);
                    _hint.SetText(L.T(L.Key.HintNoShapeKeys), warning: true);
                }
            });
            section.Add(_targetField);

            var row = new VisualElement();
            row.AddToClassList("shapepick-target-row");
            _targetDropdown = new DropdownField(L.T(L.Key.TargetDropdown), new List<string>(), -1);
            _targetDropdown.RegisterValueChangedCallback(_ =>
            {
                if (_suppressUiEvents) return;
                int i = _targetDropdown.index;
                if (i >= 0 && i < _candidates.Count) SetTarget(_candidates[i]);
            });
            row.Add(_targetDropdown);
            _countLabel = new Label();
            _countLabel.AddToClassList("shapepick-muted");
            row.Add(_countLabel);
            section.Add(row);

            // 「適用先」は常時表示する。Shinano と Shinano (1) のように名前が紛らわしくても
            // どちらの体を触っているか読み取れるよう、シーンとフルパスも下に添える
            _applyTarget = new Label { tooltip = L.T(L.Key.TipApplyTarget) };
            _applyTarget.AddToClassList("shapepick-applytarget");
            section.Add(_applyTarget);

            _applyTargetDetail = new Label { tooltip = L.T(L.Key.TipApplyTarget) };
            _applyTargetDetail.AddToClassList("shapepick-applytarget__detail");
            _applyTargetDetail.AddToClassList("shapepick-muted");
            section.Add(_applyTargetDetail);

            // 紐づけが切れた候補（置き直す前のアバターのもの等）が残っていれば、引き継ぎを案内する。無ければ出さない
            _adoptBanner = new VisualElement();
            _adoptBanner.AddToClassList("shapepick-adopt");
            _adoptLabel = new Label();
            _adoptBanner.Add(_adoptLabel);
            var adoptOpen = new Button(() =>
            {
                if (_controller != null) AdoptWindow.Open(_controller);
            }) { text = L.T(L.Key.AdoptOpen), tooltip = L.T(L.Key.TipAdoptOpen) };
            _adoptBanner.Add(adoptOpen);
            var adoptDismiss = new Button(() => _controller?.DismissAdoptable()) { text = "×", tooltip = L.T(L.Key.TipAdoptDismiss) };
            adoptDismiss.AddToClassList("shapepick-adopt__dismiss");
            _adoptBanner.Add(adoptDismiss);
            _adoptBanner.style.display = DisplayStyle.None;
            section.Add(_adoptBanner);

            // 主ボタンは「上のプレビューに出している候補」を上書きする（F3 検証の指摘 9/13）。候補が無いうちは候補1 を登録
            _registerPrimary = new Button(() =>
            {
                if (_controller == null) return;
                _controller.RegisterSlot(ResolvePrimaryTargetSlot(_topSource, _bottomSource, _controller.IsSlotRegistered));
            }) { text = L.F(L.Key.BtnRegisterA, L.LabelA) };
            _registerPrimary.AddToClassList("shapepick-primary");
            _rightPane.Add(_registerPrimary);
        }

        private void BuildSlotSection()
        {
            var section = AddSection(L.Key.SlotSection);
            _slots = new SlotCardsView();
            _slots.RegisterRequested += slot => _controller?.RegisterSlot(slot);
            _slots.ShowRequested += slot => _controller?.ShowSlot(slot);
            _slots.ApplyRequested += slot => _controller?.ApplySlot(slot);
            _slots.RenameRequested += (slot, name) => _controller?.RenameSlot(slot, name);
            _slots.MemoChanged += (slot, memo) => _controller?.SetMemo(slot, memo);
            _slots.ClearRequested += slot => _controller?.ClearSlot(slot);
            _slots.RemoveRequested += slot => _controller?.RemoveSlot(slot);
            _slots.AddRequested += () => _controller?.AddSlot();
            // サムネイルのクリックで上のプレビューへ、ドラッグで上下どちらかへ（yayo 依頼 2）
            _slots.PreviewRequested += slot => SetPreviewSource(0, slot);
            _slots.DragStarted += (slot, pos) => _preview.SetDropHighlight(_preview.HitPane(pos));
            _slots.DragMoved += (slot, pos) => _preview.SetDropHighlight(_preview.HitPane(pos));
            _slots.DragEnded += (slot, pos) =>
            {
                _preview.SetDropHighlight(-1);
                int pane = _preview.HitPane(pos);
                if (pane >= 0) SetPreviewSource(pane, slot);
            };
            section.Add(_slots);
        }

        /// <summary>上下のプレビュー（と差分表の左右）に出すものを切り替える。</summary>
        private void SetPreviewSource(int pane, int source)
        {
            if (_controller == null) return;
            if (source != SnapshotSet.LiveSource && !_controller.IsSlotRegistered(source)) return;
            if (pane == 0) _topSource = source; else _bottomSource = source;
            _sourcesChosen = true;
            RefreshAll();
        }

        /// <summary>カードが消えて後ろの番号が詰まったとき、上下のソースが指す番号を追従させる。</summary>
        private void OnSlotRemoved(int slot)
        {
            if (_topSource == slot) { _topSource = SnapshotSet.LiveSource; _topRemoved = true; }
            else if (_topSource > slot) _topSource--;
            if (_bottomSource == slot) _bottomSource = SnapshotSet.LiveSource;
            else if (_bottomSource > slot) _bottomSource--;
        }

        /// <summary>登録状況に合わせて上下のソースを整える（消えたスロットは外す。初めての登録は上に出す）。</summary>
        private void ValidateSources(ShapePickController c)
        {
            _registeredSlots.Clear();
            c.Set?.GetRegisteredSlots(_registeredSlots);
            if (_bottomSource != SnapshotSet.LiveSource && !_registeredSlots.Contains(_bottomSource))
                _bottomSource = SnapshotSet.LiveSource;
            // 上に出していた候補が消えた（空にした・削除した）ら、現在値ではなく残っている候補を上に出す。
            // 上下とも現在値になって「現在値と現在値に違いはありません」と出るのを避ける（F4 検証の指摘 9/14）
            if (_topRemoved || (_topSource != SnapshotSet.LiveSource && !_registeredSlots.Contains(_topSource)))
                _topSource = PickFallbackTopSource(_registeredSlots, _bottomSource);
            _topRemoved = false;
            // 上下とも現在値なのは初期状態としては役に立たないので、自分で選ぶまでは上に候補を出しておく。
            // 一度でも自分で選んだら、上下とも現在値にする選択も尊重する（yayo 指摘 9/13）
            if (!_sourcesChosen && _topSource == SnapshotSet.LiveSource && _bottomSource == SnapshotSet.LiveSource && _registeredSlots.Count > 0)
                _topSource = _registeredSlots[0];
        }

        /// <summary>
        /// 上に出していた候補が消えたときに代わりに上に出すもの。下と同じにならない候補を登録順で選び、
        /// 無ければ現在値。
        /// </summary>
        public static int PickFallbackTopSource(IList<int> registeredSlots, int bottomSource)
        {
            if (registeredSlots != null)
            {
                foreach (int slot in registeredSlots)
                    if (slot != bottomSource) return slot;
            }
            return SnapshotSet.LiveSource;
        }

        /// <summary>
        /// 主ボタン（登録・上書き）の対象スロット。上のプレビューに出している候補、上が現在値なら下の候補、
        /// どちらも現在値なら候補1。プレビューに出せるのは登録済みの候補か現在値だけなので、
        /// 戻り値は「登録済みの候補」か候補1 のどちらか。
        /// </summary>
        public static int ResolvePrimaryTargetSlot(int topSource, int bottomSource, System.Predicate<int> isRegistered)
        {
            if (isRegistered != null)
            {
                if (topSource >= 0 && isRegistered(topSource)) return topSource;
                if (bottomSource >= 0 && isRegistered(bottomSource)) return bottomSource;
            }
            return SnapshotSet.SlotA;
        }

        private string SourceLabel(ShapePickController c, int source)
        {
            if (source == SnapshotSet.LiveSource) return L.T(L.Key.ViewLive);
            return c.Set != null ? c.Set.DisplayLabel(source) : SnapshotSet.DefaultLabel(source);
        }

        private void RefreshPreviewSources(ShapePickController c)
        {
            _sourceNames.Clear();
            _sourceIds.Clear();
            foreach (var s in _registeredSlots)
            {
                _sourceNames.Add(c.Set.DisplayLabel(s));
                _sourceIds.Add(s);
            }
            _sourceNames.Add(L.T(L.Key.ViewLive));
            _sourceIds.Add(SnapshotSet.LiveSource);
            _preview.SetSources(_sourceNames, _sourceIds, _topSource, _bottomSource);
        }

        private void BuildViewSection()
        {
            var section = AddSection(L.Key.ViewSection);
            var row = new VisualElement();
            row.AddToClassList("shapepick-row");

            _viewRow = row;
            _viewLive = MakeToggle(() => _controller?.ShowLive());
            row.Add(_viewLive);

            _peekA = new Button();
            _peekA.AddToClassList("shapepick-peek");
            _peekA.RegisterCallback<PointerDownEvent>(evt =>
            {
                if (evt.button != 0 || _controller == null) return;
                if (_controller.BeginPeek(SnapshotSet.SlotA)) _peekA.AddToClassList("shapepick-peek--active");
            }, TrickleDown.TrickleDown);
            _peekA.RegisterCallback<PointerUpEvent>(_ => EndPeek());
            _peekA.RegisterCallback<PointerCaptureOutEvent>(_ => EndPeek());
            _peekA.RegisterCallback<PointerLeaveEvent>(_ => EndPeek());
            // 1.0.0 では非表示（検証 V1-6 で動作せず。1.0.x で作り直す）。状態機械の Peek はそのまま残す
            _peekA.style.display = DisplayStyle.None;
            row.Add(_peekA);

            section.Add(row);
        }

        private static Button MakeToggle(System.Action onClick)
        {
            var b = new Button(onClick);
            b.AddToClassList("shapepick-toggle");
            return b;
        }

        private void BuildTabs()
        {
            var tabs = new VisualElement();
            tabs.AddToClassList("shapepick-tabs");
            _tabDiff = new Button(() => SelectTab(0)) { text = L.T(L.Key.TabDiff) };
            _tabDiff.AddToClassList("shapepick-tab");
            _tabKeys = new Button(() => SelectTab(1)) { text = L.T(L.Key.TabShapeKeys) };
            _tabKeys.AddToClassList("shapepick-tab");
            tabs.Add(_tabDiff);
            tabs.Add(_tabKeys);
            var settingsButton = new Button(() =>
            {
                bool show = _settingsPanel.style.display == DisplayStyle.None;
                _settingsPanel.style.display = show ? DisplayStyle.Flex : DisplayStyle.None;
            }) { text = L.T(L.Key.SettingsButton), tooltip = L.T(L.Key.SettingsSection) };
            settingsButton.AddToClassList("shapepick-settings-btn");
            tabs.Add(settingsButton);
            _rightPane.Add(tabs);

            _diffContent = new VisualElement();
            _diffContent.AddToClassList("shapepick-tab-content");
            _diff = new DiffListView();
            _diff.AdoptRequested += (name, value) => _controller?.ApplyEntry(name, value);
            _diffContent.Add(_diff);
            _rightPane.Add(_diffContent);

            _keysContent = new VisualElement();
            _keysContent.AddToClassList("shapepick-tab-content");
            _shapeKeys = new ShapeKeyListView(_controller);
            _keysContent.Add(_shapeKeys);
            _rightPane.Add(_keysContent);

            SelectTab(EditorPrefs.GetInt(PrefTab, 0));
        }

        public void SelectTab(int index)
        {
            _tab = index;
            EditorPrefs.SetInt(PrefTab, index);
            _tabDiff.EnableInClassList("shapepick-tab--on", index == 0);
            _tabKeys.EnableInClassList("shapepick-tab--on", index == 1);
            _diffContent.style.display = index == 0 ? DisplayStyle.Flex : DisplayStyle.None;
            _keysContent.style.display = index == 1 ? DisplayStyle.Flex : DisplayStyle.None;
            if (index == 1 && _controller != null) _shapeKeys.RefreshValues();
        }

        private void SaveSplit()
        {
            if (_leftPane == null) return;
            float w = _leftPane.resolvedStyle.width;
            if (w > 0f && !float.IsNaN(w)) EditorPrefs.SetFloat(PrefSplit, w);
        }

        // ------------------------------------------------------------------ 対象

        private void OnSelectionChanged()
        {
            if (!_built || _controller == null) return;
            ApplySelection(Selection.activeGameObject);
        }

        /// <summary>Hierarchy の選択から対象を決める（FR-01）。対象が見つからない選択では現在の対象を保つ。</summary>
        private void ApplySelection(GameObject selected)
        {
            if (_controller == null) return;
            var r = RendererResolver.ResolveDefault(selected);
            if (r != null && r != _controller.Target) SetTarget(r);
        }

        private void SetTarget(SkinnedMeshRenderer renderer)
        {
            // 候補は StateChanged → RefreshAll の前に用意しておく（後に埋めると初回表示でドロップダウンが空になる）
            _candidates.Clear();
            if (RendererResolver.IsEligible(renderer))
            {
                RendererResolver.FindCandidates(renderer.transform.root.gameObject, _candidates);
                if (!_candidates.Contains(renderer)) _candidates.Insert(0, renderer);
            }
            // 対象が変わったら、その体での既定の組み合わせから始める
            _sourcesChosen = false;
            _controller.SetTarget(renderer);
        }

        // ------------------------------------------------------------------ 更新

        private void RefreshAll()
        {
            if (!_built || _controller == null) return;
            var c = _controller;
            _suppressUiEvents = true;
            try
            {
                _targetField.SetValueWithoutNotify(c.Target);

                // 破棄された候補は先に除いて、ドロップダウンの index と _candidates の index を一致させる
                _candidates.RemoveAll(r => r == null || r.sharedMesh == null);
                var choices = new List<string>(_candidates.Count);
                int current = -1;
                for (int i = 0; i < _candidates.Count; i++)
                {
                    var r = _candidates[i];
                    choices.Add(r.name + " (" + r.sharedMesh.blendShapeCount + ")");
                    if (r == c.Target) current = i;
                }
                _targetDropdown.choices = choices;
                _targetDropdown.index = current;
                // 候補が 1 つしか無いのに押せないドロップダウンを見せない（無効ボタンの残置を避ける）
                _targetDropdown.style.display = choices.Count > 1 ? DisplayStyle.Flex : DisplayStyle.None;
                _countLabel.text = c.HasTarget ? L.F(L.Key.ShapeKeyCount, c.BlendShapeCount) : L.T(L.Key.TargetNone);

                RefreshApplyTarget(c);

                // 上下のプレビューの出しものを先に確定させる（主ボタンの対象がこれで決まる）
                ValidateSources(c);

                // 主ボタンの対象は「上のプレビューに出している候補」。登録済みなら「更新（上書き）」にして色を一段落とす。位置は変えない
                int primarySlot = ResolvePrimaryTargetSlot(_topSource, _bottomSource, c.IsSlotRegistered);
                bool primaryRegistered = c.IsSlotRegistered(primarySlot);
                bool canRegisterPrimary = c.CanRegister(primarySlot);
                string primaryLabel = c.Set != null ? c.Set.DisplayLabel(primarySlot) : SnapshotSet.DefaultLabel(primarySlot);
                _registerPrimary.SetEnabled(canRegisterPrimary);
                _registerPrimary.text = L.F(primaryRegistered ? L.Key.BtnUpdateA : L.Key.BtnRegisterA, primaryLabel);
                _registerPrimary.EnableInClassList("shapepick-primary--secondary", primaryRegistered);
                _registerPrimary.tooltip = canRegisterPrimary ? (primaryRegistered ? L.F(L.Key.TipUpdateA, primaryLabel) : L.T(L.Key.TipRegister))
                    : !c.HasTarget ? L.T(L.Key.TipRegisterDisabledNoTarget)
                    : L.T(L.Key.TipRegisterDisabledShowing);

                // チュートリアルは最初の候補を登録できた時点で役目を終える
                if (_tutorial != null && c.IsSlotRegistered(SnapshotSet.SlotA))
                {
                    _tutorial.RemoveFromHierarchy();
                    _tutorial = null;
                }

                _slots.Refresh(c, _topSource, _bottomSource);
                RefreshViewButtons(c);
                RefreshBanner(c);
                RefreshPreviewSources(c);
                _shapeKeys.Rebuild();
            }
            finally
            {
                _suppressUiEvents = false;
            }

            RefreshDiff();
        }

        private void RefreshViewButtons(ShapePickController c)
        {
            string aLabel = c.Set != null ? c.Set.DisplayLabel(SnapshotSet.SlotA) : SnapshotSet.DefaultLabel(SnapshotSet.SlotA);

            // 登録済みスロットのぶんだけボタンを並べる（yayo 依頼 8: 未登録のボタンは出さない）
            foreach (var b in _viewSlotButtons) b.RemoveFromHierarchy();
            _viewSlotButtons.Clear();
            int insertAt = 0;
            foreach (var slot in _registeredSlots)
            {
                int s = slot;
                string label = c.Set.DisplayLabel(s);
                var b = MakeToggle(() => _controller?.ShowSlot(s));
                b.text = label;
                b.tooltip = L.F(L.Key.TipViewSlot, label);
                b.SetEnabled(c.CanShow(s));
                b.EnableInClassList(s == SnapshotSet.SlotB ? "shapepick-toggle--on-b" : "shapepick-toggle--on", c.Mode == ViewMode.Slot && c.ShownSlot == s);
                _viewRow.Insert(insertAt++, b);
                _viewSlotButtons.Add(b);
            }
            _viewLive.text = L.T(L.Key.ViewLive);
            _viewLive.tooltip = L.T(L.Key.TipViewLive);
            _viewLive.SetEnabled(c.HasTarget && c.Mode != ViewMode.Peek);
            _viewLive.EnableInClassList("shapepick-toggle--on", c.Mode == ViewMode.Live && c.HasTarget);
            // 登録が無いあいだは「現在値」しか無いので節ごと隠す
            _viewRow.parent.style.display = _registeredSlots.Count > 0 ? DisplayStyle.Flex : DisplayStyle.None;

            _peekA.text = L.F(L.Key.ViewPeek, aLabel);
            _peekA.tooltip = L.F(L.Key.TipViewPeek, aLabel);
            _peekA.SetEnabled(c.HasTarget && c.IsSlotRegistered(SnapshotSet.SlotA) && (c.Mode == ViewMode.Live || c.Mode == ViewMode.Peek));
            _peekA.EnableInClassList("shapepick-peek--active", c.Mode == ViewMode.Peek);
        }

        private void RefreshBanner(ShapePickController c)
        {
            _banner.RemoveFromClassList("shapepick-banner--a");
            _banner.RemoveFromClassList("shapepick-banner--b");
            _banner.RemoveFromClassList("shapepick-banner--peek");

            if (c.Mode == ViewMode.Live || !c.HasTarget)
            {
                _banner.style.display = DisplayStyle.None;
                return;
            }

            string label = c.Set != null ? c.Set.DisplayLabel(c.ShownSlot) : "?";
            _banner.style.display = DisplayStyle.Flex;
            _bannerBack.text = L.T(L.Key.BannerBackToLive);
            _bannerBack.style.display = c.Mode == ViewMode.Slot ? DisplayStyle.Flex : DisplayStyle.None;
            if (c.Mode == ViewMode.Peek)
            {
                _bannerLabel.text = L.F(L.Key.BannerPeeking, label);
                _banner.AddToClassList("shapepick-banner--peek");
            }
            else
            {
                _bannerLabel.text = L.F(L.Key.BannerShowingSlot, label);
                _banner.AddToClassList(c.ShownSlot == SnapshotSet.SlotB ? "shapepick-banner--b" : "shapepick-banner--a");
            }
        }

        /// <summary>差分表は「上のプレビュー vs 下のプレビュー」。ソースは候補か現在値。</summary>
        private void RefreshDiff()
        {
            if (!_built || _controller == null) return;
            var c = _controller;
            bool leftIsLive = _topSource == SnapshotSet.LiveSource;
            bool rightIsLive = _bottomSource == SnapshotSet.LiveSource;
            bool topReady = c.HasTarget && (leftIsLive || c.IsSlotRegistered(_topSource));
            bool bottomReady = c.HasTarget && (rightIsLive || c.IsSlotRegistered(_bottomSource));
            bool same = _topSource == _bottomSource;
            string leftLabel = SourceLabel(c, _topSource);
            string rightLabel = SourceLabel(c, _bottomSource);
            string aLabel = c.Set != null ? c.Set.DisplayLabel(SnapshotSet.SlotA) : SnapshotSet.DefaultLabel(SnapshotSet.SlotA);

            IReadOnlyList<BlendShapeEntry> left = null, right = null;
            if (topReady && bottomReady && !same)
            {
                var live = leftIsLive || rightIsLive ? c.RefreshLiveSnapshot().entries : null;
                left = leftIsLive ? live : c.GetSlot(_topSource).entries;
                right = rightIsLive ? live : c.GetSlot(_bottomSource).entries;
            }

            // 空状態の案内は状態ごとに変える（英語の "List is empty" を出さない）
            _diff.SetEmptyMessage(!c.HasTarget ? L.T(L.Key.EmptyDiffNoTarget)
                : _registeredSlots.Count == 0 ? L.F(L.Key.EmptyDiffNoA, aLabel)
                : same ? L.T(L.Key.EmptyDiffSame)
                : !topReady || !bottomReady ? L.T(L.Key.EmptyDiffNoSource)
                : L.F(L.Key.EmptyDiffNoChanges, leftLabel, rightLabel));
            _diff.SetSource(left, right, leftLabel, rightLabel, rightIsLive, leftIsLive);
            _diff.SetAdoptEnabled(c.HasTarget && c.Mode != ViewMode.Peek);

            bool otherMesh = false;
            foreach (var s in new[] { _topSource, _bottomSource })
            {
                var snap = s == SnapshotSet.LiveSource ? null : c.GetSlot(s);
                if (snap != null && snap.IsRegistered && c.HasTarget && RendererResolver.IsOtherMesh(snap, c.Target.sharedMesh)) otherMesh = true;
            }
            _hint.UpdateFrom(c, _diff.ChangedCount, otherMesh, leftLabel, rightLabel, same);

            _previewCoordinator?.SetSources(_topSource, _bottomSource);
            if (_tab == 1) _shapeKeys.RefreshValues();
        }

        /// <summary>「適用先」の表示と、引き継ぎ提示の帯を更新する。</summary>
        private void RefreshApplyTarget(ShapePickController c)
        {
            bool has = c.HasTarget;
            _applyTarget.style.display = has ? DisplayStyle.Flex : DisplayStyle.None;
            _applyTargetDetail.style.display = has ? DisplayStyle.Flex : DisplayStyle.None;

            if (has)
            {
                var avatar = PreviewObjectResolver.FindAvatarRoot(c.Target);
                string avatarName = avatar != null ? avatar.name : c.Target.name;
                _applyTarget.text = L.F(L.Key.ApplyTarget, avatarName, c.Target.name);

                var scene = c.Target.gameObject.scene;
                string scenePrefix = scene.IsValid() && !string.IsNullOrEmpty(scene.path) ? scene.path + " · " : string.Empty;
                _applyTargetDetail.text = L.F(L.Key.ApplyTargetDetail, scenePrefix, RendererResolver.GetHierarchyPath(c.Target.transform));
            }

            int adoptable = has ? c.AdoptableSlotCount : 0;
            _adoptBanner.style.display = adoptable > 0 ? DisplayStyle.Flex : DisplayStyle.None;
            if (adoptable > 0) _adoptLabel.text = L.F(L.Key.AdoptBanner, adoptable);
        }

        private void OnSaveFailed(string path, string message)
        {
            if (!_built) return;
            _saveBannerLabel.text = L.F(L.Key.ToastSaveFailed, path) + (string.IsNullOrEmpty(message) ? "" : " — " + message);
            _saveBanner.style.display = DisplayStyle.Flex;
        }

        private void EndPeek()
        {
            if (_controller == null) return;
            _controller.EndPeek();
            _peekA.RemoveFromClassList("shapepick-peek--active");
        }

        private void ShowToast(string message)
        {
            if (!_built) return;
            _toast.text = message;
            _toast.style.display = DisplayStyle.Flex;
            _toastHide?.Pause();
            _toastHide = _toast.schedule.Execute(() => _toast.style.display = DisplayStyle.None);
            _toastHide.ExecuteLater(ToastMilliseconds);
        }

        // ------------------------------------------------------------------ 外部イベント

        private const double DiffRefreshDebounceSec = 0.1;
        private double _diffRefreshRequestedAt = -1;

        /// <summary>
        /// 現在値の変化通知を 100 ms でまとめて差分表を更新する（性能指針 4.4「変化検知はデバウンス」）。
        /// シェイプキータブのスライダー操作は 1 ドラッグで数十回 LiveChanged を出すため、直接 RefreshDiff しない。
        /// </summary>
        private void RequestDiffRefresh()
        {
            if (_diffRefreshRequestedAt < 0) _diffRefreshRequestedAt = EditorApplication.timeSinceStartup;
        }

        private void OnEditorUpdate()
        {
            double now = EditorApplication.timeSinceStartup;
            _controller?.Tick(now);
            // Play 中は Hierarchy が動き続けるので調べ直さない（抜けたときにまとめて 1 回）
            if (_adoptableDirty && _controller != null && !EditorApplication.isPlayingOrWillChangePlaymode)
            {
                _adoptableDirty = false;
                // 変わったときだけ描き直す（開いている引き継ぎの一覧も StateChanged で作り直される）
                if (_controller.RefreshAdoptable()) _controller.NotifyStateChanged();
            }
            if (_diffRefreshRequestedAt >= 0 && now - _diffRefreshRequestedAt >= DiffRefreshDebounceSec)
            {
                _diffRefreshRequestedAt = -1;
                RefreshDiff();
            }
            if (_built) _previewCoordinator?.Tick();
        }

        private void OnUndoRedo(in UndoRedoInfo info)
        {
            // 名前も渡す。現在値の表示中に「表示切替」が Undo / Redo されたら、候補の値を現在値として残さない
            _controller?.HandleUndoRedo(info.undoName);
        }

        private void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.ExitingEditMode)
            {
                // 遷移前に現在値へ戻し、プレビュー資源を解放する（3.7）。CreateGUI が再度呼ばれたときに作り直す
                _controller?.RestoreForExit();
                _previewCoordinator?.Dispose();
                _previewCoordinator = null;
                RefreshAll();
            }
            else if (state == PlayModeStateChange.EnteredEditMode && _built && _previewCoordinator == null && _controller != null)
            {
                _previewCoordinator = new PreviewCoordinator(_controller, _preview);
                RefreshAll();
            }
        }

        private void OnBeforeAssemblyReload()
        {
            _controller?.RestoreForExit();
            SnapshotSetRepository.FlushPendingSaves();
        }

        private void OnLanguageChanged()
        {
            if (!_built) return;
            titleContent = new GUIContent(L.T(L.Key.WindowTitle));
            // 言語ドロップダウンの ChangeEvent 内から発火元を破棄しないよう、再構築は次のエディタ更新へ回す
            EditorApplication.delayCall += () =>
            {
                if (_controller == null) return;
                bool settingsOpen = _settingsPanel != null && _settingsPanel.style.display == DisplayStyle.Flex;
                BuildUI();
                if (settingsOpen) _settingsPanel.style.display = DisplayStyle.Flex; // 設定を開いたまま名前を試せるように
                RefreshAll();
            };
        }

        /// <summary>プレビューのカメラを既定の構図に戻す（［顔に合わせる］と同じ。開発用フックからも使う）。</summary>
        public void ResetPreviewCamera()
        {
            _previewCoordinator?.FitToFace();
        }
    }
}
