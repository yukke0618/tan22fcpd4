using ShapePick.Services;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>ウィンドウ最下部に常設する 1 行のヒント（FR-19 (3) / FR-21）。状態に応じて文言を切り替える。</summary>
    public sealed class HintBar : VisualElement
    {
        private readonly Label _label;

        public HintBar()
        {
            AddToClassList("shapepick-hint");
            _label = new Label();
            _label.AddToClassList("shapepick-hint__text");
            Add(_label);
        }

        public void SetText(string text, bool warning = false)
        {
            _label.text = text;
            EnableInClassList("shapepick-hint--warning", warning);
        }

        /// <summary>コントローラの状態からヒント文を決める。diffCount は差分表の行数（欠損行を除く）。sameSource は上下のプレビューが同じものか。</summary>
        public void UpdateFrom(ShapePickController controller, int diffCount, bool otherMeshWarning, string leftLabel = null, string rightLabel = null, bool sameSource = false)
        {
            if (controller == null || !controller.HasTarget)
            {
                bool hasRendererButNoShapes = controller != null && controller.Target != null && controller.BlendShapeCount == 0;
                SetText(L.T(hasRendererButNoShapes ? L.Key.HintNoShapeKeys : L.Key.HintNoTarget));
                return;
            }

            switch (controller.Mode)
            {
                case ViewMode.Peek:
                    SetText(L.T(L.Key.HintPeeking));
                    return;
                case ViewMode.Slot:
                    SetText(L.F(L.Key.HintShowingSlot, controller.Set != null ? controller.Set.DisplayLabel(controller.ShownSlot) : "?"), warning: true);
                    return;
            }

            if (otherMeshWarning)
            {
                SetText(L.T(L.Key.HintOtherMesh), warning: true);
                return;
            }

            string a = controller.Set != null ? controller.Set.DisplayLabel(Data.SnapshotSet.SlotA) : L.LabelA;
            if (controller.Set == null || controller.Set.RegisteredSlotCount == 0)
            {
                SetText(L.F(L.Key.HintNoA, a));
                return;
            }

            // 上下が同じだと「現在値と現在値に違いはありません」になり読みにくいので、差分表と同じ案内にする
            if (sameSource)
            {
                SetText(L.T(L.Key.EmptyDiffSame));
                return;
            }

            string left = string.IsNullOrEmpty(leftLabel) ? a : leftLabel;
            string right = string.IsNullOrEmpty(rightLabel) ? L.T(L.Key.ViewLive) : rightLabel;
            SetText(diffCount > 0 ? L.F(L.Key.HintReadyDiff, left, diffCount, right) : L.F(L.Key.HintReadyNoDiff, left, 0, right));
        }
    }
}
