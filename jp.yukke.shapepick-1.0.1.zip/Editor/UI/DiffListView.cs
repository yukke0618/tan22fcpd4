using System;
using System.Collections.Generic;
using ShapePick.Data;
using ShapePick.Services;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;

namespace ShapePick.UI
{
    /// <summary>
    /// 差分表（FR-08 / FR-09）。MultiColumnListView の固定行高仮想化で 1,000 行でも可視行だけ描く（PF-06）。
    /// 列: シェイプキー / 左値 / 右値 / 差 / バー / 採用（← →）。
    /// </summary>
    public sealed class DiffListView : VisualElement
    {
        private const float RowHeight = 22f;
        private const string ColName = "name";
        private const string ColLeft = "left";
        private const string ColRight = "right";
        private const string ColDelta = "delta";
        private const string ColBar = "bar";
        private const string ColActions = "actions";

        private readonly DiffCalculator _calc = new DiffCalculator();
        private readonly List<DiffRow> _all = new List<DiffRow>(256);
        private readonly List<DiffRow> _view = new List<DiffRow>(256);
        private readonly MultiColumnListView _list;
        private readonly ToolbarSearchField _filter;
        private readonly FloatField _threshold;
        private readonly Button _sortButton;
        private readonly Label _footer;

        private IReadOnlyList<BlendShapeEntry> _left;
        private IReadOnlyList<BlendShapeEntry> _right;
        private float _maxAbs = 1f;
        private bool _sortByDelta = true;
        private bool _adoptEnabled = true;

        /// <summary>採用ボタンが押された（シェイプキー名, 採用する値）。</summary>
        public event Action<string, float> AdoptRequested;

        /// <summary>欠損行を除いた差分行数。</summary>
        public int ChangedCount { get; private set; }

        public DiffListView()
        {
            AddToClassList("shapepick-diff");

            var toolbar = new VisualElement();
            toolbar.AddToClassList("shapepick-diff__toolbar");
            _filter = new ToolbarSearchField();
            _filter.AddToClassList("shapepick-diff__filter");
            _filter.tooltip = L.T(L.Key.TipFilter);
            _filter.RegisterValueChangedCallback(_ => RebuildView());
            toolbar.Add(_filter);

            _threshold = new FloatField(L.T(L.Key.DiffThreshold)) { value = ShapePickSettings.DiffThreshold, isDelayed = true };
            _threshold.AddToClassList("shapepick-diff__threshold");
            _threshold.tooltip = L.T(L.Key.TipThreshold);
            _threshold.RegisterValueChangedCallback(evt =>
            {
                float v = Mathf.Max(0f, evt.newValue);
                if (v != evt.newValue) _threshold.SetValueWithoutNotify(v);
                ShapePickSettings.DiffThreshold = v;
                Recompute();
            });
            toolbar.Add(_threshold);

            _sortButton = new Button(() =>
            {
                _sortByDelta = !_sortByDelta;
                RebuildView();
            });
            _sortButton.AddToClassList("shapepick-diff__sort");
            _sortButton.tooltip = L.T(L.Key.TipSort);
            toolbar.Add(_sortButton);
            Add(toolbar);

            _list = new MultiColumnListView
            {
                fixedItemHeight = RowHeight,
                virtualizationMethod = CollectionVirtualizationMethod.FixedHeight,
                selectionType = SelectionType.None,
                showAlternatingRowBackgrounds = AlternatingRowBackground.ContentOnly,
                sortingEnabled = false,
                itemsSource = _view,
            };
            _list.AddToClassList("shapepick-diff__list");
            BuildColumns();
            Add(_list);

            _empty.AddToClassList("shapepick-diff__empty");
            _empty.style.display = DisplayStyle.None;
            Add(_empty);

            _footer = new Label();
            _footer.AddToClassList("shapepick-diff__footer");
            Add(_footer);

            RefreshTexts();
        }

        private void BuildColumns()
        {
            _list.columns.Add(new Column
            {
                name = ColName, title = L.T(L.Key.ColShapeKey), stretchable = true, minWidth = 120,
                makeCell = () => MakeLabel("shapepick-diff__cell-name"),
                bindCell = (e, i) =>
                {
                    var row = _view[i];
                    var l = (Label)e;
                    l.text = row.Name;
                    l.tooltip = row.Status == DiffStatus.MissingLeft ? L.T(L.Key.DiffMissingLeft)
                        : row.Status == DiffStatus.MissingRight ? L.T(L.Key.DiffMissingRight) : row.Name;
                    l.EnableInClassList("shapepick-diff__cell--missing", row.IsMissing);
                },
            });
            _list.columns.Add(new Column
            {
                name = ColLeft, title = SnapshotSet.DefaultLabel(SnapshotSet.SlotA), width = 64,
                makeCell = () => MakeLabel("shapepick-diff__cell-num"),
                bindCell = (e, i) => ((Label)e).text = FormatValue(_view[i].Left),
            });
            _list.columns.Add(new Column
            {
                name = ColRight, title = L.T(L.Key.ViewLive), width = 64,
                makeCell = () => MakeLabel("shapepick-diff__cell-num"),
                bindCell = (e, i) => ((Label)e).text = FormatValue(_view[i].Right),
            });
            _list.columns.Add(new Column
            {
                name = ColDelta, title = L.T(L.Key.ColDelta), width = 64,
                makeCell = () => MakeLabel("shapepick-diff__cell-num"),
                bindCell = (e, i) =>
                {
                    var row = _view[i];
                    var l = (Label)e;
                    l.text = row.IsMissing ? "—" : (row.Delta > 0 ? "+" : "") + row.Delta.ToString("0.0");
                    l.EnableInClassList("shapepick-diff__cell--pos", !row.IsMissing && row.Delta > 0);
                    l.EnableInClassList("shapepick-diff__cell--neg", !row.IsMissing && row.Delta < 0);
                },
            });
            _list.columns.Add(new Column
            {
                name = ColBar, title = "", width = 90, resizable = false,
                makeCell = () =>
                {
                    var track = new VisualElement();
                    track.AddToClassList("shapepick-diff-bar");
                    var fill = new VisualElement { name = "fill" };
                    fill.AddToClassList("shapepick-diff-bar__fill");
                    track.Add(fill);
                    return track;
                },
                bindCell = (e, i) =>
                {
                    var row = _view[i];
                    var fill = e.Q("fill");
                    float ratio = row.IsMissing || _maxAbs <= 0f ? 0f : Mathf.Clamp01(row.AbsDelta / _maxAbs);
                    fill.style.width = Length.Percent(ratio * 100f);
                    fill.EnableInClassList("shapepick-diff-bar__fill--pos", row.Delta > 0);
                    fill.EnableInClassList("shapepick-diff-bar__fill--neg", row.Delta < 0);
                },
            });
            // 「この値にする」: 左（A案）の値を現在値へ。比較先が B案のときだけ右（B案）のボタンも出す。
            // 比較先が現在値のときの「右を採用」は現在値を現在値にするだけで意味が無いため出さない（Codex レビュー）。
            _list.columns.Add(new Column
            {
                name = ColActions, title = L.T(L.Key.ColAdopt), width = 110, resizable = false,
                makeCell = () =>
                {
                    var box = new VisualElement();
                    box.AddToClassList("shapepick-diff__actions");
                    var left = new Button { name = "adopt-left" };
                    var right = new Button { name = "adopt-right" };
                    left.AddToClassList("shapepick-diff__adopt");
                    right.AddToClassList("shapepick-diff__adopt");
                    left.clicked += () => Adopt(box, true);
                    right.clicked += () => Adopt(box, false);
                    box.Add(left);
                    box.Add(right);
                    return box;
                },
                bindCell = (e, i) =>
                {
                    var row = _view[i];
                    e.userData = i;
                    var left = e.Q<Button>("adopt-left");
                    var right = e.Q<Button>("adopt-right");
                    left.text = _leftLabel;
                    left.tooltip = L.F(L.Key.TipAdoptRow, _leftLabel);
                    left.SetEnabled(_adoptEnabled && row.Status != DiffStatus.MissingLeft);
                    right.text = _rightLabel;
                    right.tooltip = L.F(L.Key.TipAdoptRow, _rightLabel);
                    right.SetEnabled(_adoptEnabled && row.Status != DiffStatus.MissingRight);
                    right.style.display = _rightIsLive ? DisplayStyle.None : DisplayStyle.Flex;
                    left.style.display = _leftIsLive ? DisplayStyle.None : DisplayStyle.Flex;
                },
            });
        }

        private string _leftLabel = SnapshotSet.DefaultLabel(SnapshotSet.SlotA);
        private string _rightLabel = "";
        private bool _rightIsLive = true;
        private bool _leftIsLive;
        private readonly Label _empty = new Label();
        private string _emptyMessage = string.Empty;

        /// <summary>行が無いときに表示する案内（状態に応じてウィンドウが決める）。</summary>
        public void SetEmptyMessage(string message)
        {
            _emptyMessage = message ?? string.Empty;
            _empty.text = _emptyMessage;
        }

        private void Adopt(VisualElement cell, bool left)
        {
            if (!(cell.userData is int index) || index < 0 || index >= _view.Count) return;
            var row = _view[index];
            float value = left ? row.Left : row.Right;
            if (float.IsNaN(value)) return;
            AdoptRequested?.Invoke(row.Name, value);
        }

        private static Label MakeLabel(string cls)
        {
            var l = new Label();
            l.AddToClassList("shapepick-diff__cell");
            l.AddToClassList(cls);
            return l;
        }

        private static string FormatValue(float v) => float.IsNaN(v) ? "—" : v.ToString("0.0");

        /// <summary>差分の入力を差し替えて再計算する。ラベルは列見出しに使う。</summary>
        public void SetSource(IReadOnlyList<BlendShapeEntry> left, IReadOnlyList<BlendShapeEntry> right, string leftLabel, string rightLabel, bool rightIsLive = true, bool leftIsLive = false)
        {
            _left = left;
            _right = right;
            _leftLabel = string.IsNullOrEmpty(leftLabel) ? SnapshotSet.DefaultLabel(SnapshotSet.SlotA) : leftLabel;
            _rightLabel = string.IsNullOrEmpty(rightLabel) ? L.T(L.Key.ViewLive) : rightLabel;
            _rightIsLive = rightIsLive;
            _leftIsLive = leftIsLive;
            _list.columns[ColLeft].title = _leftLabel;
            _list.columns[ColRight].title = _rightLabel;
            Recompute();
        }

        /// <summary>部分適用（← →）の有効・無効。「押している間だけ表示」中などに無効化する。</summary>
        public void SetAdoptEnabled(bool enabled)
        {
            if (_adoptEnabled == enabled) return;
            _adoptEnabled = enabled;
            _list.RefreshItems();
        }

        public void Recompute()
        {
            float threshold = _threshold.value;
            // 片側が無い（A 未登録など）ときは「全件欠損」ではなく空表示にする
            if (_left == null || _right == null || _left.Count == 0 || _right.Count == 0)
            {
                _all.Clear();
            }
            else
            {
                _calc.Compute(_left, _right, threshold, _all);
            }

            ChangedCount = 0;
            _maxAbs = 0f;
            foreach (var r in _all)
            {
                if (r.IsMissing) continue;
                ChangedCount++;
                if (r.AbsDelta > _maxAbs) _maxAbs = r.AbsDelta;
            }
            if (_maxAbs <= 0f) _maxAbs = 1f;

            RebuildView();
        }

        private void RebuildView()
        {
            _view.Clear();
            string filter = _filter.value;
            foreach (var r in _all)
            {
                if (DiffCalculator.MatchesFilter(r, filter)) _view.Add(r);
            }
            if (_sortByDelta) DiffCalculator.SortByAbsDeltaDescending(_view);
            else DiffCalculator.SortByName(_view);

            _list.RefreshItems();
            bool empty = _view.Count == 0;
            _list.style.display = empty ? DisplayStyle.None : DisplayStyle.Flex;
            _empty.style.display = empty ? DisplayStyle.Flex : DisplayStyle.None;
            _empty.text = _emptyMessage;
            _footer.text = L.F(L.Key.DiffFooter, ChangedCount);
            _sortButton.text = L.T(_sortByDelta ? L.Key.DiffSortByDelta : L.Key.DiffSortByName);
        }

        public void RefreshTexts()
        {
            _threshold.label = L.T(L.Key.DiffThreshold);
            _threshold.tooltip = L.T(L.Key.TipThreshold);
            _filter.tooltip = L.T(L.Key.TipFilter);
            _sortButton.tooltip = L.T(L.Key.TipSort);
            _list.columns[ColName].title = L.T(L.Key.ColShapeKey);
            _list.columns[ColDelta].title = L.T(L.Key.ColDelta);
            _list.columns[ColActions].title = L.T(L.Key.ColAdopt);
            _footer.text = L.F(L.Key.DiffFooter, ChangedCount);
            _sortButton.text = L.T(_sortByDelta ? L.Key.DiffSortByDelta : L.Key.DiffSortByName);
        }
    }
}
