using System;
using System.Collections.Generic;
using ShapePick.Data;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ShapePick.Services
{
    public enum ViewMode
    {
        /// <summary>シーン上の値そのまま。</summary>
        Live,

        /// <summary>スロットの値をレンダラーへ反映して表示中（liveBackup あり）。</summary>
        Slot,

        /// <summary>「押している間だけ表示」中（Undo 記録なし、liveBackup あり）。</summary>
        Peek,
    }

    /// <summary>
    /// ウィンドウの状態（対象・SnapshotSet・表示モード）と操作を 1 か所に集めた、UI 非依存のコントローラ。
    /// ShapePickWindow はここを呼ぶだけで、EditorWindow なしにテストできる（NFR-07）。
    /// </summary>
    public sealed class ShapePickController : IDisposable
    {
        private readonly BlendShapeSnapshot _liveSnapshot = new BlendShapeSnapshot { label = "現在値" };
        private string _snapshotFolder = SnapshotSetRepository.DefaultFolder;

        public SnapshotService Service { get; } = new SnapshotService();
        public LiveChangeDetector Detector { get; } = new LiveChangeDetector();

        public SkinnedMeshRenderer Target { get; private set; }
        public SnapshotSet Set { get; private set; }
        public ViewMode Mode { get; private set; } = ViewMode.Live;

        /// <summary>Mode が Slot / Peek のとき、表示中のスロット番号。Live のときは -1。</summary>
        public int ShownSlot { get; private set; } = -1;

        /// <summary>対象・スロット・表示モードのいずれかが変わった。UI 全体を再描画する契機。</summary>
        public event Action StateChanged;

        /// <summary>現在値が変わった（外部編集の検知後、または自身の適用後）。差分表・右プレビューの更新契機。</summary>
        public event Action LiveChanged;

        /// <summary>ユーザー向けの短い通知（トースト）。</summary>
        public event Action<string> Notified;

        /// <summary>スロットが登録（上書き）された（スロット番号, 上書き前の id。無ければ null）。サムネイル生成の契機。</summary>
        public event Action<int, string> SlotRegistered;

        /// <summary>スロットが空にされた（スロット番号, 消えた id）。プレビュー画像の掃除の契機。</summary>
        public event Action<int, string> SlotCleared;

        /// <summary>カード（枠）が取り除かれた（取り除かれた番号）。後ろの番号は 1 つ前に詰まる。</summary>
        public event Action<int> SlotRemoved;

        /// <summary>UI 以外の層（プレビュー等）が SnapshotSet を更新したときに再描画を促す。</summary>
        public void NotifyStateChanged() => StateChanged?.Invoke();

        /// <summary>トーストを出す（プレビュー層など、Notified を直接持たない層から）。</summary>
        public void Notify(string message) => Notified?.Invoke(message);

        public ShapePickController()
        {
            Detector.Changed += OnDetectorChanged;
            Detector.TargetInvalidated += OnTargetInvalidated;
            // 未保存シーンを保存すると対象の GlobalObjectId が「復元できない」から「できる」へ変わる。
            // 対象は変わらないので SetTarget は走らず、ここで貼り直さないと紐付けが切れたままになる
            EditorSceneManager.sceneSaved += OnSceneSaved;
            // 保存・ビルドのフックはウィンドウの外で動くので、静的な場所から引けるようにしておく
            SafetyRestore.Register(this);
        }

        private void OnSceneSaved(Scene scene)
        {
            if (Set == null || !HasTarget) return;
            if (Target.gameObject.scene != scene) return;
            SnapshotSetRepository.Rebind(Set, Target);
        }

        /// <summary>
        /// 今の対象に合わせて紐付けを貼り直す。リネームや親の付け替えでパス（保険）が古くなるのを防ぐ。
        /// 変化が無ければ書き込まないので、Hierarchy の変化ごとに呼んでよい。
        /// </summary>
        public void RebindCurrent()
        {
            if (Set == null || !HasTarget) return;
            SnapshotSetRepository.Rebind(Set, Target);
        }

        /// <summary>テスト用: SnapshotSet アセットの生成先を変える。</summary>
        public void SetSnapshotFolder(string folder) => _snapshotFolder = folder;

        // ------------------------------------------------------------------ 状態の問い合わせ

        public bool HasTarget => RendererResolver.IsEligible(Target);
        public int BlendShapeCount => HasTarget ? Target.sharedMesh.blendShapeCount : 0;
        public bool IsSlotRegistered(int slot) => Set != null && Set.IsSlotRegistered(slot);
        public BlendShapeSnapshot GetSlot(int slot) => Set != null ? Set.GetSlot(slot) : null;

        /// <summary>登録できるのは対象があり、かつ「現在値」を表示しているときだけ（スロット表示中の値を誤って登録しない）。</summary>
        public bool CanRegister(int slot)
        {
            if (!HasTarget || Mode != ViewMode.Live) return false;
            if (slot == SnapshotSet.SlotA) return true;
            return IsSlotRegistered(SnapshotSet.SlotA);
        }

        public bool CanShow(int slot) => HasTarget && IsSlotRegistered(slot) && Mode != ViewMode.Peek;
        public bool CanApply(int slot) => HasTarget && IsSlotRegistered(slot) && Mode != ViewMode.Peek;

        /// <summary>現在値のスナップショット（差分表の右側や比較用）。呼ぶたびに最新値へ更新する。</summary>
        public BlendShapeSnapshot RefreshLiveSnapshot()
        {
            if (!HasTarget)
            {
                _liveSnapshot.entries?.Clear();
                return _liveSnapshot;
            }

            if (Mode == ViewMode.Live)
            {
                Service.Capture(Target, null, _liveSnapshot);
            }
            else
            {
                // スロット表示中は退避した値が「現在値」
                Service.CopyLiveBackupTo(Target, _liveSnapshot);
            }
            return _liveSnapshot;
        }

        // ------------------------------------------------------------------ 対象

        /// <summary>対象を切り替える。表示中のスロットがあれば先に現在値へ戻す。</summary>
        public void SetTarget(SkinnedMeshRenderer renderer)
        {
            if (renderer == Target) return;

            RestoreLiveIfNeeded(recordUndo: false);
            HandOffUndoGuard();
            Target = RendererResolver.IsEligible(renderer) ? renderer : null;
            // ここからは自分で見張る（HandleUndoRedo）ので、預けていた見張りは外す
            SafetyRestore.ReleaseUndoGuard(Target);
            _switchedOnTarget = false;
            // 紐付けは個体単位（識別子 → パス）。メッシュ名だけで別個体のセットを掴まない
            Set = Target != null ? SnapshotSetRepository.FindForTarget(Target) : null;
            if (Set != null) SnapshotSetRepository.Rebind(Set, Target);
            Mode = ViewMode.Live;
            ShownSlot = -1;

            RefreshAdoptable();

            if (Target != null) Detector.Track(Target, EditorApplication.timeSinceStartup);
            else Detector.Untrack();

            StateChanged?.Invoke();
            RaiseLiveChanged();
        }

        /// <summary>Set が未生成なら、この個体に紐付いた SnapshotSet アセットを見つける・作る。</summary>
        public SnapshotSet EnsureSet()
        {
            if (!HasTarget) return null;
            if (Set == null) Set = SnapshotSetRepository.FindOrCreateForTarget(Target, _snapshotFolder);
            return Set;
        }

        // ------------------------------------------------------------------ 登録

        public bool RegisterSlot(int slot)
        {
            if (!CanRegister(slot)) return false;
            var set = EnsureSet();
            if (set == null) return false;

            var previous = set.GetSlot(slot);
            string previousId = previous != null && previous.IsRegistered ? previous.id : null;

            var snap = Service.Register(set, slot, Target);
            Notified?.Invoke(string.Format(UI.L.T(UI.L.Key.ToastRegistered), set.DisplayLabel(slot), snap.CreatedAtLocal.ToString("HH:mm")));
            StateChanged?.Invoke();
            SlotRegistered?.Invoke(slot, previousId);
            return true;
        }

        /// <summary>空の枠を 1 つ増やす（yayo 依頼 5）。上限は SnapshotSet.VisibleSlotLimit。</summary>
        public bool CanAddSlot => HasTarget && Set != null && Set.VisibleSlotCount < SnapshotSet.VisibleSlotLimit;

        public bool AddSlot()
        {
            if (!CanAddSlot) return false;
            Undo.RecordObject(Set, SnapshotService.UndoAddSlot);
            Set.EnsureSlot(Set.VisibleSlotCount);
            SnapshotSetRepository.ScheduleSave(Set);
            StateChanged?.Invoke();
            return true;
        }

        /// <summary>カード（枠）ごと取り除く（yayo 依頼: 整理したい）。最低 1 枠は残す。表示中なら先に現在値へ戻す。</summary>
        public bool CanRemoveSlot(int slot) => Set != null && Set.CanRemoveSlot(slot) && Mode != ViewMode.Peek;

        public bool RemoveSlot(int slot)
        {
            if (!CanRemoveSlot(slot)) return false;
            if (Mode == ViewMode.Slot && ShownSlot == slot) RestoreLiveIfNeeded(recordUndo: false); // 消去と同じ Undo に切替を混ぜない（Undo で候補の値が現在値として戻るのを防ぐ）
            string label = Set.DisplayLabel(slot);
            Undo.RecordObject(Set, SnapshotService.UndoRemoveSlot);
            if (!Set.RemoveSlot(slot)) return false;
            if (Mode == ViewMode.Slot && ShownSlot > slot) ShownSlot--;
            SnapshotSetRepository.ScheduleSave(Set);
            Notified?.Invoke(string.Format(UI.L.T(UI.L.Key.ToastRemoved), label));
            SlotRemoved?.Invoke(slot);
            StateChanged?.Invoke();
            return true;
        }

        /// <summary>スロットの値を消して未登録に戻す（名前は残る）。表示中のスロットなら先に現在値へ戻す。</summary>
        public bool ClearSlot(int slot)
        {
            if (Set == null || !IsSlotRegistered(slot) || Mode == ViewMode.Peek) return false;
            if (Mode == ViewMode.Slot && ShownSlot == slot) RestoreLiveIfNeeded(recordUndo: false); // 同上
            string previousId = Set.GetSlot(slot).id;
            Service.ClearSlot(Set, slot);
            Notified?.Invoke(string.Format(UI.L.T(UI.L.Key.ToastCleared), Set.DisplayLabel(slot)));
            StateChanged?.Invoke();
            SlotCleared?.Invoke(slot, previousId);
            return true;
        }

        public void RenameSlot(int slot, string newLabel)
        {
            if (Set == null || string.IsNullOrWhiteSpace(newLabel)) return;
            Undo.RecordObject(Set, SnapshotService.UndoRename);
            var s = Set.EnsureSlot(slot);
            s.label = newLabel.Trim();
            SnapshotSetRepository.ScheduleSave(Set);
            StateChanged?.Invoke();
        }

        public void SetMemo(int slot, string memo)
        {
            if (Set == null) return;
            Undo.RecordObject(Set, SnapshotService.UndoMemo);
            Set.EnsureSlot(slot).memo = memo;
            SnapshotSetRepository.ScheduleSave(Set);
        }

        // ------------------------------------------------------------------ 引き継ぎ（紐付けが切れた候補）

        private readonly List<SnapshotSet> _adoptable = new List<SnapshotSet>();
        private readonly List<SnapshotSet> _adoptableShown = new List<SnapshotSet>();

        /// <summary>
        /// 「この対象では出さない」と閉じた提示（対象のキー + 元セットの GUID）の保存先。
        /// SessionState なので、スクリプトの再コンパイルや Play Mode をまたいで、Unity を閉じるまで残る。
        /// </summary>
        private const string DismissedKey = "ShapePick.AdoptDismissed";
        private const char DismissedSeparator = '\n';
        private static HashSet<string> s_dismissedAdoptions;

        private static HashSet<string> DismissedAdoptions
        {
            get
            {
                if (s_dismissedAdoptions == null)
                {
                    s_dismissedAdoptions = new HashSet<string>();
                    foreach (var key in SessionState.GetString(DismissedKey, string.Empty).Split(DismissedSeparator))
                    {
                        if (key.Length > 0) s_dismissedAdoptions.Add(key);
                    }
                }
                return s_dismissedAdoptions;
            }
        }

        /// <summary>
        /// 今の対象へ引き継げるセット。同じメッシュで、紐付け先の個体がもう開いているシーンに無いもの。
        /// 対象の切替・引き継ぎ・Undo のたびに作り直す。Hierarchy が変わったときは RefreshAdoptable を呼ぶ。
        /// </summary>
        public IReadOnlyList<SnapshotSet> Adoptable => _adoptableShown;

        /// <summary>引き継げるセットの一覧を作り直す。変化があれば true。</summary>
        public bool RefreshAdoptable()
        {
            if (HasTarget) SnapshotSetRepository.FindAdoptable(Target, Set, _adoptable);
            else _adoptable.Clear();

            string targetKey = HasTarget ? AdoptionTargetKey() : null;
            bool changed = false;
            int n = 0;
            foreach (var set in _adoptable)
            {
                if (DismissedAdoptions.Contains(targetKey + "|" + SnapshotSetRepository.GetAssetGuid(set))) continue;
                if (n >= _adoptableShown.Count || _adoptableShown[n] != set) changed = true;
                if (n < _adoptableShown.Count) _adoptableShown[n] = set; else _adoptableShown.Add(set);
                n++;
            }
            if (_adoptableShown.Count != n)
            {
                changed = true;
                _adoptableShown.RemoveRange(n, _adoptableShown.Count - n);
            }
            return changed;
        }

        /// <summary>引き継げる候補の合計（まだ引き継いでいないものだけ）。案内の「n 件」に使う。</summary>
        public int AdoptableSlotCount
        {
            get
            {
                int n = 0;
                foreach (var set in _adoptableShown) n += SnapshotSetRepository.CountUnadopted(set, Set);
                return n;
            }
        }

        private string AdoptionTargetKey()
        {
            var binding = TargetBinding.Capture(Target);
            return string.IsNullOrEmpty(binding.GlobalId) ? binding.Scene + ":" + binding.Path : binding.GlobalId;
        }

        /// <summary>今の対象では、いま出ている引き継ぎの提示を出さないようにする（Unity を閉じるまで）。</summary>
        public void DismissAdoptable()
        {
            if (!HasTarget) return;
            string targetKey = AdoptionTargetKey();
            foreach (var set in _adoptableShown)
            {
                DismissedAdoptions.Add(targetKey + "|" + SnapshotSetRepository.GetAssetGuid(set));
            }
            SessionState.SetString(DismissedKey, string.Join(DismissedSeparator.ToString(), DismissedAdoptions));
            RefreshAdoptable();
            StateChanged?.Invoke();
        }

        /// <summary>テスト用: 閉じた提示の記憶を消す。</summary>
        public static void ClearDismissedAdoptions()
        {
            s_dismissedAdoptions = null;
            SessionState.EraseString(DismissedKey);
        }

        /// <summary>今の対象に、あと何件の候補を入れられるか（UI に出す枠の上限まで）。</summary>
        public int FreeSlotCount
        {
            get
            {
                if (!HasTarget) return 0;
                if (Set == null) return SnapshotSet.VisibleSlotLimit;
                int free = 0;
                for (int i = 0; i < SnapshotSet.VisibleSlotLimit; i++)
                {
                    if (!Set.IsSlotRegistered(i)) free++;
                }
                return free;
            }
        }

        public bool CanAdopt => HasTarget && Mode != ViewMode.Peek;

        /// <summary>
        /// 別のセットの候補を、今の対象のセットへコピーする（元のセットは変えない・消さない）。
        /// 空いている枠へ前から順に入れ、すでにある候補は上書きしない。Undo 1 回で戻せる。
        /// </summary>
        /// <param name="source">引き継ぎ元のセット。</param>
        /// <param name="sourceSlots">コピーする候補の番号（元セット側）。null なら、まだ引き継いでいない登録済みを全部。</param>
        /// <returns>コピーした件数。空きが足りない・引き継げないセットなど、何も入れなかったときは 0。</returns>
        public int Adopt(SnapshotSet source, IList<int> sourceSlots = null)
        {
            if (!CanAdopt) return 0;
            // 一覧を作ったあとで状況が変わっていることがある（閉じていたシーンを開いた、元のアバターを Undo で戻した等）。
            // 生きている別個体の候補を取り込まないよう、ここでもう一度確かめる（Codex レビュー指摘）
            if (!SnapshotSetRepository.IsAdoptable(source, Target, Set))
            {
                if (RefreshAdoptable()) StateChanged?.Invoke();
                return 0;
            }

            var wanted = new List<int>();
            if (sourceSlots == null)
            {
                for (int i = 0; i < source.slots.Count; i++)
                {
                    if (SnapshotSetRepository.IsUnadopted(source, i, Set)) wanted.Add(i);
                }
            }
            else
            {
                foreach (int s in sourceSlots)
                {
                    if (SnapshotSetRepository.IsUnadopted(source, s, Set) && !wanted.Contains(s)) wanted.Add(s);
                }
            }
            // 入りきらないときは何もしない。どれを入れるかは呼び出し側（UI）で選んでもらう
            if (wanted.Count == 0 || wanted.Count > FreeSlotCount) return 0;

            var set = EnsureSet();
            if (set == null) return 0;

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName(SnapshotService.UndoAdopt);
            Undo.RecordObject(set, SnapshotService.UndoAdopt);

            set.adoptedFrom ??= new List<string>();
            int copied = 0;
            int dest = 0;
            foreach (int s in wanted)
            {
                while (dest < SnapshotSet.VisibleSlotLimit && set.IsSlotRegistered(dest)) dest++;
                if (dest >= SnapshotSet.VisibleSlotLimit) break;
                var from = source.GetSlot(s);
                CopySnapshot(from, s, set.EnsureSlot(dest), dest);
                if (!set.adoptedFrom.Contains(from.id)) set.adoptedFrom.Add(from.id);
                copied++;
            }

            SnapshotSetRepository.ScheduleSave(set);
            Undo.FlushUndoRecordObjects();
            RefreshAdoptable();
            Notified?.Invoke(string.Format(UI.L.T(UI.L.Key.ToastAdopted), copied));
            StateChanged?.Invoke();
            return copied;
        }

        /// <summary>候補 1 件を複製する。id は振り直し（サムネイルは値から撮り直される）、登録日時は元のまま。</summary>
        private static void CopySnapshot(BlendShapeSnapshot from, int fromIndex, BlendShapeSnapshot to, int toIndex)
        {
            to.id = Guid.NewGuid().ToString("N");
            // 自分で付けた名前は持ってくる。既定名（候補2 など）は入れた先の番号の既定名にする
            if (!SnapshotSet.IsBuiltInDefaultLabel(from.label, fromIndex)) to.label = from.label;
            else if (SnapshotSet.IsBuiltInDefaultLabel(to.label, toIndex)) to.label = SnapshotSet.DefaultLabel(toIndex);
            to.memo = from.memo;
            to.createdAtUtc = from.createdAtUtc;
            to.meshName = from.meshName;
            to.meshGuid = from.meshGuid;
            to.rendererPath = from.rendererPath;
            to.previewCache = null;
            to.entries = new List<BlendShapeEntry>(from.entries.Count);
            foreach (var e in from.entries)
            {
                if (e != null) to.entries.Add(new BlendShapeEntry(e.name, e.weight));
            }
        }

        // ------------------------------------------------------------------ 表示切替（FR-04）

        public bool ShowSlot(int slot)
        {
            if (!CanShow(slot)) return false;
            SyncLiveShadow(); // 現在値から離れる前に控えを確定する
            _switchedOnTarget = true;

            Detector.Suppress(true);
            try
            {
                var result = Service.ShowSnapshot(Target, Set.GetSlot(slot));
                if (!result.RendererValid) return false;
                Mode = ViewMode.Slot;
                ShownSlot = slot;
                if (result.Skipped > 0)
                {
                    Notified?.Invoke(string.Format(UI.L.T(UI.L.Key.ToastSkipped), result.Skipped));
                }
            }
            finally
            {
                EndOwnWrite();
            }
            StateChanged?.Invoke();
            return true;
        }

        /// <summary>「現在値」へ戻す（ユーザーの明示操作。Undo に記録する）。退避が無ければ何もしない。</summary>
        public void ShowLive()
        {
            if (Mode == ViewMode.Live) return;
            RestoreLiveIfNeeded(recordUndo: true);
            StateChanged?.Invoke();
        }

        /// <summary>
        /// 自身の書き込みを終えるときに呼ぶ。Undo の差分確定（フラッシュ）を先に済ませてから抑制を解くことで、
        /// フレーム末の postprocessModifications が自身の変更を「外部変更」として拾うのを防ぐ（性能指針 4.4）。
        /// </summary>
        private void EndOwnWrite()
        {
            Undo.FlushUndoRecordObjects();
            Detector.Suppress(false);
        }

        // ------------------------------------------------------------------ 押している間だけ表示（FR-05）

        public bool BeginPeek(int slot)
        {
            if (!HasTarget || !IsSlotRegistered(slot) || Mode != ViewMode.Live) return false;
            SyncLiveShadow();

            Detector.Suppress(true);
            Service.BackupLive(Target);
            var result = Service.Apply(Target, Set.GetSlot(slot), recordUndo: false);
            if (!result.RendererValid)
            {
                Service.DiscardLiveBackup();
                Detector.Suppress(false);
                return false;
            }
            Mode = ViewMode.Peek;
            ShownSlot = slot;
            StateChanged?.Invoke();
            return true;
        }

        public void EndPeek()
        {
            if (Mode != ViewMode.Peek) return;
            Service.RestoreLive(recordUndo: false);
            EndOwnWrite();
            Mode = ViewMode.Live;
            ShownSlot = -1;
            StateChanged?.Invoke();
        }

        // ------------------------------------------------------------------ 適用（FR-10 / FR-09）

        /// <summary>スロットの値を現在値へ書き戻す。スロット表示中なら復帰と適用を 1 つの Undo にまとめる。</summary>
        public bool ApplySlot(int slot)
        {
            if (!CanApply(slot)) return false;

            Detector.Suppress(true);
            try
            {
                Undo.IncrementCurrentGroup();
                int group = Undo.GetCurrentGroup();
                Undo.SetCurrentGroupName(SnapshotService.UndoApply);

                // 表示中のスロットからの復帰は Undo に記録せず現在値へ戻し、確定操作（適用）だけを 1 件記録する。
                // こうすると Undo 1 回で「表示切替前の現在値」へ戻る（Codex レビュー指摘）。
                if (Mode == ViewMode.Slot)
                {
                    Service.RestoreLive(recordUndo: false);
                    Mode = ViewMode.Live;
                    ShownSlot = -1;
                }

                var result = Service.Apply(Target, Set.GetSlot(slot), recordUndo: true);
                Undo.CollapseUndoOperations(group);

                if (!result.RendererValid) return false;
                var label = Set.DisplayLabel(slot);
                Notified?.Invoke(result.Skipped > 0
                    ? string.Format(UI.L.T(UI.L.Key.ToastAppliedSkipped), label, result.Skipped)
                    : string.Format(UI.L.T(UI.L.Key.ToastApplied), label));
            }
            finally
            {
                EndOwnWrite();
            }
            StateChanged?.Invoke();
            RaiseLiveChanged();
            return true;
        }

        /// <summary>1 シェイプだけ現在値へ反映する（差分表の「← →」）。スロット表示中は先に現在値へ戻す。</summary>
        public bool ApplyEntry(string name, float weight)
        {
            if (!HasTarget || Mode == ViewMode.Peek) return false;

            Detector.Suppress(true);
            try
            {
                Undo.IncrementCurrentGroup();
                int group = Undo.GetCurrentGroup();
                Undo.SetCurrentGroupName(SnapshotService.UndoPartialApply);

                if (Mode == ViewMode.Slot)
                {
                    Service.RestoreLive(recordUndo: false);
                    Mode = ViewMode.Live;
                    ShownSlot = -1;
                }

                var result = Service.ApplyEntry(Target, name, weight, recordUndo: true);
                Undo.CollapseUndoOperations(group);
                if (result.Applied == 0) return false;
            }
            finally
            {
                EndOwnWrite();
            }
            StateChanged?.Invoke();
            RaiseLiveChanged();
            return true;
        }

        /// <summary>
        /// シェイプキータブからの編集。Inspector と同じ扱い（即時反映 + Undo）。
        /// Undo グループは Unity がマウス押下・離上で自動的に区切るため、スライダーの 1 ドラッグは 1 件にまとまる。
        /// </summary>
        public bool SetLiveWeight(string name, float weight)
        {
            if (!HasTarget || Mode != ViewMode.Live) return false;
            Detector.Suppress(true);
            try
            {
                var result = Service.ApplyEntry(Target, name, weight, recordUndo: true);
                if (result.Applied == 0) return false;
            }
            finally
            {
                EndOwnWrite();
            }
            RaiseLiveChanged();
            return true;
        }

        // ------------------------------------------------------------------ 外部イベント

        /// <summary>
        /// Undo / Redo が行われた。表示モードを「現在値」に同期する（3.6）。
        /// 退避（切替前の現在値）は捨てずに書き戻す。Undo で切替自体が戻った場合は同じ値を書くだけで無害、
        /// 「A → B と切り替えて Undo」や「表示中に無関係な Undo」の場合は退避が唯一の現在値なので復元が必要。
        /// この書き戻しは Undo に記録しない（Undo 履歴を汚さない）。
        /// </summary>
        /// <param name="undoName">
        /// 実行された Undo / Redo の名前（Undo.undoRedoEvent の UndoRedoInfo.undoName）。分からなければ null。
        /// 現在値を表示中に「表示切替」が Undo / Redo されると、履歴に残っていた候補の値がレンダラーへ入る。
        /// 表示切替は現在値そのものを変える操作ではないので、そのときは直前の現在値へ書き戻す
        /// （保存・ビルドの直前に戻したあと Ctrl+Z / Ctrl+Y で候補の値が戻ってくるのを防ぐ。Codex レビュー指摘）。
        /// </param>
        public void HandleUndoRedo(string undoName = null)
        {
            if (Mode != ViewMode.Live)
            {
                bool wasPeek = Mode == ViewMode.Peek;
                Detector.Suppress(true);
                Service.RestoreLive(recordUndo: false);
                EndOwnWrite();
                if (wasPeek) Detector.Suppress(false); // BeginPeek が掛けた抑制を解く
                Mode = ViewMode.Live;
                ShownSlot = -1;
            }
            else if (undoName == SnapshotService.UndoSwitch && HasLiveShadow)
            {
                Detector.Suppress(true);
                SnapshotService.WriteWeights(Target, _liveShadow, _liveShadowCount);
                EndOwnWrite();
            }
            Detector.AcknowledgeCurrentValues();
            // 引き継ぎを Undo / Redo したら、提示も出し直す
            RefreshAdoptable();
            StateChanged?.Invoke();
            RaiseLiveChanged();
        }

        /// <summary>
        /// ウィンドウを閉じる・Play Mode に入る・ドメインリロード前など、必ず現在値へ戻してから終わるべき局面で呼ぶ。
        /// 自動復帰は Undo に記録しない。記録すると、ウィンドウが無い状態で Ctrl+Z がスロット値を呼び戻してしまう
        /// （Codex レビュー指摘）。ユーザーの明示操作である ShowLive だけを記録する。
        /// </summary>
        public void RestoreForExit()
        {
            RestoreLiveIfNeeded(recordUndo: false);
        }

        /// <summary>候補を Scene に表示中か（レンダラーに現在値ではない値が入っている）。</summary>
        public bool IsShowingCandidate => Mode != ViewMode.Live;

        /// <summary>
        /// シーン保存・ビルドの直前に現在値へ戻す（SafetyRestore から呼ぶ）。Undo には記録しない。
        /// 設定「閉じるとき現在値に戻す」には従わず、必ず戻す。戻したあとは現在値の表示のままにする。
        /// </summary>
        /// <param name="restored">実際に値を書き戻したか。</param>
        /// <returns>
        /// 候補の値がシーンに残っていないと言えるなら true。
        /// 表示中なのに書き戻せなかった（メッシュが差し替わった・退避が無い）ときだけ false。
        /// </returns>
        public bool RestoreForSafety(out bool restored)
        {
            restored = false;
            if (Mode == ViewMode.Live) return true;

            bool wasPeek = Mode == ViewMode.Peek;
            Detector.Suppress(true);
            var outcome = Service.RestoreLiveChecked(recordUndo: false);
            EndOwnWrite();
            if (wasPeek) Detector.Suppress(false); // BeginPeek が掛けた抑制を解く（EndPeek はもう通らない）
            Mode = ViewMode.Live;
            ShownSlot = -1;
            restored = outcome == LiveRestoreOutcome.Restored;

            StateChanged?.Invoke();
            RaiseLiveChanged();
            // 対象が破棄されていたなら、候補の値を持つレンダラー自体がもう無い
            return outcome == LiveRestoreOutcome.Restored || outcome == LiveRestoreOutcome.TargetGone;
        }

        /// <summary>毎エディタ更新で呼ぶ。</summary>
        public void Tick(double now)
        {
            if (Target == null && HasTargetReference())
            {
                OnTargetInvalidated();
                return;
            }
            Detector.Tick(now);
            SyncLiveShadow();
        }

        // 「いまの現在値」の控え。現在値を表示している間だけ更新する。
        // 現在値の表示中に表示切替が Undo / Redo されたとき、書き戻す先として使う（HandleUndoRedo）
        private float[] _liveShadow = Array.Empty<float>();
        private int _liveShadowCount;
        private SkinnedMeshRenderer _liveShadowRenderer;
        private Mesh _liveShadowMesh;

        private bool HasLiveShadow => HasTarget && _liveShadowRenderer == Target && _liveShadowMesh == Target.sharedMesh
                                      && _liveShadowCount == Target.sharedMesh.blendShapeCount;

        private void SyncLiveShadow()
        {
            if (Mode != ViewMode.Live) return;
            if (!HasTarget)
            {
                _liveShadowRenderer = null;
                _liveShadowMesh = null;
                _liveShadowCount = 0;
                return;
            }
            SnapshotService.ReadWeights(Target, ref _liveShadow);
            _liveShadowCount = Target.sharedMesh.blendShapeCount;
            _liveShadowRenderer = Target;
            _liveShadowMesh = Target.sharedMesh;
        }

        /// <summary>今の対象で、候補を Scene に表示したことがあるか（Undo 履歴に表示切替が残っている）。</summary>
        private bool _switchedOnTarget;

        /// <summary>
        /// 対象から離れる・ウィンドウを閉じるときに、「表示切替の Undo / Redo で候補の値を現在値として戻さない」
        /// 見張りを SafetyRestore に預ける。Undo 履歴はウィンドウより長生きするので、
        /// 離れたあとに Ctrl+Z を押すと、履歴に残った候補の値がレンダラーへ入ってしまう（Codex レビュー指摘）。
        /// 候補を表示したまま離れる場合（設定で自動復帰を切っている）は、その値を採用したものとして預けない。
        /// </summary>
        private void HandOffUndoGuard()
        {
            if (!_switchedOnTarget || Mode != ViewMode.Live || !HasTarget) return;
            SyncLiveShadow();
            var copy = new float[_liveShadowCount];
            Array.Copy(_liveShadow, copy, _liveShadowCount);
            SafetyRestore.GuardUndo(Target, copy);
        }

        private void RaiseLiveChanged()
        {
            SyncLiveShadow();
            LiveChanged?.Invoke();
        }

        private bool HasTargetReference()
        {
            // UnityEngine.Object の == null は破棄済みも null 扱いになるため、参照の有無は ReferenceEquals で見る
            return !ReferenceEquals(Target, null);
        }

        private void RestoreLiveIfNeeded(bool recordUndo)
        {
            if (Mode == ViewMode.Live) return;
            bool wasPeek = Mode == ViewMode.Peek;
            Detector.Suppress(true);
            Service.RestoreLive(recordUndo: recordUndo && Mode == ViewMode.Slot);
            EndOwnWrite();
            if (wasPeek) Detector.Suppress(false); // BeginPeek が掛けた抑制を解く（EndPeek はもう通らない）
            Mode = ViewMode.Live;
            ShownSlot = -1;
        }

        private void OnDetectorChanged()
        {
            RaiseLiveChanged();
        }

        /// <summary>対象が破棄された・メッシュが差し替わった（3.7）。例外を出さず未選択へ戻す。</summary>
        private void OnTargetInvalidated()
        {
            Service.DiscardLiveBackup();
            Target = null;
            Set = null;
            Mode = ViewMode.Live;
            ShownSlot = -1;
            // 対象が消えたら引き継ぎ提示も消す（押せないバナーを残さない）
            RefreshAdoptable();
            Detector.Untrack();
            StateChanged?.Invoke();
            RaiseLiveChanged();
        }

        /// <summary>
        /// 後始末。現在値への復帰は行わない（行うかどうかは呼び出し側が ShapePickSettings.AutoRestoreOnClose で決めて
        /// RestoreForExit() を呼ぶ）。退避だけを捨てる。
        /// </summary>
        public void Dispose()
        {
            HandOffUndoGuard();
            SafetyRestore.Unregister(this);
            Service.DiscardLiveBackup();
            Detector.Changed -= OnDetectorChanged;
            Detector.TargetInvalidated -= OnTargetInvalidated;
            EditorSceneManager.sceneSaved -= OnSceneSaved;
            Detector.Dispose();
            StateChanged = null;
            LiveChanged = null;
            Notified = null;
            SlotRegistered = null;
        }
    }
}
