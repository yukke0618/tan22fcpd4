using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// NDMF のプレビュー（Modular Avatar の Outfit Root などが Scene ビューにだけ映す「組み立て後の姿」）に合わせるための橋渡し。
    /// NDMF はオリジナルのレンダラーごとに代わりのレンダラー（プロキシ）を作って Scene ビューで差し替えている。
    /// そのプロキシを描けば、ShapePick のプレビューも Scene ビューと同じ姿になる（1.0.1、yayo 依頼 9/17）。
    ///
    /// NDMF は依存に入れないので、型とメンバーはリフレクションで探す。見つからない・プレビューが切られている・
    /// 例外が出た、のどれでも元のレンダラーをそのまま返す（従来どおりの描画）。
    /// 参照先: nadena.dev.ndmf.preview.PreviewSession.Current（public）と OriginalToProxyRenderer（internal）。
    /// NDMF 自身の HandleUtilityPatches も同じ辞書でプロキシを引いている。
    /// </summary>
    public static class NdmfPreviewBridge
    {
        private const string SessionTypeName = "nadena.dev.ndmf.preview.PreviewSession, nadena.dev.ndmf";

        private static bool s_resolved;
        private static bool s_failed;
        private static PropertyInfo s_current;
        private static PropertyInfo s_originalToProxy;

        /// <summary>NDMF が入っていて、必要なメンバーが見つかったか。</summary>
        public static bool IsAvailable
        {
            get
            {
                Resolve();
                return !s_failed;
            }
        }

        /// <summary>
        /// 今の NDMF プレビューでの「オリジナル → プロキシ」の対応表。プレビューが無効なら null。
        /// 1 回の描画の間は同じ表を使い回すこと（毎回リフレクションを呼ばない）。
        /// </summary>
        public static IReadOnlyDictionary<Renderer, Renderer> GetProxyMap()
        {
            Resolve();
            if (s_failed) return null;
            try
            {
                var session = s_current.GetValue(null);
                if (session == null) return null;
                return s_originalToProxy.GetValue(session) as IReadOnlyDictionary<Renderer, Renderer>;
            }
            catch (Exception ex)
            {
                // NDMF の内部が変わった。以後は使わず、従来どおり元のレンダラーを描く
                s_failed = true;
                Debug.LogWarning("[ShapePick] NDMF のプレビューを読めませんでした。プレビューは組み立て前の姿で表示します (" + ex.GetType().Name + ")");
                return null;
            }
        }

        /// <summary>map にプロキシがあればそれを、無ければ original を返す。</summary>
        public static Renderer Resolve(IReadOnlyDictionary<Renderer, Renderer> map, Renderer original)
        {
            if (map == null || original == null) return original;
            if (map.TryGetValue(original, out var proxy) && proxy != null && IsDrawable(proxy)) return proxy;
            return original;
        }

        private static bool IsDrawable(Renderer r)
        {
            if (r is SkinnedMeshRenderer smr) return smr.sharedMesh != null;
            if (r is MeshRenderer mr)
            {
                var mf = mr.GetComponent<MeshFilter>();
                return mf != null && mf.sharedMesh != null;
            }
            return false;
        }

        private static void Resolve()
        {
            if (s_resolved) return;
            s_resolved = true;
            try
            {
                var type = Type.GetType(SessionTypeName, false);
                s_current = type?.GetProperty("Current", BindingFlags.Public | BindingFlags.Static);
                s_originalToProxy = type?.GetProperty("OriginalToProxyRenderer", BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance);
                s_failed = s_current == null || s_originalToProxy == null
                    || !typeof(IReadOnlyDictionary<Renderer, Renderer>).IsAssignableFrom(s_originalToProxy.PropertyType);
            }
            catch (Exception)
            {
                s_failed = true;
            }
        }
    }
}
