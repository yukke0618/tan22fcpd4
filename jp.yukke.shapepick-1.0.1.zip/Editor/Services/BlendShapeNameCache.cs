using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// メッシュのブレンドシェイプ名を 1 回だけ読み、名前 → インデックスの辞書として保持する。
    /// Mesh.GetBlendShapeName をホットパスで呼ばないための層（性能指針 4.4）。
    /// 重複名は 2 個目以降を "名前#2", "名前#3" … に正規化して一意なキーにする。
    /// </summary>
    public sealed class BlendShapeNameCache
    {
        private static readonly Dictionary<int, BlendShapeNameCache> s_byMeshId = new Dictionary<int, BlendShapeNameCache>();

        private readonly string[] _keys;
        private readonly string[] _rawNames;
        private readonly Dictionary<string, int> _indexByKey;

        public Mesh Mesh { get; }
        public int Count => _keys.Length;
        public bool HasDuplicateNames { get; }
        public IReadOnlyList<string> Keys => _keys;

        private BlendShapeNameCache(Mesh mesh, string[] rawNames)
        {
            Mesh = mesh;
            _rawNames = rawNames;
            _keys = new string[rawNames.Length];
            _indexByKey = new Dictionary<string, int>(Math.Max(rawNames.Length, 1));

            Dictionary<string, int> occurrences = null;
            for (int i = 0; i < rawNames.Length; i++)
            {
                string raw = rawNames[i] ?? string.Empty;
                string key = raw;
                if (_indexByKey.ContainsKey(key))
                {
                    HasDuplicateNames = true;
                    occurrences ??= new Dictionary<string, int>();
                    occurrences.TryGetValue(raw, out int n);
                    do
                    {
                        n++;
                        key = raw + "#" + (n + 1);
                    } while (_indexByKey.ContainsKey(key));
                    occurrences[raw] = n;
                }
                _keys[i] = key;
                _indexByKey.Add(key, i);
            }
        }

        /// <summary>メッシュ用のキャッシュを取得する。件数が変わっていれば作り直す。</summary>
        public static BlendShapeNameCache Get(Mesh mesh)
        {
            if (mesh == null) throw new ArgumentNullException(nameof(mesh));

            int id = mesh.GetInstanceID();
            if (s_byMeshId.TryGetValue(id, out var cached) && cached.Mesh == mesh && cached.IsStillValidFor(mesh))
            {
                return cached;
            }

            var created = new BlendShapeNameCache(mesh, ReadNames(mesh));
            s_byMeshId[id] = created;
            return created;
        }

        /// <summary>
        /// 件数と先頭・末尾の名前が一致すれば有効とみなす（毎回の全件照合を避けつつ、
        /// 「同件数で名前だけ変わった」再構築の大半を検出する）。
        /// </summary>
        private bool IsStillValidFor(Mesh mesh)
        {
            int n = mesh.blendShapeCount;
            if (n != _rawNames.Length) return false;
            if (n == 0) return true;
            return mesh.GetBlendShapeName(0) == _rawNames[0] && mesh.GetBlendShapeName(n - 1) == _rawNames[n - 1];
        }

        /// <summary>テスト用・名前配列から直接構築する（Mesh は null）。</summary>
        public static BlendShapeNameCache FromNames(string[] names)
        {
            if (names == null) throw new ArgumentNullException(nameof(names));
            return new BlendShapeNameCache(null, (string[])names.Clone());
        }

        public static void Invalidate(Mesh mesh)
        {
            if (mesh == null) return;
            s_byMeshId.Remove(mesh.GetInstanceID());
        }

        public static void InvalidateAll() => s_byMeshId.Clear();

        /// <summary>正規化済みキー（照合キー）。</summary>
        public string GetKey(int index) => _keys[index];

        /// <summary>メッシュ上の元の名前。</summary>
        public string GetRawName(int index) => _rawNames[index];

        public bool TryGetIndex(string key, out int index)
        {
            if (key == null)
            {
                index = -1;
                return false;
            }
            return _indexByKey.TryGetValue(key, out index);
        }

        public bool Contains(string key) => key != null && _indexByKey.ContainsKey(key);

        /// <summary>
        /// 見出し用に置かれたシェイプキーか。アバターによっては一覧を区切るために
        /// <c>----------Eye----------</c> や <c>=======EYE=======</c> のような、値を持たない飾りのキーを入れている。
        /// 判定は「記号が 2 つ以上続けて始まる」。記号とは英数字・かな・漢字・空白のいずれでもない文字を指す。
        /// <c>--</c> <c>==</c> <c>__</c> <c>**</c> <c>▼▼</c> <c>■■</c> などが該当し、<c>eye_blink</c> は該当しない。
        /// </summary>
        public static bool IsSeparatorName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            var trimmed = name.TrimStart();
            if (trimmed.Length < 2) return false;

            char head = trimmed[0];
            if (char.IsLetterOrDigit(head) || char.IsWhiteSpace(head)) return false;
            return trimmed[1] == head;
        }

        private static string[] ReadNames(Mesh mesh)
        {
            int n = mesh.blendShapeCount;
            var names = new string[n];
            for (int i = 0; i < n; i++)
            {
                names[i] = mesh.GetBlendShapeName(i);
            }
            return names;
        }

        /// <summary>AssetPostprocessor から呼ぶ。メッシュを含みうるアセットが再インポートされたか判定する。</summary>
        internal static void OnAssetsImported(string[] importedAssets, string[] deletedAssets, string[] movedAssets)
        {
            if (s_byMeshId.Count == 0) return;
            if (ContainsMeshAsset(importedAssets) || ContainsMeshAsset(deletedAssets) || ContainsMeshAsset(movedAssets))
            {
                InvalidateAll();
            }
        }

        private static bool ContainsMeshAsset(string[] paths)
        {
            if (paths == null) return false;
            foreach (var p in paths)
            {
                if (string.IsNullOrEmpty(p)) continue;
                if (p.EndsWith(".fbx", StringComparison.OrdinalIgnoreCase)
                    || p.EndsWith(".obj", StringComparison.OrdinalIgnoreCase)
                    || p.EndsWith(".blend", StringComparison.OrdinalIgnoreCase)
                    || p.EndsWith(".dae", StringComparison.OrdinalIgnoreCase)
                    || p.EndsWith(".gltf", StringComparison.OrdinalIgnoreCase)
                    || p.EndsWith(".glb", StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }

                // .asset は SnapshotSet 自身の保存でも飛んでくる。メインアセットが Mesh のものだけ対象にする
                if (p.EndsWith(".asset", StringComparison.OrdinalIgnoreCase)
                    && AssetDatabase.GetMainAssetTypeAtPath(p) == typeof(Mesh))
                {
                    return true;
                }
            }
            return false;
        }
    }

    /// <summary>モデルアセットの再インポートで名前キャッシュを捨てる（名前が変わっている可能性があるため）。</summary>
    internal sealed class BlendShapeNameCacheReimportWatcher : AssetPostprocessor
    {
        private static void OnPostprocessAllAssets(
            string[] importedAssets, string[] deletedAssets, string[] movedAssets, string[] movedFromAssetPaths)
        {
            BlendShapeNameCache.OnAssetsImported(importedAssets, deletedAssets, movedAssets);
        }
    }
}
