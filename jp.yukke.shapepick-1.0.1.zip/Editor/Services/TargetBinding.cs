using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// 候補セット（SnapshotSet）をシーン上の「その個体」へ結び付けるための識別情報。
    /// 同じアバターを 2 体置いたとき（Shinano と Shinano (1)）に候補を分けるのが目的で、
    /// メッシュアセットではなく対象 SkinnedMeshRenderer の GameObject を指す。
    ///
    /// 本命は GlobalObjectId、保険は Hierarchy パス。Unity 2022.3.22f1 での実測（2026-09-11）:
    /// ・保存済みシーンの GameObject は、リネーム・親の付け替え・シーンの開き直し・Unity 再起動をまたいで不変。
    /// ・同一プレハブの 2 体は targetPrefabId で区別できるので、文字列全体で比較すれば取り違えない。
    /// ・**未保存シーン**の GameObject は GUID 部がゼロになり、文字列から GlobalObjectId.TryParse で戻せない。
    ///   そのため永続化できず、ここでは空文字として扱ってパス側に任せる。
    /// ・未保存シーンを保存すると識別子の文字列が変わる。解決に成功したときに毎回貼り直す（Rebind）。
    /// </summary>
    public readonly struct TargetBinding
    {
        /// <summary>GlobalObjectId の GUID 部がこれなら、シーンが未保存で識別子を永続化できない。</summary>
        private const string EmptyGuid = "00000000000000000000000000000000";

        /// <summary>永続化できる GlobalObjectId 文字列。未保存シーンでは空。</summary>
        public readonly string GlobalId;

        /// <summary>シーン内のフルパス（"Wrapper/Shinano (1)/Body"）。識別子が使えないときの保険。</summary>
        public readonly string Path;

        /// <summary>属するシーンのアセットパス（"Assets/test.unity"）。未保存シーンでは空。</summary>
        public readonly string Scene;

        /// <summary>表示用のアバター名（最上位 Animator、無ければ Transform.root の名前）。</summary>
        public readonly string AvatarName;

        /// <summary>表示用の対象 SkinnedMeshRenderer 名。</summary>
        public readonly string TargetName;

        /// <summary>各項目を直接指定して作る（テストや、識別情報を保存済みの値から組み立てる用）。</summary>
        public TargetBinding(string globalId, string path, string scene, string avatarName, string targetName)
        {
            GlobalId = globalId ?? string.Empty;
            Path = path ?? string.Empty;
            Scene = scene ?? string.Empty;
            AvatarName = avatarName ?? string.Empty;
            TargetName = targetName ?? string.Empty;
        }

        /// <summary>パスすら無ければ紐付けに使えない。</summary>
        public bool IsValid => !string.IsNullOrEmpty(Path);

        /// <summary>対象レンダラーから識別情報を取り出す。シーンには一切触れない。</summary>
        public static TargetBinding Capture(SkinnedMeshRenderer renderer)
        {
            if (renderer == null) return default;

            var go = renderer.gameObject;
            var avatar = PreviewObjectResolver.FindAvatarRoot(renderer);
            return new TargetBinding(
                GetPersistentGlobalId(go),
                RendererResolver.GetHierarchyPath(go.transform),
                GetSceneKey(go),
                avatar != null ? avatar.name : go.name,
                go.name);
        }

        /// <summary>
        /// パス一致をどこまでの範囲に閉じるかを表すキー。
        /// 通常はシーンのアセットパス。Prefab モードのシーンはパスを持たないので、
        /// 編集中のプレハブのアセットパスを使う（未保存シーンと同じ「空」に落として
        /// 別のプレハブ同士がぶつかるのを防ぐ）。
        /// </summary>
        private static string GetSceneKey(GameObject go)
        {
            var stage = PrefabStageUtility.GetPrefabStage(go);
            if (stage != null && !string.IsNullOrEmpty(stage.assetPath)) return stage.assetPath;

            var scene = go.scene;
            return scene.IsValid() ? scene.path ?? string.Empty : string.Empty;
        }

        /// <summary>
        /// 永続化できる GlobalObjectId 文字列。未保存シーンのオブジェクトは文字列から復元できないので空を返す。
        /// </summary>
        public static string GetPersistentGlobalId(GameObject go)
        {
            if (go == null) return string.Empty;
            var id = GlobalObjectId.GetGlobalObjectIdSlow(go);
            if (id.assetGUID.ToString() == EmptyGuid) return string.Empty;
            return id.ToString();
        }

        /// <summary>
        /// 開いているシーン（と編集中の Prefab ステージ）から、保険のパスに一致する SkinnedMeshRenderer を探す。
        /// 「このセットの紐付け先がまだ生きているか」を、識別子が使えないときに確かめるために使う。
        /// </summary>
        /// <param name="path">シーン内のフルパス（"Shinano/Body"）。</param>
        /// <param name="sceneKey">
        /// GetSceneKey と同じキー（シーンまたはプレハブのアセットパス。未保存シーンは空文字）。
        /// null を渡すと、開いているすべてのシーンから探す。
        /// </param>
        /// <param name="accept">
        /// 同じパスのレンダラーが複数あるときに、どれを採るかの条件。null なら最初の 1 つ。
        /// </param>
        public static SkinnedMeshRenderer FindLiveRendererAt(string path, string sceneKey, System.Predicate<SkinnedMeshRenderer> accept = null)
        {
            if (string.IsNullOrEmpty(path)) return null;
            bool anyScene = sceneKey == null;

            var stage = PrefabStageUtility.GetCurrentPrefabStage();
            if (stage != null && stage.prefabContentsRoot != null && (anyScene || (stage.assetPath ?? string.Empty) == sceneKey))
            {
                var found = FindUnder(stage.prefabContentsRoot, path, accept);
                if (found != null) return found;
            }

            for (int i = 0; i < UnityEngine.SceneManagement.SceneManager.sceneCount; i++)
            {
                var scene = UnityEngine.SceneManagement.SceneManager.GetSceneAt(i);
                if (!scene.IsValid() || !scene.isLoaded) continue;
                if (!anyScene && (scene.path ?? string.Empty) != sceneKey) continue;
                foreach (var root in scene.GetRootGameObjects())
                {
                    var found = FindUnder(root, path, accept);
                    if (found != null) return found;
                }
            }
            return null;
        }

        private static SkinnedMeshRenderer FindUnder(GameObject root, string path, System.Predicate<SkinnedMeshRenderer> accept)
        {
            // 名前に "/" を含むオブジェクトもあるので、パスを分解せず GetHierarchyPath の結果どうしで比べる
            if (!path.StartsWith(root.name, System.StringComparison.Ordinal)) return null;
            foreach (var r in root.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            {
                if (RendererResolver.GetHierarchyPath(r.transform) == path && (accept == null || accept(r))) return r;
            }
            return null;
        }

        /// <summary>識別子文字列から GameObject を引く。閉じたシーンや消えたオブジェクトなら null。</summary>
        public static GameObject ResolveObject(string globalId)
        {
            if (string.IsNullOrEmpty(globalId)) return null;
            if (!GlobalObjectId.TryParse(globalId, out var id)) return null;
            return GlobalObjectId.GlobalObjectIdentifierToObjectSlow(id) as GameObject;
        }
    }
}
