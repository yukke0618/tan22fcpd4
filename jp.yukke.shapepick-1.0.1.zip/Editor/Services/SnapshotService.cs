using System;
using System.Collections.Generic;
using ShapePick.Data;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>適用結果。Skipped は名前がレンダラー側に無くて飛ばした件数（FR-14）。</summary>
    public struct ApplyResult
    {
        public bool RendererValid;
        public int Applied;
        public int Skipped;

        public override string ToString() => $"applied={Applied}, skipped={Skipped}, valid={RendererValid}";
    }

    /// <summary>退避した現在値を書き戻した結果。</summary>
    public enum LiveRestoreOutcome
    {
        /// <summary>退避が無かった。</summary>
        NoBackup,

        /// <summary>現在値へ書き戻した。</summary>
        Restored,

        /// <summary>レンダラーが破棄されていた（シーンに候補の値は残っていない）。</summary>
        TargetGone,

        /// <summary>メッシュが差し替わっていて書き戻せなかった（レンダラーに候補由来の値が残っているかもしれない）。</summary>
        MeshChanged,
    }

    /// <summary>
    /// スナップショットの取得・登録・適用・表示切替・liveBackup 管理と Undo 記録（FR-02/03/04/10/15、3.5、3.6）。
    /// EditorWindow に依存しない。UI 層は 1 つのインスタンスを保持して使う。
    /// </summary>
    public sealed class SnapshotService
    {
        public const string UndoRegister = "ShapePick: 登録";
        public const string UndoSwitch = "ShapePick: 表示切替";
        public const string UndoApply = "ShapePick: 適用";
        public const string UndoPartialApply = "ShapePick: 部分適用";
        public const string UndoClearSlot = "ShapePick: スロットを消去";
        public const string UndoAddSlot = "ShapePick: スロットを追加";
        public const string UndoRemoveSlot = "ShapePick: カードを削除";
        public const string UndoRename = "ShapePick: 名前変更";
        public const string UndoMemo = "ShapePick: メモ";
        public const string UndoAdopt = "ShapePick: 候補を引き継ぐ";

        // liveBackup（切替表示中に退避した「現在値」）。スロットには保存しない。
        private float[] _liveBackup = Array.Empty<float>();
        private int _liveBackupCount;
        private SkinnedMeshRenderer _liveBackupRenderer;
        private Mesh _liveBackupMesh;

        public bool HasLiveBackup => _liveBackupRenderer != null && _liveBackupCount > 0;
        public SkinnedMeshRenderer LiveBackupRenderer => _liveBackupRenderer;

        // ---------------------------------------------------------------- 取得

        /// <summary>
        /// レンダラーの全ブレンドシェイプ値を読み取ってスナップショットを作る（アセット操作なし）。
        /// reuse を渡すとそのインスタンスとエントリを再利用して GC 割当を抑える。id は毎回振り直す。
        /// </summary>
        public BlendShapeSnapshot Capture(SkinnedMeshRenderer renderer, string label, BlendShapeSnapshot reuse = null)
        {
            if (renderer == null) throw new ArgumentNullException(nameof(renderer));
            var mesh = renderer.sharedMesh;
            if (mesh == null) throw new InvalidOperationException("SkinnedMeshRenderer に sharedMesh が設定されていません。");

            var cache = BlendShapeNameCache.Get(mesh);
            int count = cache.Count;

            var snap = reuse ?? new BlendShapeSnapshot();
            snap.id = Guid.NewGuid().ToString("N");
            if (!string.IsNullOrEmpty(label)) snap.label = label;
            snap.createdAtUtc = DateTime.UtcNow.Ticks;
            snap.meshName = mesh.name;
            snap.meshGuid = RendererResolver.GetMeshGuid(mesh);
            snap.rendererPath = RendererResolver.GetHierarchyPath(renderer.transform);
            ReleasePreview(snap);

            FillEntries(snap, cache, renderer, null, count);
            return snap;
        }

        /// <summary>プレビュー画像の参照を外す。アセットでない一時テクスチャなら破棄してリークを防ぐ。</summary>
        public static void ReleasePreview(BlendShapeSnapshot snap)
        {
            var tex = snap.previewCache;
            snap.previewCache = null;
            if (tex != null && !AssetDatabase.Contains(tex))
            {
                UnityEngine.Object.DestroyImmediate(tex);
            }
        }

        /// <summary>
        /// 退避中の「現在値」（liveBackup）をスナップショットへ書き出す。スロット表示中に差分表の右側へ使う。
        /// 退避が無い（現在値を表示中）ならレンダラーから直接取得する。戻り値は退避から取れたか。
        /// </summary>
        public bool CopyLiveBackupTo(SkinnedMeshRenderer renderer, BlendShapeSnapshot target)
        {
            if (target == null) throw new ArgumentNullException(nameof(target));

            bool fromBackup = HasLiveBackup && _liveBackupRenderer == renderer && renderer != null
                              && renderer.sharedMesh == _liveBackupMesh && renderer.sharedMesh != null
                              && renderer.sharedMesh.blendShapeCount == _liveBackupCount;

            if (!fromBackup)
            {
                if (RendererResolver.IsEligible(renderer))
                {
                    Capture(renderer, null, target);
                }
                else
                {
                    target.entries?.Clear();
                }
                return false;
            }

            var mesh = renderer.sharedMesh;
            var cache = BlendShapeNameCache.Get(mesh);
            target.meshName = mesh.name;
            target.meshGuid = RendererResolver.GetMeshGuid(mesh);
            target.rendererPath = RendererResolver.GetHierarchyPath(renderer.transform);
            FillEntries(target, cache, null, _liveBackup, _liveBackupCount);
            return true;
        }

        /// <summary>entries を count 件に揃え、renderer（または buffer）から値を詰める。既存インスタンスを再利用する。</summary>
        private static void FillEntries(BlendShapeSnapshot snap, BlendShapeNameCache cache, SkinnedMeshRenderer renderer, float[] buffer, int count)
        {
            var entries = snap.entries ??= new List<BlendShapeEntry>(count);
            if (entries.Count > count) entries.RemoveRange(count, entries.Count - count);
            if (entries.Capacity < count) entries.Capacity = count;

            for (int i = 0; i < count; i++)
            {
                float w = renderer != null ? renderer.GetBlendShapeWeight(i) : buffer[i];
                if (i < entries.Count)
                {
                    var e = entries[i];
                    if (e == null)
                    {
                        entries[i] = new BlendShapeEntry(cache.GetKey(i), w);
                    }
                    else
                    {
                        e.name = cache.GetKey(i);
                        e.weight = w;
                    }
                }
                else
                {
                    entries.Add(new BlendShapeEntry(cache.GetKey(i), w));
                }
            }
        }

        // ---------------------------------------------------------------- 登録

        /// <summary>
        /// スロットへ登録（上書き）する。Undo に SnapshotSet を記録し、保存は遅延する（3.5 登録フロー）。
        /// 既存スロットの label / memo は保持する。
        /// </summary>
        public BlendShapeSnapshot Register(SnapshotSet set, int slotIndex, SkinnedMeshRenderer renderer, bool recordUndo = true)
        {
            if (set == null) throw new ArgumentNullException(nameof(set));
            if (!SnapshotSet.IsValidSlotIndex(slotIndex))
                throw new ArgumentOutOfRangeException(nameof(slotIndex), slotIndex, "スロット番号は 0.." + (SnapshotSet.MaxSlots - 1));
            if (!RendererResolver.IsEligible(renderer))
                throw new InvalidOperationException("ブレンドシェイプを持つ SkinnedMeshRenderer を指定してください。");

            if (recordUndo) Undo.RecordObject(set, UndoRegister);

            var slot = set.EnsureSlot(slotIndex);
            Capture(renderer, null, slot);

            if (string.IsNullOrEmpty(set.meshName))
            {
                set.meshName = slot.meshName;
                set.meshGuid = slot.meshGuid;
            }

            SnapshotSetRepository.ScheduleSave(set);
            return slot;
        }

        /// <summary>スロットの値を消して未登録に戻す。Undo 対応。</summary>
        public void ClearSlot(SnapshotSet set, int slotIndex, bool recordUndo = true)
        {
            if (set == null) throw new ArgumentNullException(nameof(set));
            var slot = set.GetSlot(slotIndex);
            if (slot == null) return;
            if (recordUndo) Undo.RecordObject(set, UndoClearSlot);
            slot.ClearValues();
            SnapshotSetRepository.ScheduleSave(set);
        }

        // ---------------------------------------------------------------- 適用

        /// <summary>
        /// スナップショットの値をレンダラーへ書き戻す（FR-10）。名前が無いものはスキップして件数を返す。
        /// recordUndo=false はプレビュー一時適用・押している間だけ表示のための経路で、Undo 履歴を汚さない。
        /// </summary>
        public ApplyResult Apply(SkinnedMeshRenderer renderer, BlendShapeSnapshot snapshot, bool recordUndo, string undoName = UndoApply)
        {
            var result = default(ApplyResult);
            if (snapshot == null || snapshot.entries == null) return result;
            if (!RendererResolver.IsEligible(renderer)) return result;
            result.RendererValid = true;

            var cache = BlendShapeNameCache.Get(renderer.sharedMesh);
            if (recordUndo) Undo.RecordObject(renderer, undoName);

            var entries = snapshot.entries;
            for (int i = 0; i < entries.Count; i++)
            {
                var e = entries[i];
                if (e != null && cache.TryGetIndex(e.name, out int idx))
                {
                    renderer.SetBlendShapeWeight(idx, e.weight);
                    result.Applied++;
                }
                else
                {
                    result.Skipped++;
                }
            }

            RequestRepaint();
            return result;
        }

        /// <summary>1 シェイプだけ現在値へ反映する（FR-09 部分適用）。</summary>
        public ApplyResult ApplyEntry(SkinnedMeshRenderer renderer, string name, float weight, bool recordUndo = true)
        {
            var result = default(ApplyResult);
            if (!RendererResolver.IsEligible(renderer)) return result;
            result.RendererValid = true;

            var cache = BlendShapeNameCache.Get(renderer.sharedMesh);
            if (!cache.TryGetIndex(name, out int idx))
            {
                result.Skipped = 1;
                return result;
            }

            if (recordUndo) Undo.RecordObject(renderer, UndoPartialApply);
            renderer.SetBlendShapeWeight(idx, weight);
            result.Applied = 1;
            RequestRepaint();
            return result;
        }

        // ---------------------------------------------------------------- 表示切替（FR-04）

        /// <summary>
        /// 「現在値」から離れてスナップショットを表示する。
        /// 初回は現在値を liveBackup に退避し、以降の切替では退避し直さない。Undo は 1 切替 1 件。
        /// 別のレンダラーの退避が残っていれば、先にそれを復元する。
        /// </summary>
        public ApplyResult ShowSnapshot(SkinnedMeshRenderer renderer, BlendShapeSnapshot snapshot)
        {
            if (!RendererResolver.IsEligible(renderer) || snapshot == null) return default;

            if (HasLiveBackup && (_liveBackupRenderer != renderer || _liveBackupMesh != renderer.sharedMesh))
            {
                RestoreLive(recordUndo: true);
            }
            if (!HasLiveBackup)
            {
                BackupLive(renderer);
            }

            return Apply(renderer, snapshot, recordUndo: true, UndoSwitch);
        }

        /// <summary>「現在値」へ戻す。退避が無ければ何もしない。</summary>
        public bool ShowLive() => RestoreLive(recordUndo: true);

        /// <summary>現在値を退避する（スロットには保存しない）。</summary>
        public void BackupLive(SkinnedMeshRenderer renderer)
        {
            if (!RendererResolver.IsEligible(renderer)) throw new InvalidOperationException("退避対象のレンダラーが無効です。");
            ReadWeights(renderer, ref _liveBackup);
            _liveBackupCount = renderer.sharedMesh.blendShapeCount;
            _liveBackupRenderer = renderer;
            _liveBackupMesh = renderer.sharedMesh;
        }

        /// <summary>
        /// 退避した現在値を書き戻して退避を捨てる。
        /// レンダラーが破棄済み・メッシュが差し替わった場合は書き戻さずに退避だけ捨てて false を返す（3.7）。
        /// </summary>
        public bool RestoreLive(bool recordUndo)
        {
            return RestoreLiveChecked(recordUndo) == LiveRestoreOutcome.Restored;
        }

        /// <summary>
        /// RestoreLive と同じ処理で、書き戻せなかった理由まで返す。
        /// 保存・ビルドの直前は「戻せなかった」と「戻す相手がもう無い」を区別する必要がある。
        /// どの結果でも退避は捨てる。
        /// </summary>
        public LiveRestoreOutcome RestoreLiveChecked(bool recordUndo)
        {
            // UnityEngine.Object の == null は破棄済みも null 扱いなので、参照の有無は ReferenceEquals で見る
            if (ReferenceEquals(_liveBackupRenderer, null) || _liveBackupCount <= 0)
            {
                DiscardLiveBackup();
                return LiveRestoreOutcome.NoBackup;
            }

            var renderer = _liveBackupRenderer;
            if (renderer == null)
            {
                DiscardLiveBackup();
                return LiveRestoreOutcome.TargetGone;
            }

            bool restorable = renderer.sharedMesh == _liveBackupMesh
                              && renderer.sharedMesh != null
                              && renderer.sharedMesh.blendShapeCount == _liveBackupCount;

            if (restorable)
            {
                if (recordUndo) Undo.RecordObject(renderer, UndoSwitch);
                WriteWeights(renderer, _liveBackup, _liveBackupCount);
                RequestRepaint();
            }

            DiscardLiveBackup();
            return restorable ? LiveRestoreOutcome.Restored : LiveRestoreOutcome.MeshChanged;
        }

        /// <summary>退避を捨てる。Undo で切替が取り消されたときなど、退避内容が現在値と一致しなくなった場合に使う。</summary>
        public void DiscardLiveBackup()
        {
            _liveBackupRenderer = null;
            _liveBackupMesh = null;
            _liveBackupCount = 0;
        }

        // ---------------------------------------------------------------- 低レベル

        /// <summary>全ウェイトをインデックス順に読む。buffer は必要なら拡張される。</summary>
        public static void ReadWeights(SkinnedMeshRenderer renderer, ref float[] buffer)
        {
            int n = renderer.sharedMesh.blendShapeCount;
            if (buffer == null || buffer.Length < n) buffer = new float[n];
            for (int i = 0; i < n; i++) buffer[i] = renderer.GetBlendShapeWeight(i);
        }

        /// <summary>全ウェイトをインデックス順に書く。Undo は記録しない。</summary>
        public static void WriteWeights(SkinnedMeshRenderer renderer, float[] buffer, int count)
        {
            int n = Mathf.Min(count, renderer.sharedMesh.blendShapeCount);
            for (int i = 0; i < n; i++) renderer.SetBlendShapeWeight(i, buffer[i]);
        }

        private static void RequestRepaint()
        {
            // Scene ビュー・Game ビュー・Inspector をまとめて再描画要求する。実際の描画は次のエディタ更新で行われる。
            InternalEditorUtility.RepaintAllViews();
        }
    }
}
