using System.Collections.Generic;
using System.Text;
using ShapePick.Data;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>スナップショットとレンダラーの整合性チェック結果（FR-14）。</summary>
    public sealed class ConsistencyReport
    {
        public bool RendererValid;
        public bool MeshNameMatches;
        public bool MeshGuidMatches;

        /// <summary>スナップショットにあるがレンダラー側に無い名前（適用時にスキップされる）。</summary>
        public readonly List<string> MissingInRenderer = new List<string>();

        /// <summary>レンダラー側にあるがスナップショットに無い名前（適用時に変更されない）。</summary>
        public readonly List<string> MissingInSnapshot = new List<string>();

        /// <summary>
        /// 名前ベースで完全に一致するか。照合キーはメッシュ名 + ブレンドシェイプ名なので（仕様 2.4 / 3.2）、
        /// GUID の不一致（別 FBX の同名メッシュ）は意図的にここへ含めない。GUID は MeshGuidMatches で別に見る。
        /// </summary>
        public bool IsFullyConsistent =>
            RendererValid && MeshNameMatches && MissingInRenderer.Count == 0 && MissingInSnapshot.Count == 0;

        /// <summary>名前ベースで一部でも適用できるか。</summary>
        public bool IsPartiallyApplicable => RendererValid && ApplicableCount > 0;

        public int ApplicableCount;
    }

    /// <summary>対象 SkinnedMeshRenderer の検出とメッシュ識別（FR-01 / FR-13 / FR-14）。</summary>
    public static class RendererResolver
    {
        private static readonly List<SkinnedMeshRenderer> s_scratch = new List<SkinnedMeshRenderer>();

        /// <summary>ブレンドシェイプを 1 つ以上持ち、他ツールの隠しコピーでない SkinnedMeshRenderer か。</summary>
        public static bool IsEligible(SkinnedMeshRenderer renderer)
        {
            if (renderer == null || renderer.sharedMesh == null || renderer.sharedMesh.blendShapeCount == 0) return false;
            return !IsHiddenClone(renderer);
        }

        /// <summary>
        /// 他ツールがプレビュー用に作る使い捨ての複製か（FaceEmo は HideAndDontSave のコピーを作る）。
        /// 保存されない上に本体と同じ名前・同じ Hierarchy パスを持つので、対象にすると
        /// 本体の候補と取り違えたり、捨てるだけのセットを作ってしまう。
        /// </summary>
        public static bool IsHiddenClone(Renderer renderer)
        {
            if (renderer == null) return false;
            for (var t = renderer.transform; t != null; t = t.parent)
            {
                if ((t.gameObject.hideFlags & HideFlags.DontSaveInEditor) != 0) return true;
            }
            return false;
        }

        /// <summary>root とその子孫から候補を集める（非アクティブ含む）。Hierarchy 順。</summary>
        public static void FindCandidates(GameObject root, List<SkinnedMeshRenderer> results)
        {
            results.Clear();
            if (root == null) return;

            s_scratch.Clear();
            root.GetComponentsInChildren(true, s_scratch);
            foreach (var r in s_scratch)
            {
                if (IsEligible(r)) results.Add(r);
            }
            s_scratch.Clear();
        }

        public static List<SkinnedMeshRenderer> FindCandidates(GameObject root)
        {
            var list = new List<SkinnedMeshRenderer>();
            FindCandidates(root, list);
            return list;
        }

        /// <summary>
        /// 選択オブジェクトから既定の対象を決める。
        /// 1) 自身が対象なら自身、2) 子孫の中でブレンドシェイプ数が最多のもの、
        /// 3) 子孫に無ければ祖先へ遡って同じ規則で探す（ボーンを選んでいる場合など）。
        /// </summary>
        public static SkinnedMeshRenderer ResolveDefault(GameObject selected)
        {
            if (selected == null) return null;

            var own = selected.GetComponent<SkinnedMeshRenderer>();
            if (IsEligible(own)) return own;

            var candidates = new List<SkinnedMeshRenderer>();
            Transform cursor = selected.transform;
            while (cursor != null)
            {
                FindCandidates(cursor.gameObject, candidates);
                if (candidates.Count > 0) return PickLargest(candidates);
                cursor = cursor.parent;
            }
            return null;
        }

        private static SkinnedMeshRenderer PickLargest(List<SkinnedMeshRenderer> candidates)
        {
            SkinnedMeshRenderer best = null;
            int bestCount = -1;
            foreach (var c in candidates)
            {
                int n = c.sharedMesh.blendShapeCount;
                if (n > bestCount)
                {
                    best = c;
                    bestCount = n;
                }
            }
            return best;
        }

        /// <summary>アセット由来メッシュの GUID。シーン内やスクリプト生成メッシュなら空文字。</summary>
        public static string GetMeshGuid(Mesh mesh)
        {
            if (mesh == null) return string.Empty;
            if (AssetDatabase.TryGetGUIDAndLocalFileIdentifier(mesh, out string guid, out long _))
            {
                return guid ?? string.Empty;
            }
            return string.Empty;
        }

        /// <summary>"Root/Child/Body" 形式の Hierarchy パス。</summary>
        public static string GetHierarchyPath(Transform t)
        {
            if (t == null) return string.Empty;
            var sb = new StringBuilder(t.name);
            var p = t.parent;
            while (p != null)
            {
                sb.Insert(0, '/');
                sb.Insert(0, p.name);
                p = p.parent;
            }
            return sb.ToString();
        }

        /// <summary>
        /// スナップショットの取得元と、今のメッシュが別物か（UI の「別メッシュ」警告用）。
        /// GUID が双方にあれば GUID で判定する。名前だけで見ていると、別の FBX にある同名メッシュ
        /// （"Body" は珍しくない）に適用しようとしても警告が出ないため。
        /// どちらかの GUID が無いとき（スクリプト生成メッシュなど）は名前で判定する。
        /// </summary>
        public static bool IsOtherMesh(BlendShapeSnapshot snapshot, Mesh mesh)
        {
            if (snapshot == null || mesh == null) return false;

            string guid = GetMeshGuid(mesh);
            if (!string.IsNullOrEmpty(guid) && !string.IsNullOrEmpty(snapshot.meshGuid)) return guid != snapshot.meshGuid;
            return snapshot.meshName != mesh.name;
        }

        /// <summary>スナップショットが現在のレンダラーにどこまで適用できるかを調べる。</summary>
        public static ConsistencyReport CheckConsistency(SkinnedMeshRenderer renderer, BlendShapeSnapshot snapshot)
        {
            var report = new ConsistencyReport();
            if (snapshot == null) return report;
            if (!IsEligible(renderer)) return report;

            report.RendererValid = true;
            var mesh = renderer.sharedMesh;
            report.MeshNameMatches = snapshot.meshName == mesh.name;

            string guid = GetMeshGuid(mesh);
            report.MeshGuidMatches = string.IsNullOrEmpty(guid) || string.IsNullOrEmpty(snapshot.meshGuid)
                ? report.MeshNameMatches
                : guid == snapshot.meshGuid;

            var cache = BlendShapeNameCache.Get(mesh);
            var seen = new bool[cache.Count];
            var entries = snapshot.entries;
            if (entries != null)
            {
                foreach (var e in entries)
                {
                    if (e == null || e.name == null) continue;
                    if (cache.TryGetIndex(e.name, out int idx))
                    {
                        seen[idx] = true;
                        report.ApplicableCount++;
                    }
                    else
                    {
                        report.MissingInRenderer.Add(e.name);
                    }
                }
            }
            for (int i = 0; i < seen.Length; i++)
            {
                if (!seen[i]) report.MissingInSnapshot.Add(cache.GetKey(i));
            }
            return report;
        }
    }
}
