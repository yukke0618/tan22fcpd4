using System;
using System.Collections.Generic;
using ShapePick.Data;
using UnityEngine;

namespace ShapePick.Services
{
    public enum DiffStatus
    {
        /// <summary>両側にあり、|右 − 左| がしきい値以上。</summary>
        Changed = 0,

        /// <summary>右側にしか無い（左のスナップショットに名前が無い）。</summary>
        MissingLeft = 1,

        /// <summary>左側にしか無い（右のスナップショットに名前が無い）。</summary>
        MissingRight = 2,
    }

    /// <summary>差分表の 1 行。Delta は 右 − 左（3.4 の符号規則）。片側欠損時の値は NaN。</summary>
    public readonly struct DiffRow
    {
        public readonly string Name;
        public readonly float Left;
        public readonly float Right;
        public readonly float Delta;
        public readonly DiffStatus Status;

        public DiffRow(string name, float left, float right, float delta, DiffStatus status)
        {
            Name = name;
            Left = left;
            Right = right;
            Delta = delta;
            Status = status;
        }

        public bool IsMissing => Status != DiffStatus.Changed;
        public float AbsDelta => IsMissing ? 0f : Mathf.Abs(Delta);

        public override string ToString()
        {
            return Status switch
            {
                DiffStatus.MissingLeft => $"{Name}: (左に無し) → {Right:0.##}",
                DiffStatus.MissingRight => $"{Name}: {Left:0.##} → (右に無し)",
                _ => $"{Name}: {Left:0.##} → {Right:0.##} ({(Delta >= 0 ? "+" : "")}{Delta:0.##})",
            };
        }
    }

    /// <summary>
    /// 2 つのエントリ列を名前で結合し、差分行を返す純粋計算（FR-08）。
    /// インスタンスは内部バッファを再利用するため、同じインスタンスを複数スレッドから使ってはならない。
    /// </summary>
    public sealed class DiffCalculator
    {
        private readonly Dictionary<string, int> _rightIndex = new Dictionary<string, int>(1024);
        private readonly List<int> _missingRight = new List<int>(64);
        private bool[] _matched = new bool[1024];

        /// <summary>
        /// 差分を results に書き出す（results は Clear される）。戻り値は行数。
        /// しきい値未満の差は出力しない。しきい値 0 のときは差が 0 でない行だけ出力する。
        /// 順序: 変更行（左の並び順）→ 右に無い行 → 左に無い行。
        /// </summary>
        public int Compute(
            IReadOnlyList<BlendShapeEntry> left,
            IReadOnlyList<BlendShapeEntry> right,
            float threshold,
            List<DiffRow> results)
        {
            if (results == null) throw new ArgumentNullException(nameof(results));
            results.Clear();
            if (threshold < 0f) threshold = 0f;

            int leftCount = left?.Count ?? 0;
            int rightCount = right?.Count ?? 0;

            _rightIndex.Clear();
            for (int i = 0; i < rightCount; i++)
            {
                var e = right[i];
                if (e?.name == null) continue;
                if (!_rightIndex.ContainsKey(e.name)) _rightIndex.Add(e.name, i);
            }

            if (_matched.Length < rightCount) _matched = new bool[Mathf.NextPowerOfTwo(rightCount)];
            else Array.Clear(_matched, 0, rightCount);
            _missingRight.Clear();

            for (int i = 0; i < leftCount; i++)
            {
                var l = left[i];
                if (l?.name == null) continue;

                if (_rightIndex.TryGetValue(l.name, out int ri))
                {
                    _matched[ri] = true;
                    float r = right[ri].weight;
                    float delta = r - l.weight;
                    if (delta != 0f && Mathf.Abs(delta) >= threshold)
                    {
                        results.Add(new DiffRow(l.name, l.weight, r, delta, DiffStatus.Changed));
                    }
                }
                else
                {
                    _missingRight.Add(i);
                }
            }

            for (int k = 0; k < _missingRight.Count; k++)
            {
                var l = left[_missingRight[k]];
                results.Add(new DiffRow(l.name, l.weight, float.NaN, float.NaN, DiffStatus.MissingRight));
            }

            for (int i = 0; i < rightCount; i++)
            {
                if (_matched[i]) continue;
                var r = right[i];
                if (r?.name == null) continue;
                if (_rightIndex[r.name] != i) continue; // 右側の重複名は先頭のみ扱う
                results.Add(new DiffRow(r.name, float.NaN, r.weight, float.NaN, DiffStatus.MissingLeft));
            }

            return results.Count;
        }

        public int Compute(BlendShapeSnapshot left, BlendShapeSnapshot right, float threshold, List<DiffRow> results)
        {
            return Compute(left?.entries, right?.entries, threshold, results);
        }

        /// <summary>差の絶対値が大きい順。欠損行は末尾に名前順で並べる。</summary>
        public static void SortByAbsDeltaDescending(List<DiffRow> rows)
        {
            rows.Sort(CompareAbsDeltaDesc);
        }

        /// <summary>名前順（欠損行も混在）。</summary>
        public static void SortByName(List<DiffRow> rows)
        {
            rows.Sort((a, b) => string.CompareOrdinal(a.Name, b.Name));
        }

        private static int CompareAbsDeltaDesc(DiffRow a, DiffRow b)
        {
            if (a.IsMissing != b.IsMissing) return a.IsMissing ? 1 : -1;
            if (!a.IsMissing)
            {
                int c = b.AbsDelta.CompareTo(a.AbsDelta);
                if (c != 0) return c;
            }
            return string.CompareOrdinal(a.Name, b.Name);
        }

        /// <summary>名前フィルタ（部分一致・大文字小文字無視）。空フィルタは常に true。</summary>
        public static bool MatchesFilter(in DiffRow row, string filter)
        {
            if (string.IsNullOrEmpty(filter)) return true;
            return row.Name != null && row.Name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
