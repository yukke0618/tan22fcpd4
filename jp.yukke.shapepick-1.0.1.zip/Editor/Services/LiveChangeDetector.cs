using System;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// 対象レンダラーの「現在値」が外部（Inspector、Undo、他ツール）で変わったことを検知する。
    /// 契機は 2 つ: Undo.postprocessModifications（即時）と 10 Hz の値ハッシュ比較（取りこぼし対策）。
    /// 検知後 100 ms のデバウンスを置いて Changed を 1 回だけ発火する（性能指針 4.4、PF-09 / PF-12）。
    /// 時刻は Tick(now) で外から与えるため、EditorApplication.update 無しでもテストできる。
    /// </summary>
    public sealed class LiveChangeDetector : IDisposable
    {
        public const double PollIntervalSec = 0.1;
        public const double DebounceSec = 0.1;

        private SkinnedMeshRenderer _target;
        private Mesh _targetMesh;
        private int _lastHash;
        private double _nextPoll;
        private double _pendingSince = -1;
        private bool _hooked;
        private int _suppressDepth;
        private bool _suppressed => _suppressDepth > 0;

        /// <summary>デバウンス後に 1 回発火する。</summary>
        public event Action Changed;

        /// <summary>対象が破棄された・メッシュが差し替わったときに発火する。</summary>
        public event Action TargetInvalidated;

        public SkinnedMeshRenderer Target => _target;
        public bool HasPendingChange => _pendingSince >= 0;

        public void Track(SkinnedMeshRenderer renderer, double now)
        {
            _target = renderer;
            _targetMesh = renderer != null ? renderer.sharedMesh : null;
            _lastHash = ComputeHash(renderer);
            _pendingSince = -1;
            _nextPoll = now + PollIntervalSec;
            EnsureHook();
        }

        public void Untrack()
        {
            _target = null;
            _targetMesh = null;
            _pendingSince = -1;
        }

        /// <summary>
        /// ツール自身がレンダラーを書き換える間だけ抑制して、自分の変更を「外部変更」として拾わないようにする。
        /// ネスト可（Peek 保持中にプレビュー描画が入っても外側の抑制は解けない）。最外の解除時にハッシュを取り直す。
        /// 解除前に Undo.FlushUndoRecordObjects を呼んでおくと、自身の RecordObject が後から postprocessModifications を
        /// 発火させて余計な再計算を招くのを防げる。
        /// </summary>
        public void Suppress(bool on)
        {
            if (on)
            {
                _suppressDepth++;
                return;
            }
            if (_suppressDepth == 0) return;
            _suppressDepth--;
            if (_suppressDepth == 0)
            {
                _lastHash = ComputeHash(_target);
                _pendingSince = -1;
            }
        }

        public bool IsSuppressed => _suppressed;

        /// <summary>ツールが値を変えた直後に呼び、次のポーリングで誤検知しないようにする。</summary>
        public void AcknowledgeCurrentValues()
        {
            _lastHash = ComputeHash(_target);
            _pendingSince = -1;
        }

        /// <summary>外部から明示的に「変わった」と知らせる（Inspector 変更を postprocessModifications で拾ったとき等）。</summary>
        public void MarkChanged(double now)
        {
            if (_suppressed) return;
            if (_pendingSince < 0) _pendingSince = now;
        }

        /// <summary>毎エディタ更新で呼ぶ。now は EditorApplication.timeSinceStartup。</summary>
        public void Tick(double now)
        {
            if (_target == null && _targetMesh == null) return;

            if (_target == null || _target.sharedMesh != _targetMesh || _target.sharedMesh == null)
            {
                Untrack();
                TargetInvalidated?.Invoke();
                return;
            }

            if (now >= _nextPoll)
            {
                _nextPoll = now + PollIntervalSec;
                if (!_suppressed)
                {
                    int h = ComputeHash(_target);
                    if (h != _lastHash)
                    {
                        _lastHash = h;
                        if (_pendingSince < 0) _pendingSince = now;
                    }
                }
            }

            if (_pendingSince >= 0 && now - _pendingSince >= DebounceSec)
            {
                _pendingSince = -1;
                _lastHash = ComputeHash(_target);
                Changed?.Invoke();
            }
        }

        /// <summary>全ウェイトの順序付きハッシュ。1,000 件で 0.05 ms 程度。</summary>
        public static int ComputeHash(SkinnedMeshRenderer renderer)
        {
            if (renderer == null || renderer.sharedMesh == null) return 0;
            int n = renderer.sharedMesh.blendShapeCount;
            unchecked
            {
                int h = 17 + n;
                for (int i = 0; i < n; i++)
                {
                    h = h * 31 + renderer.GetBlendShapeWeight(i).GetHashCode();
                }
                return h;
            }
        }

        private void EnsureHook()
        {
            if (_hooked) return;
            Undo.postprocessModifications += OnPostprocessModifications;
            _hooked = true;
        }

        private UndoPropertyModification[] OnPostprocessModifications(UndoPropertyModification[] modifications)
        {
            if (_target != null && !_suppressed && modifications != null)
            {
                for (int i = 0; i < modifications.Length; i++)
                {
                    var target = modifications[i].currentValue.target;
                    if (target == _target)
                    {
                        MarkChanged(EditorApplication.timeSinceStartup);
                        break;
                    }
                }
            }
            return modifications;
        }

        public void Dispose()
        {
            if (_hooked)
            {
                Undo.postprocessModifications -= OnPostprocessModifications;
                _hooked = false;
            }
            _suppressDepth = 0;
            Untrack();
            Changed = null;
            TargetInvalidated = null;
        }
    }
}
