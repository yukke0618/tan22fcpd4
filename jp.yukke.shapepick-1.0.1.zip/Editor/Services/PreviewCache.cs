using System.IO;
using ShapePick.Data;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// スロットのプレビュー画像を PNG として SnapshotSet の隣（Snapshots/Previews/&lt;snapshotId&gt;.png）に保存する（FR-16、4.3）。
    /// ScriptableObject には埋め込まない。失われても値から再生成できるキャッシュ扱い。
    /// </summary>
    public static class PreviewCache
    {
        public const string FolderName = "Previews";

        public static string FolderFor(SnapshotSet set)
        {
            var assetPath = AssetDatabase.GetAssetPath(set);
            if (string.IsNullOrEmpty(assetPath)) return null;
            var dir = Path.GetDirectoryName(assetPath)?.Replace('\\', '/');
            return string.IsNullOrEmpty(dir) ? null : dir + "/" + FolderName;
        }

        public static string PathFor(SnapshotSet set, string snapshotId)
        {
            var folder = FolderFor(set);
            if (folder == null || string.IsNullOrEmpty(snapshotId)) return null;
            return folder + "/" + snapshotId + ".png";
        }

        /// <summary>RenderTexture の内容を PNG に書き出してインポートし、Texture2D アセットを返す。失敗時は null。</summary>
        public static Texture2D Save(SnapshotSet set, string snapshotId, RenderTexture rt)
        {
            var path = PathFor(set, snapshotId);
            if (path == null || rt == null) return null;

            var bytes = PreviewRenderer.EncodePng(rt);
            if (bytes == null) return null;

            var folder = FolderFor(set);
            if (!AssetDatabase.IsValidFolder(folder))
            {
                var parent = Path.GetDirectoryName(folder)?.Replace('\\', '/');
                AssetDatabase.CreateFolder(parent, FolderName);
            }

            try
            {
                File.WriteAllBytes(path, bytes);
                AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceSynchronousImport);
                ApplyImportSettings(path);
                return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
            }
            catch (System.Exception ex) when (ex is IOException || ex is System.UnauthorizedAccessException)
            {
                Debug.LogWarning("[ShapePick] プレビュー画像を保存できませんでした: " + path + " (" + ex.Message + ")");
                return null;
            }
        }

        public static Texture2D Load(SnapshotSet set, string snapshotId)
        {
            var path = PathFor(set, snapshotId);
            return path == null ? null : AssetDatabase.LoadAssetAtPath<Texture2D>(path);
        }

        public static void Delete(SnapshotSet set, string snapshotId)
        {
            var path = PathFor(set, snapshotId);
            if (path != null && File.Exists(path)) AssetDatabase.DeleteAsset(path);
        }

        /// <summary>
        /// Previews フォルダにある PNG のうち、同じフォルダの SnapshotSet のどのスロットからも参照されていないものを消す
        /// （yayo 依頼 7: 上書き・Undo・空にする、で残った画像が溜まらないように）。削除した数を返す。
        /// Undo で古い id に戻った場合は値から撮り直せるので、消しても復元できる。
        /// </summary>
        public static int DeleteOrphans(SnapshotSet set)
        {
            var folder = FolderFor(set);
            if (folder == null || !AssetDatabase.IsValidFolder(folder)) return 0;
            var parent = Path.GetDirectoryName(folder)?.Replace('\\', '/');
            if (string.IsNullOrEmpty(parent)) return 0;

            var referenced = new System.Collections.Generic.HashSet<string>();
            foreach (var guid in AssetDatabase.FindAssets("t:" + nameof(SnapshotSet), new[] { parent }))
            {
                var other = AssetDatabase.LoadAssetAtPath<SnapshotSet>(AssetDatabase.GUIDToAssetPath(guid));
                if (other == null || other.slots == null) continue;
                foreach (var s in other.slots)
                {
                    if (s != null && !string.IsNullOrEmpty(s.id)) referenced.Add(s.id);
                }
            }
            // まだ保存されていないスロット（このセット自身）も守る
            if (set.slots != null)
            {
                foreach (var s in set.slots)
                {
                    if (s != null && !string.IsNullOrEmpty(s.id)) referenced.Add(s.id);
                }
            }

            int deleted = 0;
            foreach (var guid in AssetDatabase.FindAssets("t:Texture2D", new[] { folder }))
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                if (Path.GetDirectoryName(path)?.Replace('\\', '/') != folder) continue;
                if (!path.EndsWith(".png", System.StringComparison.OrdinalIgnoreCase)) continue;
                var id = Path.GetFileNameWithoutExtension(path);
                if (referenced.Contains(id)) continue;
                if (AssetDatabase.DeleteAsset(path)) deleted++;
            }
            return deleted;
        }

        /// <summary>
        /// プレビュー PNG のインポート設定を整える（ミップ無し・非圧縮・読み取り不可）。設定が違うときだけ再インポートする。
        /// AssetPostprocessor の OnPreprocessTexture は使わない。テクスチャ用の前処理を持つスクリプトが増えると、
        /// Unity はプロジェクト内の全テクスチャを取り込み直すため、導入直後に数分待たされる（9/15 の導入検証で判明）。
        /// </summary>
        internal static void ApplyImportSettings(string path)
        {
            if (!(AssetImporter.GetAtPath(path) is TextureImporter importer)) return;
            if (importer.textureType == TextureImporterType.Default
                && !importer.mipmapEnabled
                && !importer.isReadable
                && importer.sRGBTexture
                && importer.npotScale == TextureImporterNPOTScale.None
                && importer.textureCompression == TextureImporterCompression.Uncompressed
                && importer.maxTextureSize == 1024)
                return;

            importer.textureType = TextureImporterType.Default;
            importer.mipmapEnabled = false;
            importer.isReadable = false;
            importer.sRGBTexture = true;
            importer.npotScale = TextureImporterNPOTScale.None;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.maxTextureSize = 1024;
            importer.SaveAndReimport();
        }
    }
}
