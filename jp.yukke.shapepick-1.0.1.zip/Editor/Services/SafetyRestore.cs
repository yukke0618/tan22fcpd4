using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace ShapePick.Services
{
    /// <summary>
    /// 候補を Scene に表示したまま保存・ビルドされるのを防ぐ（2026-11-13）。
    /// 表示中はレンダラーに候補の値が入っているので、そのまま保存・アップロードすると候補の値が残る。
    /// 保存とビルドのフックはウィンドウの外で動くため、生きているコントローラをここに登録しておき、
    /// 直前に現在値へ戻す。設定「閉じるとき現在値に戻す」には従わない（OFF でも必ず戻す）。
    ///
    /// VRChat SDK のビルドは ShapePick.Editor.VRChat アセンブリ（SDK があるときだけコンパイルされる）が
    /// RestoreForBuild を呼ぶ。このクラス自体は SDK に依存しない。
    /// </summary>
    [InitializeOnLoad]
    public static class SafetyRestore
    {
        private static readonly List<ShapePickController> s_controllers = new List<ShapePickController>();

        static SafetyRestore()
        {
            // sceneSaving はシーンを書き出す前に呼ばれる。ここで戻した値がそのまま保存される
            EditorSceneManager.sceneSaving += OnSceneSaving;
            Undo.undoRedoEvent += OnUndoRedo;
            EditorApplication.update += OnEditorUpdate;
            // Prefab モードの保存（PrefabStage.prefabSaving）には掛けない。Auto Save が既定で ON なので、
            // 候補を表示した直後に保存が走り、表示がすぐ現在値へ戻ってしまうおそれがある（Codex レビュー指摘、実機未確認）。
            // Prefab モードでは従来どおり、帯の注意と README の案内に任せる
        }

        // ------------------------------------------------------------------ 離れたあとの Undo の見張り

        // コントローラが離れた（対象を変えた・ウィンドウを閉じた）レンダラーと、そのときの現在値。
        // Undo 履歴には表示切替が残っているので、あとから Undo / Redo されると候補の値がレンダラーへ入る。
        // 表示切替は現在値そのものを変える操作ではないので、そのときは直前の値（控え）へ書き戻す。
        // メモリ上にしか持たないので、スクリプトの再コンパイルをまたぐと見張りは外れる（Undo 履歴は残る）。
        private static readonly Dictionary<SkinnedMeshRenderer, float[]> s_undoGuards = new Dictionary<SkinnedMeshRenderer, float[]>();

        internal static void GuardUndo(SkinnedMeshRenderer renderer, float[] liveWeights)
        {
            if (renderer != null && liveWeights != null) s_undoGuards[renderer] = liveWeights;
        }

        internal static void ReleaseUndoGuard(SkinnedMeshRenderer renderer)
        {
            if (!ReferenceEquals(renderer, null)) s_undoGuards.Remove(renderer);
        }

        /// <summary>見張っているレンダラーの数（テスト用）。</summary>
        public static int UndoGuardCount => s_undoGuards.Count;

        private static void OnUndoRedo(in UndoRedoInfo info) => HandleUndoRedo(info.undoName);

        /// <summary>Undo / Redo が行われた。表示切替なら、見張っているレンダラーを控えの現在値へ書き戻す。</summary>
        public static void HandleUndoRedo(string undoName)
        {
            if (undoName != SnapshotService.UndoSwitch || s_undoGuards.Count == 0) return;

            // 控えは「この Undo / Redo の直前の値」（毎エディタ更新で取り直している）。
            // この Undo で値が変わったレンダラーだけを控えへ戻す。変わっていないものには触れない
            foreach (var pair in s_undoGuards)
            {
                var renderer = pair.Key;
                if (!IsGuardUsable(renderer, pair.Value)) continue;
                SnapshotService.WriteWeights(renderer, pair.Value, pair.Value.Length);
            }
            UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
        }

        private static bool IsGuardUsable(SkinnedMeshRenderer renderer, float[] weights)
        {
            return renderer != null && renderer.sharedMesh != null && renderer.sharedMesh.blendShapeCount == weights.Length;
        }

        /// <summary>
        /// 見張っているレンダラーの控えを、いまの値で取り直す。離れたあとに利用者が値を変えても、
        /// 控えが古くならないようにする（古い控えで書き戻すと、利用者の編集を消してしまう）。
        /// </summary>
        private static void OnEditorUpdate()
        {
            if (s_undoGuards.Count == 0) return;

            List<SkinnedMeshRenderer> dead = null;
            foreach (var pair in s_undoGuards)
            {
                if (!IsGuardUsable(pair.Key, pair.Value))
                {
                    (dead ??= new List<SkinnedMeshRenderer>()).Add(pair.Key);
                    continue;
                }
                for (int i = 0; i < pair.Value.Length; i++) pair.Value[i] = pair.Key.GetBlendShapeWeight(i);
            }
            if (dead != null)
            {
                foreach (var r in dead) s_undoGuards.Remove(r);
            }
        }

        internal static void Register(ShapePickController controller)
        {
            if (controller != null && !s_controllers.Contains(controller)) s_controllers.Add(controller);
        }

        internal static void Unregister(ShapePickController controller)
        {
            s_controllers.Remove(controller);
        }

        /// <summary>ビルドを止めたときにダイアログを出すか。テストでは false にして、Console への出力だけにする。</summary>
        public static bool ShowDialogs { get; set; } = true;

        /// <summary>生きているコントローラ（通常はウィンドウ 1 つぶん）。</summary>
        public static IReadOnlyList<ShapePickController> Controllers => s_controllers;

        /// <summary>候補を Scene に表示中のコントローラがあるか。</summary>
        public static bool AnyShowing
        {
            get
            {
                foreach (var c in s_controllers)
                {
                    if (c.IsShowingCandidate) return true;
                }
                return false;
            }
        }

        private static void OnSceneSaving(Scene scene, string path) => RestoreForSceneSave(scene);

        /// <summary>
        /// 保存されるシーンにある対象を現在値へ戻す。戻した数を返す。
        /// 保存は止められないので、戻せなかった対象は Console の警告とウィンドウの通知で知らせるだけになる。
        /// </summary>
        public static int RestoreForSceneSave(Scene scene)
        {
            return RestoreWhere(r => r.gameObject.scene == scene, UI.L.Key.ToastRestoredForSave, out _);
        }

        /// <summary>
        /// ビルドの開始前に、表示中の対象をすべて現在値へ戻す。
        /// ビルド要求の時点ではどのアバターが対象か分からないので、シーンを問わず全部戻す。
        /// </summary>
        /// <param name="reason">戻せなかったときの、利用者向けの説明。</param>
        /// <returns>候補の値が残っていないと言えるなら true。false のときはビルドを止めること。</returns>
        public static bool RestoreForBuild(out string reason)
        {
            RestoreWhere(null, UI.L.Key.ToastRestoredForBuild, out var failed);
            if (failed.Count == 0)
            {
                reason = null;
                return true;
            }
            reason = string.Format(UI.L.T(UI.L.Key.BuildBlockedMessage), string.Join(", ", failed));
            return false;
        }

        /// <param name="filter">対象レンダラーの絞り込み。null なら全部。</param>
        private static int RestoreWhere(System.Predicate<SkinnedMeshRenderer> filter, UI.L.Key toastKey, out List<string> failed)
        {
            failed = new List<string>();
            int restoredCount = 0;

            // 復帰の通知で UI が動くので、列挙中にリストが変わっても困らないよう写しを回す
            // （保存やビルドの中から再び呼ばれても壊れないよう、写しは呼び出しごとに作る）
            foreach (var c in new List<ShapePickController>(s_controllers))
            {
                if (!c.IsShowingCandidate) continue;

                var target = c.Target;
                // 対象が破棄済みなら、候補の値を持つレンダラーはどのシーンにも無い
                if (target == null) continue;
                if (filter != null && !filter(target)) continue;

                string name = RendererResolver.GetHierarchyPath(target.transform);
                bool ok, restored = false;
                try
                {
                    ok = c.RestoreForSafety(out restored);
                }
                catch (System.Exception ex)
                {
                    // 値を戻したあとの画面更新で例外が出ても、残りの対象は必ず処理する。戻せたかは分からないので失敗として扱う
                    Debug.LogException(ex);
                    ok = false;
                }
                if (!ok)
                {
                    failed.Add(name);
                    string message = string.Format(UI.L.T(UI.L.Key.RestoreFailedLog), name);
                    Debug.LogWarning("[ShapePick] " + message, target);
                    c.Notify(message);
                    continue;
                }
                if (!restored) continue;
                restoredCount++;
                c.Notify(UI.L.T(toastKey));
            }
            return restoredCount;
        }
    }
}
