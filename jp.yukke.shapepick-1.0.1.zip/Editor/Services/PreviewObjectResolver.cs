using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using ShapePick.Data;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>プレビューに描ける 1 オブジェクトの情報（FR-23）。</summary>
    public sealed class PreviewObjectInfo
    {
        public Renderer Renderer;
        public string Path;
        public string DisplayName;
        public bool IsTarget;

        /// <summary>シーンでの表示状態（activeInHierarchy かつ enabled）。一覧の既定値。</summary>
        public bool DefaultVisible;

        /// <summary>Head ボーン配下、または Head を主なボーンとするスキンメッシュ。</summary>
        public bool HeadAttached;

        /// <summary>Neck ボーン配下（Head 配下は除く）、または Neck を主なボーンとするスキンメッシュ。</summary>
        public bool NeckAttached;

        /// <summary>
        /// まとまり（衣装など）の root からの相対パス。アバター本体（root 直下のメッシュや、Head を含む Armature 配下）は空文字。
        /// </summary>
        public string GroupPath = string.Empty;

        /// <summary>まとまりの表示名（アバター直下の子オブジェクト名）。本体は空文字。</summary>
        public string GroupName = string.Empty;

        public bool IsSkinned => Renderer is SkinnedMeshRenderer;
    }

    /// <summary>
    /// 対象レンダラーと同じアバターにあるレンダラーを集め、「頭まわり」判定と表示可否の解決を行う（FR-23）。
    /// シーンのオブジェクトは一切変更しない。
    /// </summary>
    public static class PreviewObjectResolver
    {
        private static readonly List<Renderer> s_scratch = new List<Renderer>();

        /// <summary>
        /// 衣装・髪のボーン → 統合先（アバター本体）のボーン の対応を返す。既定は Modular Avatar の Merge Armature を読む。
        /// テストで差し替えられるように公開している。
        /// </summary>
        public static Func<GameObject, Dictionary<Transform, Transform>> MergedBoneProvider = ModularAvatarMergedBones;

        private const string MergeArmatureTypeName = "nadena.dev.modular_avatar.core.ModularAvatarMergeArmature";
        private static MethodInfo s_getBonesMapping;
        private static bool s_mergeLookupFailed;

        /// <summary>アバターの root。最上位の Animator があればその GameObject、無ければ Transform.root。</summary>
        public static GameObject FindAvatarRoot(Renderer target)
        {
            if (target == null) return null;
            Transform t = target.transform;
            Transform best = null;
            while (t != null)
            {
                if (t.GetComponent<Animator>() != null) best = t;
                t = t.parent;
            }
            return (best != null ? best : target.transform.root).gameObject;
        }

        /// <summary>Head / Neck ボーンを探す。Humanoid なら Animator から、そうでなければ名前で探す。</summary>
        public static void FindHeadAndNeck(GameObject root, out Transform head, out Transform neck)
        {
            head = null;
            neck = null;
            if (root == null) return;

            var animator = root.GetComponent<Animator>();
            if (animator != null && animator.isHuman && animator.avatar != null)
            {
                head = animator.GetBoneTransform(HumanBodyBones.Head);
                neck = animator.GetBoneTransform(HumanBodyBones.Neck);
            }
            if (head == null || neck == null)
            {
                foreach (var t in root.GetComponentsInChildren<Transform>(true))
                {
                    if (t.GetComponent<Renderer>() != null) continue; // メッシュ側の "Head" は除外
                    string n = t.name.ToLowerInvariant();
                    if (head == null && (n == "head" || n.EndsWith("_head") || n.EndsWith(".head") || n.EndsWith(" head"))) head = t;
                    else if (neck == null && (n == "neck" || n.EndsWith("_neck") || n.EndsWith(".neck") || n.EndsWith(" neck"))) neck = t;
                }
            }
        }

        /// <summary>対象と同じアバターの全レンダラーを集める（対象自身を先頭に含む）。</summary>
        public static List<PreviewObjectInfo> Collect(SkinnedMeshRenderer target)
        {
            var list = new List<PreviewObjectInfo>();
            if (target == null) return list;

            var root = FindAvatarRoot(target);
            FindHeadAndNeck(root, out var head, out var neck);
            Dictionary<Transform, Transform> merged = null;
            try { merged = MergedBoneProvider?.Invoke(root); }
            catch (Exception) { merged = null; }

            s_scratch.Clear();
            root.GetComponentsInChildren(true, s_scratch);
            foreach (var r in s_scratch)
            {
                if (r == null) continue;
                bool isTarget = r == target;
                if (!isTarget && !IsDrawable(r)) continue;
                // EditorOnly はアップロード時に消えるので、一覧にも出さない（yayo 指摘 9/17）
                if (!isTarget && IsEditorOnly(r.transform, root.transform)) continue;

                var info = new PreviewObjectInfo
                {
                    Renderer = r,
                    Path = RelativePath(root.transform, r.transform),
                    DisplayName = r.gameObject.name,
                    IsTarget = isTarget,
                    DefaultVisible = isTarget || (r.gameObject.activeInHierarchy && r.enabled),
                };
                Classify(info, head, neck, merged);
                AssignGroup(info, root.transform, head);
                list.Add(info);
            }
            s_scratch.Clear();

            // まとまりの並び: 対象を含むまとまり → 本体 → 他の衣装（Hierarchy 順）
            var groupOrder = new List<string>();
            foreach (var i in list) if (i.IsTarget) groupOrder.Add(i.GroupPath);
            if (!groupOrder.Contains(string.Empty)) groupOrder.Add(string.Empty);
            foreach (var i in list) if (!groupOrder.Contains(i.GroupPath)) groupOrder.Add(i.GroupPath);

            // まとまりの中は 対象 → 頭まわり → Neck → その他、の順。同じ区分内は Hierarchy 順のまま
            var ordered = new List<PreviewObjectInfo>(list.Count);
            foreach (var g in groupOrder)
            {
                foreach (var i in list) if (i.GroupPath == g && i.IsTarget) ordered.Add(i);
                foreach (var i in list) if (i.GroupPath == g && !i.IsTarget && i.HeadAttached) ordered.Add(i);
                foreach (var i in list) if (i.GroupPath == g && !i.IsTarget && !i.HeadAttached && i.NeckAttached) ordered.Add(i);
                foreach (var i in list) if (i.GroupPath == g && !i.IsTarget && !i.HeadAttached && !i.NeckAttached) ordered.Add(i);
            }
            return ordered;
        }

        /// <summary>
        /// アバター直下の子オブジェクトを「まとまり」とする（衣装のプレハブはたいていここに置かれる。yayo 依頼 9/16）。
        /// root 直下のメッシュそのものと、Head ボーンを含む子（アバター本体の Armature）の配下は本体として扱う。
        /// </summary>
        private static void AssignGroup(PreviewObjectInfo info, Transform root, Transform head)
        {
            var t = info.Renderer.transform;
            if (t == root || t.parent == null) return;
            var top = t;
            while (top.parent != null && top.parent != root) top = top.parent;
            if (top.parent != root || top == t) return;
            if (head != null && head.IsChildOf(top)) return;
            info.GroupPath = RelativePath(root, top);
            info.GroupName = top.name;
        }

        private static bool IsDrawable(Renderer r)
        {
            if (r is SkinnedMeshRenderer smr) return smr.sharedMesh != null;
            if (r is MeshRenderer mr)
            {
                var mf = mr.GetComponent<MeshFilter>();
                return mf != null && mf.sharedMesh != null;
            }
            return false;
        }

        private static bool IsEditorOnly(Transform t, Transform root)
        {
            for (var p = t; p != null; p = p.parent)
            {
                if (p.CompareTag("EditorOnly")) return true;
                if (p == root) break;
            }
            return false;
        }

        /// <summary>
        /// t が anc の配下か。Merge Armature で統合されるボーンの配下なら、統合先のボーンで判定する
        /// （髪や衣装を自前の Armature に置いたまま Head に統合する作りに対応。yayo 指摘 9/17）。
        /// </summary>
        private static bool IsUnder(Transform t, Transform anc, Dictionary<Transform, Transform> merged)
        {
            if (t == null || anc == null) return false;
            if (t.IsChildOf(anc)) return true;
            if (merged == null || merged.Count == 0) return false;
            for (var p = t; p != null; p = p.parent)
            {
                if (merged.TryGetValue(p, out var baseBone) && baseBone != null) return baseBone.IsChildOf(anc);
            }
            return false;
        }

        /// <summary>Modular Avatar が入っていれば、Merge Armature の公開 API GetBonesMapping() から対応表を作る。</summary>
        private static Dictionary<Transform, Transform> ModularAvatarMergedBones(GameObject root)
        {
            if (root == null || s_mergeLookupFailed) return null;
            Dictionary<Transform, Transform> map = null;
            foreach (var c in root.GetComponentsInChildren<Component>(true))
            {
                if (c == null || c.GetType().FullName != MergeArmatureTypeName) continue;
                if (s_getBonesMapping == null)
                {
                    s_getBonesMapping = c.GetType().GetMethod("GetBonesMapping", BindingFlags.Public | BindingFlags.Instance, null, Type.EmptyTypes, null);
                    if (s_getBonesMapping == null) { s_mergeLookupFailed = true; return null; }
                }
                if (!(s_getBonesMapping.Invoke(c, null) is IList pairs)) continue;
                foreach (var pair in pairs)
                {
                    if (pair == null) continue;
                    var type = pair.GetType();
                    var baseBone = type.GetField("Item1")?.GetValue(pair) as Transform;
                    var mergeBone = type.GetField("Item2")?.GetValue(pair) as Transform;
                    if (baseBone == null || mergeBone == null) continue;
                    map ??= new Dictionary<Transform, Transform>();
                    map[mergeBone] = baseBone;
                }
            }
            return map;
        }

        private static void Classify(PreviewObjectInfo info, Transform head, Transform neck, Dictionary<Transform, Transform> merged = null)
        {
            if (info.IsTarget) return;
            var t = info.Renderer.transform;

            if (IsUnder(t, head, merged)) { info.HeadAttached = true; return; }
            if (IsUnder(t, neck, merged)) { info.NeckAttached = true; return; }

            if (info.Renderer is SkinnedMeshRenderer smr)
            {
                var bones = smr.bones;
                if (bones == null || bones.Length == 0)
                {
                    var rb = smr.rootBone;
                    if (rb != null)
                    {
                        if (IsUnder(rb, head, merged)) info.HeadAttached = true;
                        else if (IsUnder(rb, neck, merged)) info.NeckAttached = true;
                    }
                    return;
                }

                // ボーンごとに「Head 配下 / Neck 配下 / その他」を先に分類しておく
                int n = bones.Length;
                var kind = new byte[n]; // 0 = その他, 1 = Neck 配下, 2 = Head 配下
                for (int i = 0; i < n; i++)
                {
                    var b = bones[i];
                    if (b == null) continue;
                    if (IsUnder(b, head, merged)) kind[i] = 2;
                    else if (IsUnder(b, neck, merged)) kind[i] = 1;
                }

                // VRChat アバターでは髪などの SkinnedMeshRenderer も bones 配列に全身のボーンを持つことが多い。
                // そのため配列の数ではなく、実際のボーンウェイトの総量で「どの骨に付いているか」を見る。
                float total = 0f, underHead = 0f, underNeck = 0f;
                var mesh = smr.sharedMesh;
                var weights = mesh != null ? mesh.boneWeights : null;
                if (weights != null && weights.Length > 0)
                {
                    foreach (var w in weights)
                    {
                        Accumulate(kind, w.boneIndex0, w.weight0, ref total, ref underHead, ref underNeck);
                        Accumulate(kind, w.boneIndex1, w.weight1, ref total, ref underHead, ref underNeck);
                        Accumulate(kind, w.boneIndex2, w.weight2, ref total, ref underHead, ref underNeck);
                        Accumulate(kind, w.boneIndex3, w.weight3, ref total, ref underHead, ref underNeck);
                    }
                }
                else
                {
                    // ウェイト情報が無い（スクリプト生成など）ときは配列の数で代用する
                    for (int i = 0; i < n; i++)
                    {
                        if (bones[i] == null) continue;
                        total += 1f;
                        if (kind[i] == 2) underHead += 1f;
                        else if (kind[i] == 1) underNeck += 1f;
                    }
                }

                if (total <= 0f) return;
                // 過半が Head 配下なら髪・耳などの頭まわり。体メッシュは全身に重みが散るので該当しない
                if (underHead * 2f > total) info.HeadAttached = true;
                else if ((underHead + underNeck) * 2f > total) info.NeckAttached = true;
            }
        }

        private static void Accumulate(byte[] kind, int boneIndex, float weight, ref float total, ref float underHead, ref float underNeck)
        {
            if (weight <= 0f || boneIndex < 0 || boneIndex >= kind.Length) return;
            total += weight;
            if (kind[boneIndex] == 2) underHead += weight;
            else if (kind[boneIndex] == 1) underNeck += weight;
        }

        /// <summary>root からの相対パス（"Armature/Hips/.../Hair"）。root 自身なら名前。</summary>
        public static string RelativePath(Transform root, Transform t)
        {
            if (t == null) return string.Empty;
            if (root == null || t == root) return t.name;
            var parts = new List<string>();
            var cur = t;
            while (cur != null && cur != root)
            {
                parts.Add(cur.name);
                cur = cur.parent;
            }
            parts.Reverse();
            return string.Join("/", parts);
        }

        /// <summary>プリセットが要求する表示可否。Custom のときは既定を返す。</summary>
        public static bool PresetVisible(PreviewObjectInfo info, PreviewObjectPreset preset, bool includeNeck)
        {
            if (info.IsTarget) return true;
            switch (preset)
            {
                case PreviewObjectPreset.TargetOnly:
                    return false;
                case PreviewObjectPreset.HeadOnly:
                    // シーンで非表示のもの（着せ替え前の初期の髪など）は「頭まわり」でも出さない（yayo 指摘 9/17）
                    return info.DefaultVisible && (info.HeadAttached || (includeNeck && info.NeckAttached));
                default:
                    return info.DefaultVisible;
            }
        }

        /// <summary>
        /// 最終的な表示可否。個別の上書きがあればそれ、無ければプリセットの規則。
        /// </summary>
        public static bool IsVisible(PreviewObjectInfo info, SnapshotSet set)
        {
            if (info.IsTarget) return true;
            if (set != null)
            {
                var o = set.GetPreviewOverride(info.Path);
                if (o.HasValue) return o.Value;
                return PresetVisible(info, set.previewPreset, set.previewIncludeNeck);
            }
            return info.DefaultVisible;
        }

        /// <summary>
        /// paths のオブジェクトをまとめて表示 / 非表示にする（個別チェック・衣装ごとのチェック共通）。
        /// プリセットの規則と同じ値なら上書きを持たない。上書きが残るならプリセットは Custom に移し、
        /// 元のプリセットで見えていたものは既定との差分として明示する。対象は常に表示なので触らない。
        /// </summary>
        public static void SetVisible(IReadOnlyList<PreviewObjectInfo> objects, SnapshotSet set, ICollection<string> paths, bool visible)
        {
            if (objects == null || set == null || paths == null || paths.Count == 0) return;
            foreach (var o in objects)
            {
                if (o.IsTarget || !paths.Contains(o.Path)) continue;
                bool presetValue = PresetVisible(o, set.previewPreset, set.previewIncludeNeck);
                set.SetPreviewOverride(o.Path, visible == presetValue ? (bool?)null : visible);
            }
            if (set.previewObjects.Count > 0 && set.previewPreset != PreviewObjectPreset.Custom)
            {
                foreach (var o in objects)
                {
                    if (o.IsTarget) continue;
                    bool v = paths.Contains(o.Path) ? visible : IsVisible(o, set);
                    set.SetPreviewOverride(o.Path, v == o.DefaultVisible ? (bool?)null : v);
                }
                set.previewPreset = PreviewObjectPreset.Custom;
            }
        }

        /// <summary>表示するレンダラー（対象を除く）を results に集める。</summary>
        public static void CollectVisibleExtras(IReadOnlyList<PreviewObjectInfo> objects, SnapshotSet set, List<Renderer> results)
        {
            results.Clear();
            if (objects == null) return;
            for (int i = 0; i < objects.Count; i++)
            {
                var o = objects[i];
                if (o.IsTarget || o.Renderer == null) continue;
                if (IsVisible(o, set)) results.Add(o.Renderer);
            }
        }
    }
}
