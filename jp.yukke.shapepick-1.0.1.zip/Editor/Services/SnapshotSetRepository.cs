using System;
using System.Collections.Generic;
using System.IO;
using ShapePick.Data;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// SnapshotSet アセットの検索・生成・遅延保存（FR-13、性能指針 4.4）。
    /// 検索はアセットラベル "ShapePick" で絞り、全アセット走査を避ける。
    /// </summary>
    public static class SnapshotSetRepository
    {
        public const string Label = "ShapePick";
        public const string DefaultFolder = "Assets/ShapePick/Snapshots";

        private static readonly HashSet<SnapshotSet> s_pendingSave = new HashSet<SnapshotSet>();
        private static bool s_saveScheduled;

        // ------------------------------------------------------------------ 個体単位の紐付け

        /// <summary>
        /// 対象レンダラーの「その個体」に紐付いた SnapshotSet を探す。
        /// 解決順序は 識別子一致 → パス一致 で、見つからなければ null（**メッシュ名だけでは決して採用しない**）。
        /// </summary>
        public static SnapshotSet FindForTarget(SkinnedMeshRenderer renderer)
        {
            if (renderer == null) return null;
            var mesh = renderer.sharedMesh;
            return FindForTarget(TargetBinding.Capture(renderer), RendererResolver.GetMeshGuid(mesh), mesh != null ? mesh.name : null);
        }

        /// <summary>
        /// 識別情報から SnapshotSet を探す。テストから合成した TargetBinding も渡せる。
        /// </summary>
        /// <param name="binding">対象個体の識別情報。</param>
        /// <param name="meshGuid">保険のパス一致に使うメッシュ GUID。空でもよい。</param>
        /// <param name="meshName">保険のパス一致に使うメッシュ名。空を渡すとメッシュを見ない。</param>
        public static SnapshotSet FindForTarget(in TargetBinding binding, string meshGuid = null, string meshName = null)
        {
            if (!binding.IsValid) return null;

            SnapshotSet pathMatch = null;
            foreach (var set in EnumerateAll())
            {
                // 識別子一致は最優先。パス一致が先に見つかっていても識別子を優先する
                if (set.MatchesGlobalId(binding.GlobalId)) return set;
                if (pathMatch != null) continue;
                if (!set.MatchesPath(binding.Path, binding.Scene)) continue;
                // パスは保険でしかないので、同じ場所に別のアバターを置き直した場合まで拾わないよう
                // メッシュも一致していることを求める（メッシュ名だけで採用はしない。パス一致とセット）
                if (!string.IsNullOrEmpty(meshName) && !set.MatchesMesh(meshGuid, meshName)) continue;
                // まだ生きている別の個体に紐付いているセットは横取りしない
                // （Shinano を消して Shinano (1) を Shinano に改名した、のような場面）
                if (IsBoundElsewhere(set, binding.GlobalId)) continue;
                pathMatch = set;
            }
            return pathMatch;
        }

        /// <summary>このセットが、今の対象とは別の「生きている」個体に紐付いているか。</summary>
        public static bool IsBoundElsewhere(SnapshotSet set, string globalId)
        {
            if (set == null || string.IsNullOrEmpty(set.targetGlobalId)) return false;
            if (set.targetGlobalId == globalId) return false;
            return TargetBinding.ResolveObject(set.targetGlobalId) != null;
        }

        // ------------------------------------------------------------------ 引き継ぎ（紐付けが切れたセット）

        /// <summary>
        /// このセットの紐付け先が、いま開いているシーンに生きているか。
        /// 識別子で引ければ生きている。引けなくても、保険のパスにあるレンダラーを選んだときに
        /// このセットが使われるなら、生きているものとして扱う
        /// （同じ名前・同じ階層で置き直した場合がこれ）。
        /// 閉じているシーンの個体は確かめようがないので、生きていないものとして扱う。
        /// </summary>
        /// <param name="target">
        /// 引き継ぎ先にしようとしている対象。識別子を持たないセット（未保存シーンで作ったもの）の判定に使う。
        /// </param>
        public static bool IsBoundToLiveObject(SnapshotSet set, SkinnedMeshRenderer target = null)
        {
            if (set == null) return false;
            if (TargetBinding.ResolveObject(set.targetGlobalId) != null) return true;

            if (string.IsNullOrEmpty(set.targetGlobalId))
            {
                // 未保存シーンで作ったセットは、頼れるのがパスだけ。シーンを保存するとシーンのキーも変わるので、
                // シーンは問わず、開いているどこかに同じパス・同じメッシュの別のレンダラーがあれば「生きている」側に倒す
                // （未保存シーンに 2 体置いて保存したとき、もう 1 体の候補を取り違えないため。Codex レビュー指摘）。
                // パスの先が引き継ぎ先そのものなら、それは自分が見失った候補なので引き継いでよい
                // 同じパスのものが複数のシーンにあっても見落とさないよう、条件に合うものが 1 つでもあるかを見る
                return TargetBinding.FindLiveRendererAt(set.targetPath, null, r =>
                    r != target && r.sharedMesh != null
                    && set.MatchesMesh(RendererResolver.GetMeshGuid(r.sharedMesh), r.sharedMesh.name)) != null;
            }

            // パスにレンダラーがあるだけでは足りない。そのレンダラーを選んだときに、実際にこのセットが使われること
            // （そのレンダラーが自分のセットを別に持っていれば、このセットは宙に浮いている）
            var atPath = TargetBinding.FindLiveRendererAt(set.targetPath, set.targetScene);
            return atPath != null && FindForTarget(atPath) == set;
        }

        /// <summary>
        /// このセットを今の対象へ引き継いでよいか。条件は次のすべて。
        /// ・今の対象と同じメッシュ（MatchesMesh）で、今の対象のセット自身ではない
        /// ・まだ引き継いでいない登録済みの候補が 1 件以上ある
        /// ・紐付け先がいま開いているシーンに生きていない（生きている別個体のセットは出さない。2 体置いても混ざらない約束を守る）
        /// </summary>
        /// <param name="current">今の対象のセット。無ければ null。</param>
        public static bool IsAdoptable(SnapshotSet set, SkinnedMeshRenderer target, SnapshotSet current)
        {
            if (set == null || set == current || !RendererResolver.IsEligible(target)) return false;
            var mesh = target.sharedMesh;
            if (!set.MatchesMesh(RendererResolver.GetMeshGuid(mesh), mesh.name)) return false;
            if (CountUnadopted(set, current) == 0) return false;
            return !IsBoundToLiveObject(set, target);
        }

        /// <summary>source の登録済みの候補のうち、current へまだ引き継いでいないものの数。</summary>
        public static int CountUnadopted(SnapshotSet source, SnapshotSet current)
        {
            if (source == null || source.slots == null) return 0;
            int n = 0;
            for (int i = 0; i < source.slots.Count; i++)
            {
                if (IsUnadopted(source, i, current)) n++;
            }
            return n;
        }

        /// <summary>source の候補 slot が登録済みで、current へまだ引き継いでいないか。</summary>
        public static bool IsUnadopted(SnapshotSet source, int slot, SnapshotSet current)
        {
            var s = source != null ? source.GetSlot(slot) : null;
            if (s == null || !s.IsRegistered) return false;
            return current == null || current.adoptedFrom == null || !current.adoptedFrom.Contains(s.id);
        }

        /// <summary>今の対象へ引き継げるセット（IsAdoptable）を集める。</summary>
        /// <param name="current">今の対象のセット。無ければ null。</param>
        public static void FindAdoptable(SkinnedMeshRenderer target, SnapshotSet current, List<SnapshotSet> result)
        {
            result.Clear();
            if (!RendererResolver.IsEligible(target)) return;
            // IsAdoptable の中でも全セットを列挙するので、列挙は先に済ませておく
            foreach (var set in new List<SnapshotSet>(EnumerateAll()))
            {
                if (IsAdoptable(set, target, current)) result.Add(set);
            }
        }

        /// <summary>セットのアセット GUID。アセットでなければ空。</summary>
        public static string GetAssetGuid(SnapshotSet set)
        {
            if (set == null) return string.Empty;
            var path = AssetDatabase.GetAssetPath(set);
            return string.IsNullOrEmpty(path) ? string.Empty : AssetDatabase.AssetPathToGUID(path);
        }

        /// <summary>紐付け情報を今の個体に貼り直す。未保存シーンを保存して識別子が変わった場合もここで追従する。</summary>
        public static void Rebind(SnapshotSet set, SkinnedMeshRenderer renderer)
        {
            if (set == null || renderer == null) return;
            Rebind(set, TargetBinding.Capture(renderer));
        }

        /// <summary>識別情報を直接渡して貼り直す。変化が無ければ保存もしない。</summary>
        public static void Rebind(SnapshotSet set, in TargetBinding binding)
        {
            if (set == null || !binding.IsValid) return;
            if (set.UpdateBinding(binding.GlobalId, binding.Path, binding.Scene, binding.AvatarName))
            {
                ScheduleSave(set);
            }
        }

        /// <summary>個体に紐付いたセットを新しく作る。ファイル名は「アバター名_対象名」。</summary>
        public static SnapshotSet CreateForTarget(SkinnedMeshRenderer renderer, string folder = DefaultFolder)
        {
            if (renderer == null) throw new System.ArgumentNullException(nameof(renderer));

            var mesh = renderer.sharedMesh;
            var binding = TargetBinding.Capture(renderer);
            string baseName = binding.AvatarName == binding.TargetName
                ? binding.TargetName
                : binding.AvatarName + "_" + binding.TargetName;

            var set = Create(RendererResolver.GetMeshGuid(mesh), mesh != null ? mesh.name : string.Empty, folder, baseName);
            set.UpdateBinding(binding.GlobalId, binding.Path, binding.Scene, binding.AvatarName);
            ScheduleSave(set);
            return set;
        }

        /// <summary>
        /// 対象に紐付いたセットを返し、無ければ作る。
        /// </summary>
        public static SnapshotSet FindOrCreateForTarget(SkinnedMeshRenderer renderer, string folder = DefaultFolder)
        {
            if (renderer == null) throw new System.ArgumentNullException(nameof(renderer));
            var existing = FindForTarget(renderer);
            if (existing == null) return CreateForTarget(renderer, folder);
            Rebind(existing, renderer);
            return existing;
        }

        // ------------------------------------------------------------------ メッシュ単位の検索（警告・一覧用）

        /// <summary>
        /// メッシュに対応する SnapshotSet を探す。
        /// GUID が双方にあるものは GUID + 名前で厳密一致、無ければ名前一致で最初に見つかったものを返す。
        /// セットの選択には使わない（個体単位の FindForTarget を使う）。
        /// </summary>
        public static SnapshotSet Find(string meshGuid, string meshName)
        {
            if (string.IsNullOrEmpty(meshName)) return null;

            SnapshotSet nameOnlyMatch = null;
            foreach (var set in EnumerateAll())
            {
                if (!set.MatchesMesh(meshGuid, meshName)) continue;

                bool exact = !string.IsNullOrEmpty(meshGuid) && !string.IsNullOrEmpty(set.meshGuid);
                if (exact) return set;
                nameOnlyMatch ??= set;
            }
            return nameOnlyMatch;
        }

        public static SnapshotSet Find(Mesh mesh)
        {
            if (mesh == null) return null;
            return Find(RendererResolver.GetMeshGuid(mesh), mesh.name);
        }

        /// <summary>対応する SnapshotSet を返し、無ければ folder に生成する。</summary>
        public static SnapshotSet FindOrCreate(Mesh mesh, string folder = DefaultFolder)
        {
            if (mesh == null) throw new System.ArgumentNullException(nameof(mesh));
            var guid = RendererResolver.GetMeshGuid(mesh);
            var existing = Find(guid, mesh.name);
            return existing != null ? existing : Create(guid, mesh.name, folder);
        }

        /// <summary>新しい SnapshotSet アセットを生成する。同名ファイルがあれば連番を付ける。</summary>
        /// <param name="fileBaseName">ファイル名の元。省略時はメッシュ名。</param>
        public static SnapshotSet Create(string meshGuid, string meshName, string folder = DefaultFolder, string fileBaseName = null)
        {
            folder = NormalizeFolder(folder);
            EnsureFolder(folder);

            var set = ScriptableObject.CreateInstance<SnapshotSet>();
            set.meshName = meshName;
            set.meshGuid = meshGuid ?? string.Empty;

            string fileName = SanitizeFileName(string.IsNullOrEmpty(fileBaseName) ? meshName : fileBaseName);
            string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + fileName + ".asset");
            AssetDatabase.CreateAsset(set, path);
            AssetDatabase.SetLabels(set, new[] { Label });
            return set;
        }

        /// <summary>ラベル付きの全 SnapshotSet を列挙する（UI の一覧用）。</summary>
        public static IEnumerable<SnapshotSet> EnumerateAll()
        {
            var guids = AssetDatabase.FindAssets("l:" + Label + " t:" + nameof(SnapshotSet));
            foreach (var g in guids)
            {
                var path = AssetDatabase.GUIDToAssetPath(g);
                if (string.IsNullOrEmpty(path)) continue;
                var set = AssetDatabase.LoadAssetAtPath<SnapshotSet>(path);
                if (set != null) yield return set;
            }
        }

        /// <summary>SetDirty を即時に付け、保存は delayCall で 1 回にまとめる。アセットでないものは保存しない。</summary>
        public static void ScheduleSave(SnapshotSet set)
        {
            if (set == null) return;
            EditorUtility.SetDirty(set);
            s_pendingSave.Add(set);
            if (s_saveScheduled) return;
            s_saveScheduled = true;
            EditorApplication.delayCall += FlushPendingSaves;
        }

        /// <summary>保存に失敗した（アセットパス, 例外メッセージ）。UI は赤帯と再試行ボタンを出す（3.7）。</summary>
        public static event Action<string, string> SaveFailed;

        private static readonly List<SnapshotSet> s_flushScratch = new List<SnapshotSet>();

        /// <summary>
        /// 保留中の保存を今すぐ実行する。テストやウィンドウ終了時に使う。
        /// 1 件が失敗しても残りは保存し、失敗した分は保留に残して RetryPendingSaves で再試行できる。
        /// </summary>
        public static void FlushPendingSaves()
        {
            s_saveScheduled = false;
            if (s_pendingSave.Count == 0) return;

            s_flushScratch.Clear();
            s_flushScratch.AddRange(s_pendingSave);
            s_pendingSave.Clear();

            foreach (var set in s_flushScratch)
            {
                if (set == null) continue;
                if (!AssetDatabase.Contains(set)) continue;
                try
                {
                    AssetDatabase.SaveAssetIfDirty(set);
                    if (EditorUtility.IsDirty(set))
                    {
                        // 例外なく戻ったのに dirty のまま = 書き込めなかった（読み取り専用など）
                        throw new IOException("アセットを書き込めませんでした");
                    }
                }
                catch (Exception ex)
                {
                    s_pendingSave.Add(set);
                    SaveFailed?.Invoke(AssetDatabase.GetAssetPath(set), ex.Message);
                }
            }
            s_flushScratch.Clear();
        }

        /// <summary>失敗して保留に残った保存をもう一度試す。</summary>
        public static void RetryPendingSaves()
        {
            foreach (var set in s_pendingSave)
            {
                if (set != null) EditorUtility.SetDirty(set);
            }
            FlushPendingSaves();
        }

        public static bool HasPendingSaves => s_pendingSave.Count > 0;

        /// <summary>ファイル名に使えない文字を '_' に置き換える。</summary>
        public static string SanitizeFileName(string name)
        {
            if (string.IsNullOrWhiteSpace(name)) return "Mesh";
            var invalid = Path.GetInvalidFileNameChars();
            var chars = name.Trim().ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                if (System.Array.IndexOf(invalid, chars[i]) >= 0) chars[i] = '_';
            }
            var s = new string(chars).Trim('.', ' ');
            return s.Length == 0 ? "Mesh" : s;
        }

        private static string NormalizeFolder(string folder)
        {
            if (string.IsNullOrEmpty(folder)) return DefaultFolder;
            folder = folder.Replace('\\', '/').TrimEnd('/');
            if (!folder.StartsWith("Assets")) folder = "Assets/" + folder;
            return folder;
        }

        private static void EnsureFolder(string folder)
        {
            if (AssetDatabase.IsValidFolder(folder)) return;

            var parts = folder.Split('/');
            string current = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                string next = current + "/" + parts[i];
                if (!AssetDatabase.IsValidFolder(next))
                {
                    AssetDatabase.CreateFolder(current, parts[i]);
                }
                current = next;
            }
        }
    }
}
