using System;
using System.Collections.Generic;
using ShapePick.Data;
using UnityEditor;
using UnityEngine;

namespace ShapePick.Services
{
    /// <summary>
    /// PreviewRenderUtility のラッパ（FR-06 / FR-07、3.5 並列プレビュー）。
    /// 実レンダラーの現在のポーズとブレンドシェイプを BakeMesh で焼き、プレビュー用カメラで RenderTexture に描く。
    /// スロットの値を描くときは「退避 → 一時適用（Undo 記録なし） → 描画 → finally で復元」を同一メソッド内で行う（NFR-02）。
    /// GameObject を複製せず、シーンにも触らない。
    /// </summary>
    public sealed class PreviewRenderer : IDisposable
    {
        private PreviewRenderUtility _pru;
        private Mesh _bakeScratch;
        private Material _fallbackMaterial;
        private float[] _backup = Array.Empty<float>();
        private readonly List<Material> _materials = new List<Material>(8);
        private readonly Dictionary<Renderer, Mesh> _extraBakes = new Dictionary<Renderer, Mesh>();
        private Matrix4x4 _targetMatrix = Matrix4x4.identity;
        private IReadOnlyList<Renderer> _extraRenderers;

        /// <summary>
        /// 対象以外に描くレンダラー（髪・アクセサリー・体など、FR-23）。そのままの値で描き、変更しない。
        /// null または空なら対象だけを描く。
        /// </summary>
        public IReadOnlyList<Renderer> ExtraRenderers
        {
            get => _extraRenderers;
            set => _extraRenderers = value;
        }

        public Color BackgroundColor { get; set; } = new Color(0.22f, 0.23f, 0.26f, 1f);

        /// <summary>直近の描画にかかった時間（ms）。性能確認用。</summary>
        public double LastRenderMilliseconds { get; private set; }

        public PreviewRenderer()
        {
            _pru = new PreviewRenderUtility();
            var cam = _pru.camera;
            cam.nearClipPlane = 0.01f;
            cam.farClipPlane = 100f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.allowHDR = false;
            cam.allowMSAA = true;

            if (_pru.lights != null && _pru.lights.Length > 0)
            {
                _pru.lights[0].intensity = 1.1f;
                _pru.lights[0].color = Color.white;
                if (_pru.lights.Length > 1)
                {
                    _pru.lights[1].intensity = 0.5f;
                    _pru.lights[1].color = new Color(0.85f, 0.9f, 1f);
                }
            }
            _pru.ambientColor = new Color(0.45f, 0.45f, 0.5f, 1f);
        }

        /// <summary>
        /// 描画する。temporaryValues が null ならレンダラーの今の値、非 null ならその値を一時適用して描く。
        /// 戻り値は描けたか。target は呼び出し側が確保した RenderTexture（正方形でなくてもよい）。
        /// </summary>
        public bool Render(SkinnedMeshRenderer renderer, IReadOnlyList<BlendShapeEntry> temporaryValues, PreviewCameraState camera, RenderTexture target)
        {
            if (_pru == null) throw new ObjectDisposedException(nameof(PreviewRenderer));
            if (target == null || !RendererResolver.IsEligible(renderer)) return false;

            var sw = System.Diagnostics.Stopwatch.StartNew();
            var mesh = renderer.sharedMesh;
            int count = mesh.blendShapeCount;
            bool applied = false;

            try
            {
                if (temporaryValues != null)
                {
                    SnapshotService.ReadWeights(renderer, ref _backup);
                    applied = true;
                    var cache = BlendShapeNameCache.Get(mesh);
                    for (int i = 0; i < temporaryValues.Count; i++)
                    {
                        var e = temporaryValues[i];
                        if (e != null && cache.TryGetIndex(e.name, out int idx))
                        {
                            renderer.SetBlendShapeWeight(idx, e.weight);
                        }
                    }
                }

                DrawInternal(renderer, camera, target);
                return true;
            }
            finally
            {
                if (applied)
                {
                    SnapshotService.WriteWeights(renderer, _backup, count);
                }
                sw.Stop();
                LastRenderMilliseconds = sw.Elapsed.TotalMilliseconds;
            }
        }

        private void DrawInternal(SkinnedMeshRenderer renderer, PreviewCameraState camera, RenderTexture target)
        {
            if (_bakeScratch == null)
            {
                _bakeScratch = new Mesh { name = "ShapePick.PreviewBake", hideFlags = HideFlags.HideAndDontSave };
            }
            _targetMatrix = BakeForDraw(renderer, _bakeScratch);

            // BeginPreview は pixelsPerPoint を掛けて RenderTexture を確保するので、ピクセル数をポイントに戻して渡す
            float ppp = Mathf.Max(1f, EditorGUIUtility.pixelsPerPoint);
            _pru.BeginPreview(new Rect(0f, 0f, target.width / ppp, target.height / ppp), GUIStyle.none);
            bool begun = true;
            try
            {
                DrawScene(renderer, camera);
                _pru.Render(true, false);
                var result = _pru.EndPreview();
                begun = false;
                if (result != null)
                {
                    // Graphics.Blit は RenderTexture.active を dest に差し替えるので、元に戻す
                    var prevActive = RenderTexture.active;
                    Graphics.Blit(result, target);
                    RenderTexture.active = prevActive;
                }
            }
            finally
            {
                // 描画中に例外が出ても PreviewRenderUtility を「Begin 済み」のまま残さない
                if (begun) _pru.EndPreview();
            }
        }

        private void DrawScene(SkinnedMeshRenderer renderer, PreviewCameraState camera)
        {
            var cam = _pru.camera;
            cam.backgroundColor = BackgroundColor;
            cam.transform.SetPositionAndRotation(camera.Position, camera.Rotation);
            cam.fieldOfView = camera.fov;
            _pru.cameraFieldOfView = camera.fov;
            // Scene ビューの Persp / Iso と同じ切替。Iso は同じ距離で同じ範囲が映る半高さにする
            cam.orthographic = camera.orthographic;
            cam.orthographicSize = camera.OrthographicSize;

            if (_pru.lights != null && _pru.lights.Length > 0)
            {
                // キーライトはカメラの少し上・右から。左右のプレビューで同じ見え方になる
                _pru.lights[0].transform.rotation = camera.Rotation * Quaternion.Euler(25f, 30f, 0f);
                if (_pru.lights.Length > 1)
                {
                    _pru.lights[1].transform.rotation = camera.Rotation * Quaternion.Euler(-10f, -140f, 0f);
                }
            }

            DrawRendererMesh(renderer, _bakeScratch, _targetMatrix);

            if (_extraRenderers != null)
            {
                // NDMF のプレビューが有効なら、Scene ビューと同じくプロキシ（組み立て後の姿）を描く。
                // 対象（表情を一時的に書き換えて描くメッシュ）は元のまま描く
                var proxyMap = NdmfPreviewBridge.GetProxyMap();
                for (int i = 0; i < _extraRenderers.Count; i++)
                {
                    var r = _extraRenderers[i];
                    if (r == null || r == renderer) continue;
                    DrawExtra(r, NdmfPreviewBridge.Resolve(proxyMap, r));
                }
            }
        }

        /// <summary>original は焼き込みメッシュの置き場のキー、r は実際に描くレンダラー（NDMF のプロキシのことがある）。</summary>
        private void DrawExtra(Renderer original, Renderer r)
        {
            if (r == null) return;

            if (r is SkinnedMeshRenderer smr)
            {
                if (smr.sharedMesh == null) return;
                if (!_extraBakes.TryGetValue(original, out var bake) || bake == null)
                {
                    bake = new Mesh { name = "ShapePick.ExtraBake", hideFlags = HideFlags.HideAndDontSave };
                    _extraBakes[original] = bake;
                }
                DrawRendererMesh(r, bake, BakeForDraw(smr, bake));
                return;
            }

            if (r is MeshRenderer mr)
            {
                var mf = mr.GetComponent<MeshFilter>();
                if (mf == null || mf.sharedMesh == null) return;
                DrawRendererMesh(r, mf.sharedMesh, r.transform.localToWorldMatrix);
            }
        }

        /// <summary>
        /// スキンメッシュを焼き込み、その焼き込みメッシュを描くときの行列を返す（テスト用に分けてある）。
        /// BakeMesh(useScale: true) はレンダラーの Transform の scale を取り除いたローカル頂点を返すので、
        /// localToWorldMatrix で描くと Unity 自身の描画と一致する（親・自身・不均一な scale、ボーン無し、scale 0 をテストで確認）。
        /// 1.0.0 までは位置と回転だけの行列で描いていて、scale の付いた衣装や髪のモジュールがずれていた（9/17）。
        /// </summary>
        public static Matrix4x4 BakeForDraw(SkinnedMeshRenderer smr, Mesh into)
        {
            smr.BakeMesh(into, true);
            return smr.transform.localToWorldMatrix;
        }

        private void DrawRendererMesh(Renderer r, Mesh mesh, Matrix4x4 matrix)
        {
            r.GetSharedMaterials(_materials);
            int subMeshCount = mesh.subMeshCount;
            for (int i = 0; i < subMeshCount; i++)
            {
                var mat = i < _materials.Count ? _materials[i] : null;
                if (mat == null) mat = FallbackMaterial;
                _pru.DrawMesh(mesh, matrix, mat, i);
            }
        }

        /// <summary>もう描かないレンダラーの焼き込みメッシュを捨てる。</summary>
        public void ReleaseExtraBakes()
        {
            foreach (var kv in _extraBakes)
            {
                if (kv.Value != null) UnityEngine.Object.DestroyImmediate(kv.Value);
            }
            _extraBakes.Clear();
        }

        public bool IsDisposed => _pru == null;

        private Material FallbackMaterial
        {
            get
            {
                if (_fallbackMaterial == null)
                {
                    var shader = Shader.Find("Standard") ?? Shader.Find("Hidden/InternalErrorShader");
                    _fallbackMaterial = new Material(shader) { hideFlags = HideFlags.HideAndDontSave };
                }
                return _fallbackMaterial;
            }
        }

        /// <summary>
        /// 構図の基準点・アバターの向き・スケールを求める。Humanoid なら Head ボーン、無ければレンダラー境界の上部 30%。
        /// </summary>
        public static void GetFramingAnchor(SkinnedMeshRenderer renderer, out Vector3 anchor, out Quaternion rootRotation, out float scale)
        {
            anchor = Vector3.zero;
            rootRotation = Quaternion.identity;
            scale = 1f;
            if (renderer == null) return;

            var root = renderer.transform.root;
            rootRotation = Quaternion.Euler(0f, root.eulerAngles.y, 0f);
            scale = Mathf.Max(0.01f, root.lossyScale.y);

            Transform head = null;
            var animator = renderer.GetComponentInParent<Animator>();
            if (animator != null && animator.isHuman && animator.avatar != null)
            {
                head = animator.GetBoneTransform(HumanBodyBones.Head);
            }

            if (head != null)
            {
                anchor = head.position;
            }
            else
            {
                var b = renderer.bounds;
                anchor = b.center + Vector3.up * (b.extents.y * 0.7f);
                // Head ボーンが無いときは境界の大きさで代用（1.5m 前後の人型を 1 とみなす）
                scale = Mathf.Max(0.01f, b.size.y / 1.5f);
            }
        }

        /// <summary>
        /// 初期フレーミング（FR-07）。既定の構図（設定 → 無ければ組み込みのバストアップ）を、対象の基準点・向き・大きさに当てはめる。
        /// </summary>
        public static PreviewCameraState FitToFace(SkinnedMeshRenderer renderer, float fov = 0f)
        {
            return FitToFace(renderer, ShapePickSettings.DefaultCameraPreset, fov);
        }

        public static PreviewCameraState FitToFace(SkinnedMeshRenderer renderer, CameraPreset preset, float fov = 0f)
        {
            if (renderer == null)
            {
                var d = PreviewCameraState.Default;
                if (fov > 0f) d.fov = fov;
                return d;
            }
            GetFramingAnchor(renderer, out var anchor, out var rootRotation, out var scale);
            if (fov > 0f) preset.fov = fov;
            return preset.Apply(anchor, rootRotation, scale);
        }

        /// <summary>今の構図を、対象に依存しない既定の構図として取り出す（［この構図を既定に］）。</summary>
        public static CameraPreset CapturePreset(SkinnedMeshRenderer renderer, PreviewCameraState state)
        {
            GetFramingAnchor(renderer, out var anchor, out var rootRotation, out var scale);
            return CameraPreset.Capture(state, anchor, rootRotation, scale);
        }

        /// <summary>Scene ビューのカメラ位置・注視点・画角・投影方式を引き継ぐ。Scene ビューが無ければ false。</summary>
        public static bool TryFromSceneView(out PreviewCameraState state)
        {
            var sv = SceneView.lastActiveSceneView;
            if (sv == null || sv.camera == null)
            {
                state = PreviewCameraState.Default;
                return false;
            }
            state = PreviewCameraState.FromLookAt(sv.pivot, sv.rotation, sv.cameraDistance, sv.camera.fieldOfView, sv.orthographic);
            return true;
        }

        /// <summary>RenderTexture を PNG バイト列にする（キャッシュ保存用）。</summary>
        public static byte[] EncodePng(RenderTexture rt)
        {
            if (rt == null) return null;
            var prev = RenderTexture.active;
            var tex = new Texture2D(rt.width, rt.height, TextureFormat.RGBA32, false);
            try
            {
                RenderTexture.active = rt;
                tex.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0, false);
                tex.Apply(false, false);
                return tex.EncodeToPNG();
            }
            finally
            {
                RenderTexture.active = prev;
                UnityEngine.Object.DestroyImmediate(tex);
            }
        }

        /// <summary>描く対象が無いときに背景色で塗る。</summary>
        public static void Clear(RenderTexture rt, Color color)
        {
            if (rt == null) return;
            var prev = RenderTexture.active;
            RenderTexture.active = rt;
            // GL.Clear はそのままの値を書くため、リニア色空間のプロジェクトではカメラ背景と同じ見え方になるよう変換する
            var c = QualitySettings.activeColorSpace == ColorSpace.Linear ? color.linear : color;
            GL.Clear(true, true, c);
            RenderTexture.active = prev;
        }

        public static RenderTexture CreateTarget(int size)
        {
            var rt = new RenderTexture(size, size, 24, RenderTextureFormat.ARGB32)
            {
                name = "ShapePick.Preview" + size,
                hideFlags = HideFlags.HideAndDontSave,
                antiAliasing = 1,
                filterMode = FilterMode.Bilinear,
            };
            rt.Create();
            return rt;
        }

        public void Dispose()
        {
            if (_pru != null)
            {
                _pru.Cleanup();
                _pru = null;
            }
            if (_bakeScratch != null)
            {
                UnityEngine.Object.DestroyImmediate(_bakeScratch);
                _bakeScratch = null;
            }
            ReleaseExtraBakes();
            if (_fallbackMaterial != null)
            {
                UnityEngine.Object.DestroyImmediate(_fallbackMaterial);
                _fallbackMaterial = null;
            }
        }
    }
}
