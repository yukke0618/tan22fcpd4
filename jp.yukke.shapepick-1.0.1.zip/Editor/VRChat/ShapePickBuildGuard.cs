using ShapePick.Services;
using ShapePick.UI;
using UnityEditor;
using UnityEngine;
using VRC.SDKBase.Editor.BuildPipeline;

namespace ShapePick.VRChat
{
    /// <summary>
    /// VRChat SDK のビルド（Build &amp; Test / Build &amp; Publish）の開始前に、候補を表示中の対象を現在値へ戻す。
    /// 戻せなかったときは false を返してビルドを止める。
    ///
    /// このアセンブリは asmdef の versionDefines（com.vrchat.base があれば SHAPEPICK_VRCSDK）と
    /// defineConstraints で「SDK があるときだけ」コンパイルされる。本体（ShapePick.Editor）は SDK に依存しない。
    ///
    /// コールバックの選び方（VRChat SDK 3.10.4 のソースで確認、2026-11-13）:
    /// ・com.vrchat.avatars/Editor/VRCSDK/SDK3A/VRCSdkControlPanelAvatarBuilder.cs の Build() は、
    ///   VRCBuildPipelineCallbacks.OnVRCSDKBuildRequested(Avatar) を呼び（2833 行）、false ならその場で
    ///   BuildBlockedException を投げる。シーン上のアバターを VRC_SdkBuilder.RunExportAvatarBlueprint(target) /
    ///   RunExportAndTestAvatarBlueprint(target) に渡すのはその後（2897・2907 行）。
    ///   VRCSdkControlPanelAvatarBuilderV3.cs（17 行）も同じ順序。
    /// ・IVRCSDKPreprocessAvatarCallback は、書き出しの中で作られたアバターの複製に対して呼ばれる
    ///   （nadena.dev.ndmf/Editor/ApplyOnPlay.cs の注記: 元のアバターと "(Clone)" の付いた複製が同時に存在する）。
    ///   複製は作られた時点のシーンの値を持つので、ここでシーン側を戻しても間に合わない。
    /// ・NDMF（callbackOrder -11000）と Modular Avatar は IVRCSDKPreprocessAvatarCallback で動く。
    ///   ビルド要求のコールバックはそれらより前に全部終わる。
    /// よって、複製が作られる前に呼ばれる IVRCSDKBuildRequestedCallback を使う。
    /// 書き出しの本体は VRCSDKBase-Editor.dll の中で、ソースでは読めていない。
    /// </summary>
    internal sealed class ShapePickBuildGuard : IVRCSDKBuildRequestedCallback
    {
        // ほかのビルド要求コールバックがシーンの値を読む前に戻しておく
        public int callbackOrder => -100000;

        public bool OnBuildRequested(VRCSDKRequestedBuildType requestedBuildType)
        {
            if (SafetyRestore.RestoreForBuild(out string reason)) return true;

            Debug.LogError("[ShapePick] " + reason);
            if (SafetyRestore.ShowDialogs && !Application.isBatchMode)
            {
                EditorUtility.DisplayDialog(L.T(L.Key.BuildBlockedTitle), reason, "OK");
            }
            return false;
        }
    }
}
